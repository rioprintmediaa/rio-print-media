import re
"""
rio_erp_api.py — RIO PRINT MEDIA ERP v2.0
FastAPI backend replacing the PowerShell script.
Data stored in MongoDB Atlas.

Run locally:
    uvicorn rio_erp_api:app --host 0.0.0.0 --port 8001 --reload

Deploy on Render.com:
    Start command: uvicorn rio_erp_api:app --host 0.0.0.0 --port 8001
"""

import os, re, bcrypt, sys, secrets
import httpx
from contextlib import asynccontextmanager
from datetime import datetime, date, timedelta
from typing import Optional, Any

from fastapi import FastAPI, Request, Query, Header
from fastapi.concurrency import run_in_threadpool
from pydantic import BaseModel
from fastapi.responses import JSONResponse, HTMLResponse, FileResponse, Response
from fastapi.middleware.cors import CORSMiddleware
from pymongo import MongoClient, ASCENDING, DESCENDING
from pymongo.collection import Collection
from bson import ObjectId
from dotenv import load_dotenv

# Use logging so uvicorn captures and displays output properly
import logging
import logging.handlers
import pathlib

# ── Logging setup ────────────────────────────────────────────────
# Windows (local run): writes to C:\Rio\Logs\rio_app.log
# Render / Linux:      stdout only (visible in Render → Logs tab)
import platform as _platform

_fmt = logging.Formatter("%(asctime)s | %(levelname)-5s | %(message)s",
                          datefmt="%Y-%m-%d %H:%M:%S")

# Set up "rio_erp_api" logger cleanly — don't use basicConfig (conflicts with uvicorn)
logger = logging.getLogger("rio_erp_api")
logger.setLevel(logging.DEBUG)
logger.propagate = False   # prevent double-logging via root logger

# Always add stdout handler
_sh = logging.StreamHandler()
_sh.setFormatter(_fmt)
if not logger.handlers:    # avoid adding duplicate handlers on reload
    logger.addHandler(_sh)

# File handler — try C:\Rio\Logs on Windows, fallback to script directory
_LOG_FILE = None
_log_candidates = []
if _platform.system() == "Windows":
    _log_candidates = [
        pathlib.Path(r"C:\Rio\Logs"),
        pathlib.Path(os.path.dirname(os.path.abspath(__file__))) / "logs",
        pathlib.Path.cwd() / "logs",
    ]
else:
    # On Linux/Render: no file needed (use Render Logs tab)
    _log_candidates = []

for _log_candidate_dir in _log_candidates:
    try:
        _log_candidate_dir.mkdir(parents=True, exist_ok=True)
        _test = _log_candidate_dir / ".write_test"
        _test.touch(); _test.unlink()
        _LOG_FILE = _log_candidate_dir / "rio_app.log"
        _fh = logging.handlers.RotatingFileHandler(
            _LOG_FILE, maxBytes=5 * 1024 * 1024, backupCount=2, encoding="utf-8"
        )
        _fh.setFormatter(_fmt)
        logger.addHandler(_fh)
        logger.info("=== RIO — Log file: %s ===", _LOG_FILE)
        break
    except Exception as _log_ex:
        logger.debug("Log dir %s not writable: %s", _log_candidate_dir, _log_ex)

if not _LOG_FILE:
    if _platform.system() == "Windows":
        logger.warning("Could not create log file — check C:\\Rio\\Logs permissions")
    else:
        logger.info("=== RIO PRINT MEDIA ERP v2.0 — Render — check Logs tab ===")

load_dotenv(override=False)  # Never override Render environment variables

# ─────────────────────────────────────────────
#  CONFIG
# ─────────────────────────────────────────────
MONGO_URI  = os.environ.get("MONGO_URI", "mongodb+srv://rioprintmediaa_db_Mani:Nannavinam%401212@rioprintmedia.6e7l1ak.mongodb.net/?appName=RIOPRINTMEDIA")
MONGO_DB   = os.environ.get("MONGO_DB",  "RioPrintMedia")
# Rainbow's database name is now configurable (was hardcoded as "RainbowUmbrellas"
# further down in the file), so a test deployment can isolate Rainbow's data too
# via MONGO_DB_RAINBOW, the same way MONGO_DB isolates Rio's. Defaults to the
# existing production database name if unset, so production is unaffected.
MONGO_DB_RAINBOW = os.environ.get("MONGO_DB_RAINBOW", "RainbowUmbrellas")
HTML_FILE  = os.environ.get("HTML_FILE", "RIO_PRINT_MEDIA_ERP.html")

# ── Startup diagnostics ──
logger.info("=" * 60)
logger.info("RIO PRINT MEDIA ERP v2.0 — STARTING UP")
logger.info(f"MONGO_DB  = {MONGO_DB}")
logger.info(f"MONGO_DB_RAINBOW = {MONGO_DB_RAINBOW}")
if MONGO_URI:
    _safe = re.sub(r':(.*?)@', ':***@', MONGO_URI)
    logger.info(f"MONGO_URI = SET → {_safe[:70]}")
else:
    logger.error("MONGO_URI = NOT SET — add it in Render Environment Variables!")
logger.info("=" * 60)

# ─────────────────────────────────────────────
#  DB
# ─────────────────────────────────────────────
_client: MongoClient = None
_db = None

def _ensure_db_blocking() -> bool:
    """Connect to MongoDB if not already connected. Returns True if connected."""
    global _client, _db
    if _db is not None:
        try:
            _client.admin.command("ping")
            return True
        except Exception:
            _client = None
            _db = None
    if not MONGO_URI:
        logger.error("MONGO_URI not set — cannot connect to MongoDB")
        return False
    try:
        _client = MongoClient(
            MONGO_URI,
            serverSelectionTimeoutMS=8000,
            connectTimeoutMS=8000,
            socketTimeoutMS=15000,
        )
        _client.admin.command("ping")
        _db = _client[MONGO_DB]
        logger.info("MongoClient created, pinging Atlas...")
        # Create indexes
        try:
            _db["sales_records"].create_index([("SNo", DESCENDING)])
            _db["daily_expenses"].create_index([("ExpDate", DESCENDING)])
            _db["sales_invoices"].create_index([("InvoiceDate", DESCENDING)])
            _db["quotations"].create_index([("QuotationDate", DESCENDING)])
            _db["attendance"].create_index([("name", ASCENDING), ("date", ASCENDING)], unique=True)
            logger.info("Indexes created")
        except Exception:
            pass
        ensure_default_users()
        ensure_default_debt_loan_auth()
        return True
    except Exception as e:
        logger.error(f"MongoDB connection failed: {e}")
        _client = None
        _db = None
        return False

async def ensure_db() -> bool:
    """
    Async-safe wrapper around the blocking MongoDB connection check.
    Runs the actual pymongo calls in a worker thread so a slow/unresponsive
    Atlas connection never freezes the asyncio event loop (which would make
    the ENTIRE server unresponsive to all users, not just this request).
    """
    return await run_in_threadpool(_ensure_db_blocking)

def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()

def verify_password(plain: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(plain.encode(), hashed.encode())
    except Exception:
        return False


def get_client_ip(request) -> str:
    """The real client IP, not the load balancer's. Render (like most
    hosting platforms) sits the app behind a proxy, so request.client.host
    would just show the proxy's own address - the actual visitor IP is in
    the X-Forwarded-For header instead, which can be a comma-separated
    chain if there are multiple proxies (the first entry is the original
    client)."""
    forwarded = request.headers.get("x-forwarded-for", "")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


def parse_user_agent(ua: str) -> dict:
    """Basic OS/browser identification from the User-Agent string - not a
    real device/computer name. Browsers deliberately don't expose the
    actual hostname of the machine to web pages (that would be a
    fingerprinting/privacy risk), so 'machine name' in the login log
    means 'OS + browser', the closest equivalent actually available."""
    ua = ua or ""
    if "Windows" in ua:
        os_name = "Windows"
    elif "Mac OS" in ua or "Macintosh" in ua:
        os_name = "macOS"
    elif "Android" in ua:
        os_name = "Android"
    elif "iPhone" in ua or "iPad" in ua:
        os_name = "iOS"
    elif "Linux" in ua:
        os_name = "Linux"
    else:
        os_name = "Unknown OS"

    if "Edg/" in ua:
        browser = "Edge"
    elif "Chrome/" in ua and "Chromium" not in ua:
        browser = "Chrome"
    elif "Firefox/" in ua:
        browser = "Firefox"
    elif "Safari/" in ua and "Chrome" not in ua:
        browser = "Safari"
    else:
        browser = "Unknown browser"

    return {"os": os_name, "browser": browser}


async def get_ip_geolocation(ip: str) -> dict:
    """City/region/country from a free IP-geolocation lookup - this is
    approximate (based on which ISP block the IP belongs to), not exact
    GPS location, and won't resolve for local/private IPs (e.g. testing
    on localhost). Short timeout so a slow/unreachable lookup never
    delays the actual login - falls back to 'Unknown' if it fails."""
    if not ip or ip in ("unknown", "127.0.0.1", "localhost") or ip.startswith(("10.", "192.168.", "172.")):
        return {"city": "Unknown", "region": "Unknown", "country": "Unknown"}
    try:
        async with httpx.AsyncClient(timeout=2.0) as client:
            resp = await client.get(f"http://ip-api.com/json/{ip}?fields=status,city,regionName,country")
            data = resp.json()
            if data.get("status") == "success":
                return {"city": data.get("city", "Unknown"), "region": data.get("regionName", "Unknown"), "country": data.get("country", "Unknown")}
    except Exception:
        pass
    return {"city": "Unknown", "region": "Unknown", "country": "Unknown"}

def ensure_default_users():
    """Always ensure admin user exists."""
    try:
        existing = col("rio_users").find_one({"username": "admin"})
        if not existing:
            col("rio_users").insert_one({
                "username": "admin",
                "password": hash_password("rio@admin"),
                "role": "admin",
                "name": "Administrator",
                "scope": "all"
            })
            logger.info("Admin user created: username=admin password=rio@admin")
        else:
            update_fields = {}
            if existing.get("role") != "admin":
                update_fields["role"] = "admin"
            if "scope" not in existing:
                update_fields["scope"] = "all"
            if update_fields:
                col("rio_users").update_one({"username": "admin"}, {"$set": update_fields})
    except Exception as e:
        logger.error(f"ensure_default_users error: {e}")


def ensure_default_debt_loan_auth():
    """Debt & Loan has its own, separate login - independent of the main
    rio_users accounts, by explicit request. Single-user tool, so this
    just ensures one set of credentials exists (auto-created on first
    run), the same way ensure_default_users seeds the main admin account."""
    try:
        existing = col("debt_loan_auth").find_one({"username": "admin"})
        if not existing:
            col("debt_loan_auth").insert_one({
                "username": "admin",
                "password": hash_password("debtloan@123"),
            })
            logger.info("Debt & Loan account created: username=admin password=debtloan@123")
    except Exception as e:
        logger.error(f"ensure_default_debt_loan_auth error: {e}")


def get_db():
    return _db

from contextvars import ContextVar
COMPANY_DBS = {"rio": MONGO_DB, "rainbow": MONGO_DB_RAINBOW}
_company_ctx: ContextVar[str] = ContextVar("company", default="rio")

def col(name: str) -> Collection:
    company = _company_ctx.get()
    if _client and company == "rainbow":
        return _client[MONGO_DB_RAINBOW][name]
    return _db[name]

def shared_col(name: str) -> Collection:
    """Always uses RioPrintMedia — for shared data like customers."""
    return _db[name]

# ─────────────────────────────────────────────
#  HELPERS
# ─────────────────────────────────────────────
def clean(doc: dict) -> dict:
    """Remove MongoDB _id and convert ObjectId."""
    if doc is None:
        return None
    doc.pop("_id", None)
    return doc

def clean_list(docs) -> list:
    return [clean(d) for d in docs]

def to_float(v, default=None):
    if v is None or v == "":
        return default
    try:
        return float(v)
    except:
        return default

def to_int(v, default=None):
    if v is None or v == "":
        return default
    try:
        return int(v)
    except:
        return default

def fy_from_date(d: str) -> str:
    """Return FY string like '2024-25' from a date string."""
    try:
        dt = datetime.strptime(d[:10], "%Y-%m-%d")
        m, y = dt.month, dt.year
        if m >= 4:
            return f"{y}-{str(y+1)[-2:]}"
        else:
            return f"{y-1}-{str(y)[-2:]}"
    except:
        return ""

def current_fy() -> str:
    return fy_from_date(datetime.now().strftime("%Y-%m-%d"))

def fy_range(fy: str):
    """Return (from_date, to_date) strings for a FY like '2024-25'."""
    try:
        y = int(fy.split("-")[0])
        return f"{y}-04-01", f"{y+1}-03-31"
    except:
        return None, None


# ── The link between a sales entry and its invoice ─────────────────────────────────────────────
# A sales entry carries InvoiceNo (shown in the list) and, since v276, InvoiceId (exact). Invoice numbers restart every financial year, so a link
# made of the number alone can mean two different invoices: the exact Id is used whenever it exists.
def err2(msg, code=400, **extra):
    return JSONResponse(content={"error": msg, **extra}, status_code=code)


def _inv_fy(inv):
    return (inv or {}).get("FY") or fy_from_date(((inv or {}).get("InvoiceDate") or "")[:10])


def _sale_fy(sale):
    d = ((sale or {}).get("OrderDate") or "")[:10]
    return fy_from_date(d) if d else ""


def _linked_invoice(sale):
    """The invoice a sales entry is linked to, if it still exists (else None).
    A link that carries the invoice Id is exact. An older link has only the number: the invoice of the sale's own financial year is preferred,
    otherwise the newest invoice with that number."""
    proj = {"_id": 0, "Id": 1, "InvoiceNo": 1, "InvoiceDate": 1, "FY": 1, "Status": 1, "CustomerName": 1}
    iid = to_int((sale or {}).get("InvoiceId"), 0)
    if iid:
        return col("sales_invoices").find_one({"Id": iid}, proj)           # gone (deleted) -> None: the sale can be invoiced again
    no = ((sale or {}).get("InvoiceNo") or "").strip()
    if not no:
        return None
    cands = list(col("sales_invoices").find({"InvoiceNo": no}, proj))
    if not cands:
        return None
    sfy = _sale_fy(sale)
    pick = [c for c in cands if _inv_fy(c) == sfy] or cands
    return sorted(pick, key=lambda c: c.get("Id") or 0)[-1]


def _number_shared(inv):
    """Another LIVE invoice of the same financial year has the same number (a duplicate)."""
    fy = _inv_fy(inv)
    for x in col("sales_invoices").find({"InvoiceNo": inv.get("InvoiceNo", ""), "Status": {"$ne": "Cancelled"}}, {"_id": 0, "Id": 1, "FY": 1, "InvoiceDate": 1}):
        if x.get("Id") != inv.get("Id") and _inv_fy(x) == fy:
            return True
    return False


def _sales_of_invoice(inv, shared):
    """The sales entries that were made into this invoice: by the exact Id; and the older number-only links of the SAME financial year
    (not when another live invoice has the same number - then nobody can tell which sale belongs to which)."""
    out = [r.get("SNo") for r in col("sales_records").find({"InvoiceId": inv.get("Id")}, {"_id": 0, "SNo": 1})]
    if not shared:
        fy = _inv_fy(inv)
        for r in col("sales_records").find({"InvoiceNo": inv.get("InvoiceNo", "")}, {"_id": 0, "SNo": 1, "InvoiceId": 1, "OrderDate": 1}):
            if not to_int(r.get("InvoiceId"), 0) and (not r.get("OrderDate") or _sale_fy(r) == fy):
                out.append(r.get("SNo"))
    return sorted({x for x in out if x is not None})


def _release_sales(snos):
    for n in snos:
        col("sales_records").update_one({"SNo": n}, {"$set": {"InvoiceNo": "", "InvoiceId": 0}})

def next_invoice_no(inv_type: str, fy: str) -> str:
    fy_from, fy_to = fy_range(fy)
    company = _company_ctx.get()
    is_rb = (company == "rainbow")
    if inv_type == "GST":
        pfx = "RU" if is_rb else "R"
        rgx = r"^RU\d" if is_rb else r"^R\d"
        skip = 2 if is_rb else 1
        pipeline = [
            {"$match": {
                "InvoiceNo": {"$regex": rgx},
                "$or": [{"FY": fy}, {"$and": [{"FY": None}, {"InvoiceDate": {"$gte": fy_from, "$lte": fy_to}}]}]
            }},
            {"$project": {"num": {"$toInt": {"$substr": ["$InvoiceNo", skip, 10]}}}},
            {"$group": {"_id": None, "max": {"$max": "$num"}}}
        ]
        res = list(col("sales_invoices").aggregate(pipeline))
        n = (res[0]["max"] if res else 0) + 1
        return f"{pfx}{n:02d}"
    else:
        pfx2 = "RUN" if is_rb else "RN"
        rgx2 = r"^RUN" if is_rb else r"^RN"
        skip2 = 3 if is_rb else 2
        pipeline = [
            {"$match": {
                "InvoiceNo": {"$regex": rgx2},
                "$or": [{"FY": fy}, {"$and": [{"FY": None}, {"InvoiceDate": {"$gte": fy_from, "$lte": fy_to}}]}]
            }},
            {"$project": {"num": {"$toInt": {"$substr": ["$InvoiceNo", skip2, 10]}}}},
            {"$group": {"_id": None, "max": {"$max": "$num"}}}
        ]
        res = list(col("sales_invoices").aggregate(pipeline))
        n = (res[0]["max"] if res else 0) + 1
        return f"{pfx2}{n:02d}"

def next_quotation_no(q_type: str, fy: str) -> str:
    fy_from, fy_to = fy_range(fy)
    if q_type == "GST":
        pipeline = [
            {"$match": {"QuotationNo": {"$regex": r"^Q\d"}, "QuotationDate": {"$gte": fy_from, "$lte": fy_to}}},
            {"$project": {"num": {"$toInt": {"$substr": ["$QuotationNo", 1, 10]}}}},
            {"$group": {"_id": None, "max": {"$max": "$num"}}}
        ]
        res = list(col("quotations").aggregate(pipeline))
        n = (res[0]["max"] if res else 0) + 1
        return f"Q{n:02d}"
    else:
        pipeline = [
            {"$match": {"QuotationNo": {"$regex": r"^QN"}, "QuotationDate": {"$gte": fy_from, "$lte": fy_to}}},
            {"$project": {"num": {"$toInt": {"$substr": ["$QuotationNo", 2, 10]}}}},
            {"$group": {"_id": None, "max": {"$max": "$num"}}}
        ]
        res = list(col("quotations").aggregate(pipeline))
        n = (res[0]["max"] if res else 0) + 1
        return f"QN{n:02d}"

def next_product_code() -> str:
    pipeline = [
        {"$match": {"Code": {"$regex": r"^P"}}},
        {"$project": {"num": {"$toInt": {"$substr": ["$Code", 1, 10]}}}},
        {"$group": {"_id": None, "max": {"$max": "$num"}}}
    ]
    res = list(col("products").aggregate(pipeline))
    n = (res[0]["max"] if res else 0) + 1
    return f"P{n:03d}"

def next_id(collection_name: str, field: str = "Id") -> int:
    """Atomic ID generation using a counters collection.
    The counter is looked up BY ITS _id (the collection name), but backup files carry no _id: after a restore the counters are gone. A counter that
    does not exist therefore starts AFTER the highest number that already exists in the collection - never at 1 (that would hand out a number that is taken)."""
    cnt = _db["_counters"]
    result = cnt.find_one_and_update({"_id": collection_name}, {"$inc": {"seq": 1}}, return_document=True)
    if result is None:
        res = list(_db[collection_name].aggregate([{"$group": {"_id": None, "max": {"$max": f"${field}"}}}]))
        mx = to_int(res[0]["max"], 0) if res and res[0].get("max") is not None else 0
        cnt.update_one({"_id": collection_name}, {"$setOnInsert": {"seq": mx}}, upsert=True)      # atomic and harmless if two requests get here together
        result = cnt.find_one_and_update({"_id": collection_name}, {"$inc": {"seq": 1}}, return_document=True)
    return result["seq"]


def raise_counters_to_data():
    """A counter must never be BEHIND the data (an earlier restore, or a counter that started at 1, can leave it low): raise it to the highest existing number.
    Never lowers a counter. Runs at every start."""
    try:
        for d in list(_db["_counters"].find({}, {"_id": 1, "seq": 1})):
            c = d.get("_id")
            if not isinstance(c, str):
                continue                                           # the id-less documents a restore leaves behind
            field = "SNo" if c == "sales_records" else "Id"
            res = list(_db[c].aggregate([{"$group": {"_id": None, "max": {"$max": f"${field}"}}}]))
            mx = to_int(res[0]["max"], 0) if res and res[0].get("max") is not None else 0
            if mx and mx > (to_int(d.get("seq"), 0) or 0):
                _db["_counters"].update_one({"_id": c, "seq": {"$lt": mx}}, {"$set": {"seq": mx}})     # only if it is still behind (safe with two requests)
                logger.warning(f"counter '{c}' was behind the data ({d.get('seq')} < {mx}): raised")
    except Exception as e:
        logger.warning(f"raise_counters_to_data error (non-fatal): {e}")


def reseed_counters():
    """After a restore: rebuild ALL number counters from the data (the backup file has none that can be used, see next_id)."""
    try:
        names = _db.list_collection_names()
        _db["_counters"].delete_many({})
        for c in names:
            if c.startswith("_") or c.startswith("system."):
                continue
            field = "SNo" if c == "sales_records" else "Id"
            res = list(_db[c].aggregate([{"$group": {"_id": None, "max": {"$max": f"${field}"}}}]))
            if res and res[0].get("max") is not None:
                _db["_counters"].update_one({"_id": c}, {"$set": {"seq": to_int(res[0]["max"], 0) or 0}}, upsert=True)
    except Exception as e:
        logger.warning(f"reseed_counters error (non-fatal): {e}")

async def require_db():
    """Call at the start of every endpoint to ensure DB is ready."""
    if not await ensure_db():
        raise Exception("Database not connected")

def init_indexes():
    """Create indexes for fast queries."""
    try:
        _db["sales_records"].create_index([("SNo", DESCENDING)])
        _db["daily_expenses"].create_index([("ExpDate", DESCENDING)])
        _db["sales_invoices"].create_index([("InvoiceDate", DESCENDING)])
        _db["quotations"].create_index([("QuotationDate", DESCENDING)])
        logger.info("Indexes created")
    except Exception as e:
        logger.warning(f"Index creation (non-fatal): {e}")

def init_counters():
    """Seed counters from current max IDs in each collection."""
    collections = [
        ("sales_records", "SNo"), ("daily_expenses", "Id"),
        ("notes", "Id"), ("followups", "Id"), ("rio_clients", "Id"),
        ("expense_categories", "Id"), ("jobs", "Id"), ("account_balances", "Id"),
        ("account_ledger", "Id"), ("products", "Id"), ("sales_invoices", "Id"),
        ("quotations", "Id"),
    ]
    for coll_name, field in collections:
        existing = _db["_counters"].find_one({"_id": coll_name})
        if not existing:
            pipeline = [{"$group": {"_id": None, "max": {"$max": f"${field}"}}}]
            res = list(_db[coll_name].aggregate(pipeline))
            max_val = to_int(res[0]["max"]) if res and res[0].get("max") is not None else 0
            _db["_counters"].update_one(
                {"_id": coll_name},
                {"$setOnInsert": {"seq": max_val}},
                upsert=True
            )

def set_sales_ledger_credits(sno: int, customer: str, job_name: str, payments: list):
    """Delete old ledger entries for a sales record and recreate them.
    After recreating, recalculate running balances for all affected accounts."""
    col("account_ledger").delete_many({"SalesRef": sno})
    affected = set()  # track which (account, fy) pairs need rebalancing
    for pay in payments:
        amt  = to_float(pay.get("Amt"))
        dt   = (pay.get("Date") or "").strip()
        mode = (pay.get("Mode") or "").strip()
        if not amt or amt <= 0 or not dt:
            continue
        acct_map = {
            "KVB MOM":     "KVB MOM",
            "KVB Mani":    "KVB Mani",
            "Indian Bank": "Indian Bank",
            "Cash":        "Cash Balance",
        }
        acct = acct_map.get(mode)
        if not acct:
            continue
        fy = fy_from_date(dt)
        if not fy:
            continue
        jn_str = f" — {job_name}" if job_name else ""
        desc = f"Sales: {customer}{jn_str}"
        col("account_ledger").insert_one({
            "Id": next_id("account_ledger"), "AccountName": acct, "EntryDate": dt,
            "Description": desc, "CreditAmt": amt, "DebitAmt": 0,
            "Balance": 0, "EntryType": "Credit", "FY": fy,
            "ExpenseRef": None, "SalesRef": sno
        })
        affected.add((acct, fy))
    # Recalculate running balances for all affected accounts
    for acct, fy in affected:
        recalc_ledger_balances(acct, fy)

def recalc_ledger_balances(account_name: str, fy: str):
    """
    Recalculate running balances for all entries of an account in a given FY,
    sorted by EntryDate then Id. Called after any edit or delete of a ledger entry
    to ensure the Balance column stays accurate throughout.
    """
    entries = list(col("account_ledger").find(
        {"AccountName": account_name, "FY": fy},
        sort=[("EntryDate", ASCENDING), ("Id", ASCENDING)]
    ))
    if not entries:
        return
    running = 0.0
    for entry in entries:
        running += to_float(entry.get("CreditAmt", 0))
        running -= to_float(entry.get("DebitAmt", 0))
        col("account_ledger").update_one(
            {"_id": entry["_id"]},
            {"$set": {"Balance": round(running, 2)}}
        )

# ─────────────────────────────────────────────
#  APP STARTUP
# ─────────────────────────────────────────────
_db_connected = False  # track real connection state

def _mongo_tls(uri):
    """Atlas (mongodb+srv) needs TLS; a MongoDB running on this same PC normally does not.
    Set MONGO_TLS=0 or MONGO_TLS=1 in .env to force either way."""
    forced = os.environ.get("MONGO_TLS")
    if forced is not None and forced.strip() != "":
        return forced.strip().lower() not in ("0", "false", "no", "off")
    return not re.match(r"mongodb://(?:[^@/]*@)?(?:localhost|127\.0\.0\.1|\[::1\])(?::\d+)?(?:[/?]|$)", uri or "", re.I)

def _connect_mongo():
    """Attempt MongoDB connection. Returns True on success, False on failure."""
    global _client, _db, _db_connected
    if not MONGO_URI:
        logger.error("=" * 60)
        logger.error("MONGO_URI IS NOT SET!")
        logger.error("Go to Render → your service → Environment → Add:")
        logger.error("  MONGO_URI = mongodb+srv://user:pass@cluster...")
        logger.error("  MONGO_DB  = RioPrintMedia")
        logger.error("Then click Save and Manual Deploy")
        logger.error("=" * 60)
        _db_connected = False
        return False
    # Mask password for safe logging
    safe_uri = re.sub(r':(.*?)@', ':***@', MONGO_URI) if MONGO_URI else MONGO_URI
    _use_tls = _mongo_tls(MONGO_URI)
    logger.info(f"Connecting to MongoDB ({'with TLS' if _use_tls else 'no TLS, local'})...")
    logger.info(f"URI: {safe_uri}")
    logger.info(f"DB:  {MONGO_DB}")
    try:
        _client = MongoClient(
            MONGO_URI,
            serverSelectionTimeoutMS=25000,
            connectTimeoutMS=25000,
            socketTimeoutMS=30000,
            tls=_use_tls,
            retryWrites=True,
        )
        logger.info("MongoClient created, pinging MongoDB...")
        _client.admin.command("ping")
        _db = _client[MONGO_DB]
        _db_connected = True
        logger.info(f"✓ MongoDB connected: {MONGO_DB}")
        return True
    except Exception as e:
        _db_connected = False
        err_str = str(e)
        logger.error(f"✗ MongoDB connection FAILED: {err_str}")
        if "Authentication failed" in err_str or "auth" in err_str.lower():
            logger.error("→ CHECK: Username and password in MONGO_URI")
            logger.error("→ Special chars in password must be URL-encoded (@ = %40)")
        elif "network" in err_str.lower() or "timeout" in err_str.lower() or "timed out" in err_str.lower():
            logger.error("→ CHECK: MongoDB Atlas Network Access")
            logger.error("→ Go to Atlas → Network Access → Add IP: 0.0.0.0/0 (Allow All)")
            logger.error("→ Render uses dynamic IPs, so 0.0.0.0/0 is required")
        elif "SSL" in err_str or "TLS" in err_str:
            logger.error("→ SSL/TLS error — check Atlas cluster TLS settings")
        logger.error(f"→ URI used (masked): {safe_uri[:60]}...")
        return False

@asynccontextmanager
async def lifespan(app: FastAPI):
    # DO NOT raise — keep server alive even if DB is temporarily down.
    # Render cold starts can be slow; server retries on first real request.
    connected = _connect_mongo()
    if connected:
        try:
            init_indexes()
            logger.info("Indexes ready")
        except Exception as e:
            logger.warning(f"init_indexes error (non-fatal): {e}")
        try:
            init_counters()
            logger.info("Counters initialised")
        except Exception as e:
            logger.warning(f"init_counters error (non-fatal): {e}")
        raise_counters_to_data()
        try:
            ensure_default_users()
            logger.info("Users ready")
        except Exception as e:
            logger.warning(f"ensure_default_users error (non-fatal): {e}")
        try:
            ensure_default_debt_loan_auth()
            logger.info("Debt & Loan auth ready")
        except Exception as e:
            logger.warning(f"ensure_default_debt_loan_auth error (non-fatal): {e}")
    else:
        logger.warning("Server started WITHOUT DB — will retry on first request")
    yield
    if _client:
        _client.close()
        logger.info("MongoDB connection closed")

app = FastAPI(title="RIO PRINT MEDIA ERP v3.0", lifespan=lifespan)

# ── Build/version marker ─────────────────────────────────────────
# Bump this string every time this file is packaged, so it's possible
# to confirm from the browser console (fetch('/api/version')) exactly
# which build is actually running on the live server — instead of
# guessing from behavior when something looks stale or cached.
BUILD_VERSION = "v95-2026-07-03"

@app.get("/api/version")
async def get_version():
    # api_level / api_build let the page check it is talking to a server new enough for it (see rioCheckServerLevel)
    return {"build": BUILD_VERSION, "mobile_toggle_route": True, "api_level": API_LEVEL, "api_build": API_BUILD}

@app.put("/api/quotations/{qid}")
async def update_quotation(qid: str, request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    try:
        data = await request.json()
        data.pop("_id", None)
        items = data.get("Items", [])
        for item in items:
            item["TaxableValue"] = to_float(item.get("TaxableValue"))
            item["GSTRate"]      = to_float(item.get("GSTRate"))
            item["Total"]        = to_float(item.get("Total"))
        from bson import ObjectId
        col("quotations").update_one(
            {"_id": ObjectId(qid)},
            {"$set": data}
        )
        return {"success": True, "quotationNo": data.get("QuotationNo", "")}
    except Exception as e:
        return err(str(e), 500)


@app.middleware("http")
async def set_company_context(request, call_next):
    company = request.query_params.get("company", "rio")
    token = _company_ctx.set("rainbow" if company == "rainbow" else "rio")
    try:
        response = await call_next(request)
    finally:
        _company_ctx.reset(token)
    return response

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

def ok(data=None, **kwargs):
    if data is not None:
        return JSONResponse(content=data)
    return JSONResponse(content={"ok": True, **kwargs})

def err(msg, status=400):
    return JSONResponse(content={"error": msg}, status_code=status)

# ─────────────────────────────────────────────
#  LIVE HTML PATCHER — applied every request
# ─────────────────────────────────────────────
# ─────────────────────────────────────────────
#  SERVE HTML DASHBOARD
# ─────────────────────────────────────────────
# ── In-memory HTML cache ────────────────────────────────────────
# The main dashboard HTML is several MB. Re-reading it from disk on
# every single page load means every concurrent request holds its own
# full copy in memory at once — on Render's free 512MB tier, a handful
# of simultaneous loads can be enough to trigger an OOM kill (which
# shows up to users as every endpoint suddenly returning 502). Loading
# it once at startup and reusing the same string avoids that entirely,
# and is also faster since there's no disk I/O per request.
_HTML_CACHE = {}

def _load_html_cached(file_path):
    if file_path in _HTML_CACHE:
        return _HTML_CACHE[file_path]
    if not os.path.exists(file_path):
        return None
    with open(file_path, "r", encoding="utf-8") as f:
        content = f.read()
    _HTML_CACHE[file_path] = content
    logger.info(f"Cached {file_path} in memory ({len(content)} bytes)")
    return content


# The pages are always revalidated by the browser, so that an updated page is never replaced by an old copy from the cache.
_NO_CACHE = {"Cache-Control": "no-cache"}

@app.get("/", response_class=HTMLResponse)
async def serve_dashboard(request: Request):
    html = _load_html_cached(HTML_FILE)
    if html is None:
        logger.error(f"HTML file not found: {HTML_FILE} — cwd={os.getcwd()}")
        return HTMLResponse(f"<h2>File not found: {HTML_FILE}</h2><p>CWD: {os.getcwd()}</p><p>Files: {os.listdir('.')[:20]}</p>", 404)
    return HTMLResponse(html, headers=_NO_CACHE)

@app.get("/mobile", response_class=HTMLResponse)
async def serve_mobile(request: Request):
    mobile_file = os.environ.get("MOBILE_FILE", "RIO_MOBILE.html")
    html = _load_html_cached(mobile_file)
    if html is None:
        return HTMLResponse(f"<h2>Mobile file not found: {mobile_file}</h2><p>CWD: {os.getcwd()}</p>", 404)
    return HTMLResponse(html, headers=_NO_CACHE)

@app.get("/stock", response_class=HTMLResponse)
async def serve_stock_mobile(request: Request):
    """Standalone, login-free Stock Ledger tool for production staff — same
    backend/DB as desktop and the main mobile app, just a single-purpose UI."""
    stock_file = os.environ.get("STOCK_MOBILE_FILE", "RIO_STOCK_MOBILE.html")
    html = _load_html_cached(stock_file)
    if html is None:
        return HTMLResponse(f"<h2>Stock mobile file not found: {stock_file}</h2><p>CWD: {os.getcwd()}</p>", 404)
    return HTMLResponse(html, headers=_NO_CACHE)

# ── CMY tools: real server-side protection, admin role only ────────────
# Unlike a password check baked into a standalone HTML file's own
# JavaScript (readable/bypassable by anyone who opens dev tools), this
# verifies the session token against the database on every request, the
# same way any other protected API call would. A token only exists after
# a real login through /api/auth/login, and is checked here server-side —
# not just hidden client-side — so there's no way to reach the tool
# without actually being logged in as admin, regardless of what a person
# does in their own browser.
def verify_admin_token(token: str):
    if not token:
        return None
    user = _db["rio_users"].find_one({"session_token": token}, {"_id": 0})
    if not user:
        return None
    if (user.get("role") or "").lower() != "admin":
        return None
    return user

def verify_user_token(token: str):
    """Same real server-side session check as verify_admin_token, but for
    any logged-in user, not just admins — Renu Contacts is a regular
    feature, not an admin-only tool."""
    if not token:
        return None
    user = _db["rio_users"].find_one({"session_token": token}, {"_id": 0})
    if not user:
        return None
    return user

# ── Server-side admin check for sensitive routes ─────────────────────────────────────────────
# The page already sends the login token as "Authorization: Bearer <token>". These helpers verify it
# against the database, so a sensitive action cannot be reached just by calling the URL directly -
# hiding a button in the page is not protection. EMERGENCY SWITCH: set the environment variable
# RIO_ENFORCE_ADMIN=0 on Render to turn the check off if it ever locks the owner out.
API_LEVEL = 3          # bump only when the page starts depending on new server behaviour (2 = invoice duplicate-number tools, 3 = remove-duplicate route + delete of the last printed invoice)
API_BUILD = "v293"

def _enforce_admin() -> bool:
    return os.getenv("RIO_ENFORCE_ADMIN", "1").strip() != "0"

def _bearer_token(request: Request) -> str:
    h = (request.headers.get("authorization") or "").strip()
    return h[7:].strip() if h.lower().startswith("bearer ") else ""

async def admin_guard(request: Request):
    """None if the caller may proceed, otherwise the error response to return."""
    if not _enforce_admin(): return None
    if not await ensure_db(): return err("Database not connected", 503)
    tok = _bearer_token(request)
    if not tok:
        return err("Login required - no session token was sent. Please log out and log in again.", 401)
    me = _db["rio_users"].find_one({"session_token": tok}, {"_id": 0})
    if not me:
        return err("Your session has expired (it also ends when the same user logs in somewhere else). Please log out and log in again.", 401)
    if (me.get("role") or "").lower() != "admin":
        return err("Admin access is required for this action.", 403)
    return None

def _access_denied_page(reason: str):
    return HTMLResponse(f"""<!DOCTYPE html><html><head><meta charset="UTF-8">
<title>Access Denied</title>
<style>body{{background:#16171a;color:#e8e6e1;font-family:'Nunito',sans-serif;
display:flex;align-items:center;justify-content:center;height:100vh;margin:0;text-align:center;}}
.box{{max-width:420px;padding:32px;}}
h1{{font-size:1.3rem;margin-bottom:12px;}}
p{{color:#8a8d94;font-size:0.9rem;line-height:1.6;}}</style></head>
<body><div class="box"><h1>🔒 Access Denied</h1><p>{reason}</p>
<p>Please open this tool from within the Rio ERP (logged in as an admin), not as a direct link.</p></div></body></html>""", status_code=403)

@app.get("/cmy-tool", response_class=HTMLResponse)
async def serve_cmy_tool(request: Request, token: str = ""):
    if not await ensure_db():
        return _access_denied_page("Database not connected — please try again in a moment.")
    if not verify_admin_token(token):
        return _access_denied_page("This tool is restricted to admin accounts, and your session could not be verified.")
    cmy_file = os.environ.get("CMY_TOOL_FILE", "CMY_Color_Correction.html")
    html = _load_html_cached(cmy_file)
    if html is None:
        return HTMLResponse(f"<h2>CMY tool file not found: {cmy_file}</h2><p>CWD: {os.getcwd()}</p>", 404)
    return HTMLResponse(html, headers=_NO_CACHE)

@app.get("/cmy-layer-proof", response_class=HTMLResponse)
async def serve_cmy_layer_proof(request: Request, token: str = ""):
    if not await ensure_db():
        return _access_denied_page("Database not connected — please try again in a moment.")
    if not verify_admin_token(token):
        return _access_denied_page("This tool is restricted to admin accounts, and your session could not be verified.")
    layer_file = os.environ.get("CMY_LAYER_TOOL_FILE", "CMY_Layer_Proof_PSD.html")
    html = _load_html_cached(layer_file)
    if html is None:
        return HTMLResponse(f"<h2>CMY Layer Proof file not found: {layer_file}</h2><p>CWD: {os.getcwd()}</p>", 404)
    return HTMLResponse(html, headers=_NO_CACHE)

@app.get("/renu-contacts", response_class=HTMLResponse)
async def serve_renu_contacts(request: Request):
    """Standalone Renu Contacts page — separate URL, separate HTML file,
    own DB collection. No login required by design: opening this URL
    directly (e.g. rio-print-media.onrender.com/renu-contacts) shows the
    page immediately, on both desktop and mobile."""
    if not await ensure_db():
        return _access_denied_page("Database not connected — please try again in a moment.")
    renu_file = os.environ.get("RENU_CONTACTS_FILE", "Renu_Contacts.html")
    html = _load_html_cached(renu_file)
    if html is None:
        return HTMLResponse(f"<h2>Renu Contacts file not found: {renu_file}</h2><p>CWD: {os.getcwd()}</p>", 404)
    return HTMLResponse(html, headers=_NO_CACHE)

@app.get("/debt-and-loan", response_class=HTMLResponse)
async def serve_debt_and_loan(request: Request):
    """Standalone Debt & Loan tracker — separate URL, separate HTML file,
    own DB collections, and its OWN independent login (not the main
    rio_users accounts). The page itself loads freely so its login form
    can display; the actual protection is enforced API-side, on every
    /api/debt-members and /api/debt-transactions call, via a token this
    page's own login endpoint issues."""
    if not await ensure_db():
        return _access_denied_page("Database not connected — please try again in a moment.")
    dl_file = os.environ.get("DEBT_LOAN_FILE", "Debt_and_Loan.html")
    html = _load_html_cached(dl_file)
    if html is None:
        return HTMLResponse(f"<h2>Debt and Loan file not found: {dl_file}</h2><p>CWD: {os.getcwd()}</p>", 404)
    return HTMLResponse(html, headers=_NO_CACHE)

@app.get("/pay", response_class=HTMLResponse)
async def redirect_to_upi(pa: str = "", pn: str = "", am: str = "", tn: str = "", cu: str = "INR"):
    """Shows explicit GPay / PhonePe / Paytm / Other-UPI-app buttons rather
    than auto-redirecting straight to the generic upi:// scheme. Auto-
    redirecting hands the choice to the phone's OS-level "default app for
    this link type" setting - which is very often the bank's own app
    (many bank apps register as UPI handlers too), not a real chooser.
    Giving separate buttons, each using that app's own deep-link scheme,
    means the customer picks the app themselves instead of the OS
    deciding silently on their behalf."""
    import html as html_module
    # This route is publicly reachable, so every query param must be
    # HTML-escaped before being embedded in the response - otherwise
    # anyone could craft a /pay?pn=<script>... URL and have it execute.
    safe_pa, safe_pn, safe_am, safe_tn, safe_cu = (html_module.escape(v) for v in (pa, pn, am, tn, cu))

    def build_params(extra=""):
        params = [f"pa={safe_pa}", f"pn={safe_pn}", f"cu={safe_cu}"]
        if safe_am:
            params.append(f"am={safe_am}")
        if safe_tn:
            params.append(f"tn={safe_tn}")
        return "&".join(params) + extra

    upi_generic = "upi://pay?" + build_params()
    gpay_link = "tez://upi/pay?" + build_params()
    phonepe_link = "phonepe://pay?" + build_params()
    paytm_link = "paytmmp://pay?" + build_params()

    amount_line = f"Amount: ₹{safe_am}" if safe_am else "You'll be asked to enter the amount"
    # QR image rendered via a free QR-generation image API (no JS library
    # needed) - encodes the same generic UPI link, so scanning it with
    # any UPI app's own QR scanner works exactly like tapping the link.
    from urllib.parse import quote as _urlquote
    qr_img_url = "https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=" + _urlquote(upi_generic)
    html_out = f"""<!DOCTYPE html>
<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pay {safe_pn}</title>
<style>
  body {{ font-family: -apple-system, sans-serif; text-align:center; padding:40px 20px; background:#f0f2f8; margin:0; }}
  .card {{ background:white; border-radius:14px; padding:28px 20px; max-width:360px; margin:0 auto; box-shadow:0 4px 20px rgba(0,0,0,0.08); }}
  h2 {{ margin:0 0 4px; font-size:1.1rem; color:#1a1a2e; }}
  p.sub {{ color:#888; font-size:0.85rem; margin:0 0 24px; }}
  a.app-btn, button.app-btn {{ display:flex; align-items:center; justify-content:center; gap:10px; height:48px; border-radius:10px; margin-bottom:12px; text-decoration:none; font-weight:700; font-size:0.9rem; border:none; width:100%; cursor:pointer; font-family:inherit; }}
  .gpay {{ background:#fff; border:1.5px solid #ddd; color:#1a1a2e; }}
  .phonepe {{ background:#5f259f; color:white; }}
  .paytm {{ background:#00baf2; color:white; }}
  .other {{ background:#f5f5f5; color:#555; border:1.5px solid #ddd; }}
  .qrbtn {{ background:white; color:#2e7d32; border:1.5px solid #2e7d32; }}
  .bankbtn {{ background:white; color:#1565c0; border:1.5px solid #1565c0; }}
  .bankgo {{ background:#1565c0; color:white; margin-top:8px; height:40px; }}
  #qr-box {{ display:none; margin-top:6px; }}
  #qr-box img {{ border-radius:10px; border:1.5px solid #eee; }}
  #bank-box {{ display:none; margin-top:6px; text-align:left; }}
  #bank-select {{ width:100%; height:44px; border:1.5px solid #ddd; border-radius:8px; padding:0 12px; font-size:0.85rem; font-family:inherit; margin-bottom:8px; }}
</style>
</head>
<body>
<div class="card">
<h2>Pay {safe_pn}</h2>
<p class="sub">{amount_line}</p>
<a class="app-btn gpay" href="{gpay_link}">Pay with GPay</a>
<a class="app-btn phonepe" href="{phonepe_link}">Pay with PhonePe</a>
<a class="app-btn paytm" href="{paytm_link}">Pay with Paytm</a>
<a class="app-btn other" href="{upi_generic}">Other UPI App</a>
<button class="app-btn qrbtn" onclick="document.getElementById('qr-box').style.display = document.getElementById('qr-box').style.display === 'none' ? 'block' : 'none';">Show &amp; Scan QR</button>
<div id="qr-box"><img src="{qr_img_url}" width="220" height="220" alt="UPI QR code"><p style="font-size:0.7rem;color:#888;margin-top:8px;">Scan this with any UPI app's camera/QR scanner</p></div>

<button class="app-btn bankbtn" onclick="document.getElementById('bank-box').style.display = document.getElementById('bank-box').style.display === 'none' ? 'block' : 'none';">Open Mobile Banking</button>
<div id="bank-box">
  <select id="bank-select">
    <option value="">Select your bank…</option>
    <option value="sbiyono://">SBI (YONO)</option>
    <option value="hdfcbank://">HDFC Bank</option>
    <option value="icicibank://">ICICI Bank (iMobile)</option>
    <option value="axismobile://">Axis Bank</option>
    <option value="kotak811://">Kotak Mahindra Bank</option>
    <option value="pnbone://">Punjab National Bank</option>
    <option value="indianbank://">Indian Bank</option>
  </select>
  <button class="app-btn bankgo" onclick="openBankApp()">Go</button>
  <p id="bank-error" style="font-size:0.72rem;color:#c62828;margin-top:8px;display:none;"></p>
  <p style="font-size:0.65rem;color:#aaa;margin-top:8px;">Note: this opens your bank's own app to make a transfer manually — it won't carry over the amount or payee automatically like the UPI options above.</p>
</div>

<p style="font-size:0.7rem;color:#aaa;margin-top:16px;">If a button doesn't open its app, that app may not be installed - try another option above.</p>
</div>
<script>
function openBankApp() {{
  const scheme = document.getElementById('bank-select').value;
  const errEl = document.getElementById('bank-error');
  errEl.style.display = 'none';
  if (!scheme) {{ errEl.textContent = 'Select a bank first'; errEl.style.display = 'block'; return; }}
  // There's no reliable way for a web page to confirm whether a specific
  // app is actually installed - browsers intentionally don't expose that
  // (it would be a fingerprinting/privacy risk). This timeout-based
  // approach is the common workaround: attempt the app link, and if the
  // page is still visible after ~1.5s (meaning nothing intercepted it
  // and took over), assume the app isn't installed and show a message.
  // It's an approximation, not a guarantee.
  let appOpened = false;
  window.addEventListener('blur', function onBlur() {{ appOpened = true; window.removeEventListener('blur', onBlur); }});
  window.location.href = scheme;
  setTimeout(() => {{
    if (!appOpened) {{
      errEl.textContent = "This bank's app doesn't seem to be installed, or doesn't support this link.";
      errEl.style.display = 'block';
    }}
  }}, 1500);
}}
</script>
</body></html>"""
    return HTMLResponse(html_out)

@app.get("/ledger", response_class=HTMLResponse)
async def serve_ledger(request: Request):
    """Standalone ledger diagnostic page"""
    LEDGER_FILE = "RIO_PRINT_MEDIA_ERP_ledger.html"
    if not os.path.exists(LEDGER_FILE):
        return HTMLResponse(f"<h2>Ledger file not found: {LEDGER_FILE}</h2>", 404)
    with open(LEDGER_FILE, "r", encoding="utf-8") as f:
        html = f.read()
    return HTMLResponse(html, headers=_NO_CACHE)

# ─────────────────────────────────────────────
#  MOBILE APP
# ─────────────────────────────────────────────


@app.post("/api/log")
async def client_log(request: Request):
    try:
        body = await request.json()
    except Exception:
        return JSONResponse(content={"ok": False}, status_code=400)
    level   = str(body.get("level",  "INFO")).upper()
    user    = str(body.get("user",   "unknown"))
    action  = str(body.get("action", ""))
    detail  = str(body.get("detail", ""))
    msg = f"[CLIENT] user={user} | {action} | {detail}"
    if level == "ERROR":
        logger.error(msg)
    elif level == "WARN":
        logger.warning(msg)
    else:
        logger.info(msg)
    return {"ok": True}


@app.get("/api/ping")
async def ping():
    connected = await ensure_db()
    if not connected:
        return JSONResponse(
            content={"ok": False, "error": "MongoDB not connected. Check MONGO_URI on Render.", "db": MONGO_DB},
            status_code=503
        )
    # ensure_db() already verified the connection with a fresh ping internally
    # (in a worker thread) — no need to block the event loop again here.
    return {"ok": True, "db": MONGO_DB, "server": "MongoDB Atlas", "connected": True}

@app.get("/api/companies")
def list_companies():
    return JSONResponse({"companies":[{"id":"rio","name":"RIO PRINT MEDIA"},{"id":"rainbow","name":"RAINBOW UMBRELLAS"}]})

@app.post("/api/sync-rainbow")
def sync_rainbow():
    if not _client: return JSONResponse({"ok":False,"error":"DB not connected"},status_code=503)
    rio_db=_client[MONGO_DB]; rb_db=_client[MONGO_DB_RAINBOW]
    results={}
    for c in ["clients","rio_clients","products","categories","sizes"]:
        try:
            docs=list(rio_db[c].find({},{"_id":0}))
            if docs: rb_db[c].delete_many({}); rb_db[c].insert_many(docs); results[c]=len(docs)
            else: results[c]=0
        except Exception as e: results[c]=f"err:{e}"
    return JSONResponse({"ok":True,"synced":results})

@app.get("/api/debug")
async def debug_info():
    """Public debug endpoint — shows connection state without exposing credentials"""
    safe_uri = re.sub(r':(.*?)@', ':***@', MONGO_URI) if MONGO_URI else "NOT SET"
    return JSONResponse(content={
        "mongo_uri_set": bool(MONGO_URI),
        "mongo_uri_masked": safe_uri[:80] if MONGO_URI else "NOT SET",
        "mongo_db": MONGO_DB,
        "db_connected": _db_connected,
        "hint": "If db_connected=false, go to MongoDB Atlas → Network Access → Add 0.0.0.0/0"
    })

# ─────────────────────────────────────────────
#  SALES RECORDS
# ─────────────────────────────────────────────
@app.get("/api/sales")
async def get_sales(
    limit: int = Query(2000, ge=1, le=5000),
    skip: int = Query(0, ge=0),
    fy: Optional[str] = Query(None),
    fr: Optional[str] = Query(None, alias="from"),
    to: Optional[str] = Query(None),
    scope: Optional[str] = Query(None),
    user: Optional[str] = Query(None)
):
    if not await ensure_db():
        return JSONResponse(content=[], status_code=503)
    try:
        query = {}
        if fy:
            fy_from, fy_to = fy_range(fy)
            if fy_from and fy_to:
                query = {"$or": [
                    {"FY": fy},
                    {"$and": [{"FY": {"$in": [None, ""]}}, {"OrderDate": {"$gte": fy_from, "$lte": fy_to}}]}
                ]}
        if fr or to:
            # OrderDate stored as YYYY-MM-DD — filter by range
            date_q = {}
            if fr: date_q["$gte"] = fr
            if to: date_q["$lte"] = to
            if query:
                query = {"$and": [query, {"OrderDate": date_q}]}
            else:
                query["OrderDate"] = date_q
        if scope == "own" and user:
            query["createdBy"] = user
        rows = list(col("sales_records").find(query, {"_id": 0})
                    .sort("SNo", DESCENDING).skip(skip).limit(limit))
        return JSONResponse(content=rows)
    except Exception as e:
        logger.error(f"get_sales error: {e}")
        return JSONResponse(content=[], status_code=500)

def _sanitize_sale_items(items):
    """Validates/cleans the Rio dynamic multi-product Items array before storage.
    Unlimited products (Add Product button) — each item is a distinct product row
    with its own size/qty/rate/GST rate, unlike the old fixed Size1/2/3 fields."""
    if not isinstance(items, list):
        return []
    out = []
    for it in items:
        if not isinstance(it, dict):
            continue
        qty = to_float(it.get("Qty"), 0.0)
        rate = to_float(it.get("Rate"), 0.0)
        if not (it.get("ProductId") or qty or rate):
            continue
        out.append({
            "ProductId":   it.get("ProductId", ""),
            "ProductName": it.get("ProductName", ""),
            "HSN":         it.get("HSN", ""),
            "Size":        it.get("Size", ""),
            "Qty":         qty,
            "Rate":        rate,
            "Amt":         to_float(it.get("Amt"), 0.0),
            "GSTRate":     to_float(it.get("GSTRate"), 0.0),
        })
    return out

@app.post("/api/sales")
async def post_sales(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    sno = next_id("sales_records", "SNo")
    doc = {
        "SNo": sno,
        "createdBy":          b.get("createdBy", ""),
        "Customer":           b.get("Customer", ""),
        "Category":           b.get("Category", ""),
        "ProductSize":        b.get("ProductSize", ""),
        "Size1":              b.get("Size1", ""),
        "Qty1":               b.get("Qty1", ""),
        "Size2":              b.get("Size2", ""),
        "Qty2":               b.get("Qty2", ""),
        "Size3":              b.get("Size3", ""),
        "Qty3":               b.get("Qty3", ""),
        "Items":              _sanitize_sale_items(b.get("Items")),
        "BillingType":        b.get("BillingType", ""),
        "JobName":            b.get("JobName", ""),
        "OrderDate":          b.get("OrderDate"),
        "TotalAmount":        to_float(b.get("TotalAmount")),
        "AdvanceAmt":         to_float(b.get("AdvanceAmt")),
        "AdvanceDate":        b.get("AdvanceDate"),
        "AdvanceMode":        b.get("AdvanceMode", ""),
        "AdvanceActualMode":        str(b.get("AdvanceActualMode", "") or "").strip(),
        "AdvanceDetails":     b.get("AdvanceDetails", ""),
        "BalanceSettledAmt":  to_float(b.get("BalanceSettledAmt")),
        "BalanceDate":        b.get("BalanceDate"),
        "BalanceMode":        b.get("BalanceMode", ""),
        "BalanceActualMode":        str(b.get("BalanceActualMode", "") or "").strip(),
        "Balance1Details":    b.get("Balance1Details", ""),
        "Balance2Amt":        to_float(b.get("Balance2Amt")),
        "Balance2Date":       b.get("Balance2Date"),
        "Balance2Mode":       b.get("Balance2Mode", ""),
        "Balance2ActualMode":       str(b.get("Balance2ActualMode", "") or "").strip(),
        "Balance2Details":    b.get("Balance2Details", ""),
        "Balance3Amt":        to_float(b.get("Balance3Amt")),
        "Balance3Date":       b.get("Balance3Date"),
        "Balance3Mode":       b.get("Balance3Mode", ""),
        "Balance3ActualMode":       str(b.get("Balance3ActualMode", "") or "").strip(),
        "Balance3Details":    b.get("Balance3Details", ""),
        "Balance4Amt":        to_float(b.get("Balance4Amt")),
        "Balance4Date":       b.get("Balance4Date"),
        "Balance4Mode":       b.get("Balance4Mode", ""),
        "Balance4ActualMode":       str(b.get("Balance4ActualMode", "") or "").strip(),
        "Balance4Details":    b.get("Balance4Details", ""),
        "RemainingBalance":   to_float(b.get("RemainingBalance")),
        "CustomerGST":        b.get("CustomerGST", ""),
        "CustomerStateCode":  b.get("CustomerStateCode", ""),
        "ProductId":          to_int(b.get("ProductId")),
        "ProductId2":         to_int(b.get("ProductId2")),
        "Rate1":              to_float(b.get("Rate1")),
        "Rate2":              to_float(b.get("Rate2")),
        "Rate3":              to_float(b.get("Rate3")),
        "Amt1":               to_float(b.get("Amt1"), 0.0),
        "Amt2":               to_float(b.get("Amt2"), 0.0),
        "Amt3":               to_float(b.get("Amt3"), 0.0),
        "GSTRate1":           to_float(b.get("GSTRate1"), 0.0),
        "GSTRate2":           to_float(b.get("GSTRate2"), 0.0),
        "GSTRate3":           to_float(b.get("GSTRate3"), 0.0),
        "InvoiceNo":          b.get("InvoiceNo", ""),
        "PFDesc":             b.get("PFDesc", ""),
        "PFAmt":              to_float(b.get("PFAmt"), 0.0),
        "PFGst":              to_float(b.get("PFGst"), 0.0),
        "PFTotal":            to_float(b.get("PFTotal"), 0.0),
        "EyeletQty":          to_float(b.get("EyeletQty"), 0.0),
        "EyeletRate":         to_float(b.get("EyeletRate"), 0.0),
        "EyeletTotal":        to_float(b.get("EyeletTotal"), 0.0),
        "FY":                 fy_from_date(b.get("OrderDate") or datetime.now().strftime("%Y-%m-%d")),
        "UpdatedAt":          datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    col("sales_records").insert_one(doc)
    # Auto-add client
    if doc["Customer"]:
        shared_col("rio_clients").update_one(
            {"ClientName": doc["Customer"]},
            {"$setOnInsert": {"Id": next_id("rio_clients"), "ClientName": doc["Customer"], "createdBy": doc.get("createdBy", "")}},
            upsert=True
        )
    # Ledger credits
    payments = [
        {"Amt": doc["AdvanceAmt"],        "Date": doc["AdvanceDate"],  "Mode": doc["AdvanceMode"]},
        {"Amt": doc["BalanceSettledAmt"], "Date": doc["BalanceDate"],  "Mode": doc["BalanceMode"]},
        {"Amt": doc["Balance2Amt"],       "Date": doc["Balance2Date"], "Mode": doc["Balance2Mode"]},
        {"Amt": doc["Balance3Amt"],       "Date": doc["Balance3Date"], "Mode": doc["Balance3Mode"]},
        {"Amt": doc["Balance4Amt"],       "Date": doc["Balance4Date"], "Mode": doc["Balance4Mode"]},
    ]
    set_sales_ledger_credits(sno, doc["Customer"], doc["JobName"], payments)
    return ok({"ok": True, "SNo": sno})

@app.put("/api/sales/{sno}")
async def put_sales(sno: int, request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    update = {
        "Customer":           b.get("Customer", ""),
        "Category":           b.get("Category", ""),
        "ProductSize":        b.get("ProductSize", ""),
        "Size1":              b.get("Size1", ""),
        "Qty1":               b.get("Qty1", ""),
        "Size2":              b.get("Size2", ""),
        "Qty2":               b.get("Qty2", ""),
        "Size3":              b.get("Size3", ""),
        "Qty3":               b.get("Qty3", ""),
        "Items":              _sanitize_sale_items(b.get("Items")),
        "BillingType":        b.get("BillingType", ""),
        "JobName":            b.get("JobName", ""),
        "OrderDate":          b.get("OrderDate"),
        "TotalAmount":        to_float(b.get("TotalAmount")),
        "AdvanceAmt":         to_float(b.get("AdvanceAmt")),
        "AdvanceDate":        b.get("AdvanceDate"),
        "AdvanceMode":        b.get("AdvanceMode", ""),
        "AdvanceActualMode":        str(b.get("AdvanceActualMode", "") or "").strip(),
        "AdvanceDetails":     b.get("AdvanceDetails", ""),
        "BalanceSettledAmt":  to_float(b.get("BalanceSettledAmt")),
        "BalanceDate":        b.get("BalanceDate"),
        "BalanceMode":        b.get("BalanceMode", ""),
        "BalanceActualMode":        str(b.get("BalanceActualMode", "") or "").strip(),
        "Balance1Details":    b.get("Balance1Details", ""),
        "Balance2Amt":        to_float(b.get("Balance2Amt")),
        "Balance2Date":       b.get("Balance2Date"),
        "Balance2Mode":       b.get("Balance2Mode", ""),
        "Balance2ActualMode":       str(b.get("Balance2ActualMode", "") or "").strip(),
        "Balance2Details":    b.get("Balance2Details", ""),
        "Balance3Amt":        to_float(b.get("Balance3Amt")),
        "Balance3Date":       b.get("Balance3Date"),
        "Balance3Mode":       b.get("Balance3Mode", ""),
        "Balance3ActualMode":       str(b.get("Balance3ActualMode", "") or "").strip(),
        "Balance3Details":    b.get("Balance3Details", ""),
        "Balance4Amt":        to_float(b.get("Balance4Amt")),
        "Balance4Date":       b.get("Balance4Date"),
        "Balance4Mode":       b.get("Balance4Mode", ""),
        "Balance4ActualMode":       str(b.get("Balance4ActualMode", "") or "").strip(),
        "Balance4Details":    b.get("Balance4Details", ""),
        "RemainingBalance":   to_float(b.get("RemainingBalance")),
        "CustomerGST":        b.get("CustomerGST", ""),
        "CustomerStateCode":  b.get("CustomerStateCode", ""),
        "ProductId":          to_int(b.get("ProductId")),
        "ProductId2":         to_int(b.get("ProductId2")),
        "Rate1":              to_float(b.get("Rate1")),
        "Rate2":              to_float(b.get("Rate2")),
        "Rate3":              to_float(b.get("Rate3")),
        "Amt1":               to_float(b.get("Amt1"), 0.0),
        "Amt2":               to_float(b.get("Amt2"), 0.0),
        "Amt3":               to_float(b.get("Amt3"), 0.0),
        "GSTRate1":           to_float(b.get("GSTRate1"), 0.0),
        "GSTRate2":           to_float(b.get("GSTRate2"), 0.0),
        "GSTRate3":           to_float(b.get("GSTRate3"), 0.0),
        "PFDesc":             b.get("PFDesc", ""),
        "PFAmt":              to_float(b.get("PFAmt"), 0.0),
        "PFGst":              to_float(b.get("PFGst"), 0.0),
        "PFTotal":            to_float(b.get("PFTotal"), 0.0),
        "EyeletQty":          to_float(b.get("EyeletQty"), 0.0),
        "EyeletRate":         to_float(b.get("EyeletRate"), 0.0),
        "EyeletTotal":        to_float(b.get("EyeletTotal"), 0.0),
        "FY":                 fy_from_date(b.get("OrderDate") or datetime.now().strftime("%Y-%m-%d")),
        "UpdatedAt":          datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    col("sales_records").update_one({"SNo": sno}, {"$set": update})
    payments = [
        {"Amt": update["AdvanceAmt"],        "Date": update["AdvanceDate"],  "Mode": update["AdvanceMode"]},
        {"Amt": update["BalanceSettledAmt"], "Date": update["BalanceDate"],  "Mode": update["BalanceMode"]},
        {"Amt": update["Balance2Amt"],       "Date": update["Balance2Date"], "Mode": update["Balance2Mode"]},
        {"Amt": update["Balance3Amt"],       "Date": update["Balance3Date"], "Mode": update["Balance3Mode"]},
        {"Amt": update["Balance4Amt"],       "Date": update["Balance4Date"], "Mode": update["Balance4Mode"]},
    ]
    set_sales_ledger_credits(sno, update["Customer"], update["JobName"], payments)
    return ok()

@app.delete("/api/sales/{sno}")
async def delete_sales(sno: int):
    if not await ensure_db(): return err("Database not connected", 503)
    # Find affected accounts before deleting so we can recalc their balances
    affected_entries = list(col("account_ledger").find(
        {"SalesRef": sno}, {"AccountName": 1, "FY": 1}
    ))
    affected = set((e["AccountName"], e["FY"]) for e in affected_entries if e.get("AccountName") and e.get("FY"))
    col("account_ledger").delete_many({"SalesRef": sno})
    col("sales_records").delete_one({"SNo": sno})
    # Recalculate running balances for all affected accounts
    for acct, fy in affected:
        recalc_ledger_balances(acct, fy)
    return ok()

@app.post("/api/sales/{sno}/invoiceno")
async def patch_sales_invoiceno(sno: int, request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    new_no = b.get("InvoiceNo", "") or ""
    cur = col("sales_records").find_one({"SNo": sno}, {"_id": 0, "InvoiceNo": 1}) or {}
    upd = {"InvoiceNo": new_no}
    if not new_no or (cur.get("InvoiceNo") or "") != new_no:
        upd["InvoiceId"] = 0                                    # a different number is a different invoice: the exact link no longer applies
    col("sales_records").update_one({"SNo": sno}, {"$set": upd})
    return ok()


@app.get("/api/sales/{sno}/invoice-status")
async def sales_invoice_status(sno: int):
    """Does this sales entry already have its invoice? (exact, by invoice Id when the link has one)"""
    if not await ensure_db(): return err("Database not connected", 503)
    sale = col("sales_records").find_one({"SNo": sno}, {"_id": 0, "SNo": 1, "InvoiceNo": 1, "InvoiceId": 1, "OrderDate": 1})
    if not sale: return err("Sales entry not found", 404)
    inv = _linked_invoice(sale)
    out = {"linked": bool((sale.get("InvoiceNo") or "").strip() or to_int(sale.get("InvoiceId"), 0)), "invoiceNo": (sale.get("InvoiceNo") or "").strip(),
           "exists": bool(inv and inv.get("Status") != "Cancelled")}
    if inv:
        out.update({"invoiceId": inv.get("Id"), "invoiceNo": inv.get("InvoiceNo") or out["invoiceNo"], "invoiceDate": inv.get("InvoiceDate"), "fy": _inv_fy(inv), "status": inv.get("Status") or ""})
    return ok(out)

# ─────────────────────────────────────────────
#  EXPENSES
# ─────────────────────────────────────────────
@app.get("/api/expenses")
async def get_expenses(scope: Optional[str] = Query(None), user: Optional[str] = Query(None)):
    if not await ensure_db(): return JSONResponse(content=[], status_code=503)
    query = {}
    if scope == "own" and user:
        query["createdBy"] = user
    rows = list(col("daily_expenses").find(query, {"_id": 0}).sort([("ExpDate", DESCENDING), ("Id", DESCENDING)]))
    return JSONResponse(content=rows)

@app.post("/api/expenses")
async def post_expenses(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    new_id = next_id("daily_expenses")
    amt = to_float(b.get("Amount"), 0.0)
    doc = {
        "Id":          new_id,
        "createdBy":   (b.get("createdBy") or "").strip(),
        "ExpDate":     b.get("ExpDate"),
        "Category":    b.get("Category", ""),
        "SubCategory": b.get("SubCategory", ""),
        "PaymentMode": b.get("PaymentMode", ""),
        "Description": b.get("Description", ""),
        "Amount":      amt,
    }
    col("daily_expenses").insert_one(doc)
    # Auto-create ledger debit
    pm = (b.get("PaymentMode") or "").strip()
    acct_map = {"KVB MOM":"KVB MOM","KVB Mani":"KVB Mani","Indian Bank":"Indian Bank","Cash":"Cash Balance"}
    acct = acct_map.get(pm)
    if acct and new_id:
        exp_date = (b.get("ExpDate") or "").strip()
        fy = fy_from_date(exp_date)
        if fy:
            sub_cat = (b.get("SubCategory") or "").strip()
            desc_str = (b.get("Description") or "").strip()
            desc = f"Expense: {sub_cat} — {desc_str}" if desc_str else f"Expense: {sub_cat}"
            last = col("account_ledger").find_one(
                {"AccountName": acct, "FY": fy},
                sort=[("EntryDate", DESCENDING), ("Id", DESCENDING)]
            )
            prev_bal = to_float(last["Balance"]) if last else 0.0
            new_bal  = prev_bal - amt
            led_id   = next_id("account_ledger")
            col("account_ledger").insert_one({
                "Id": led_id, "AccountName": acct, "EntryDate": exp_date,
                "Description": desc, "CreditAmt": 0, "DebitAmt": amt,
                "Balance": new_bal, "EntryType": "Expense", "FY": fy,
                "ExpenseRef": new_id, "SalesRef": None
            })
    return ok({"ok": True, "id": new_id})


@app.put("/api/expense/{exp_id}")
@app.put("/api/billing/expense/{exp_id}")
async def put_expense(exp_id: int, request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    amt = to_float(b.get("Amount"), 0.0)
    result = col("daily_expenses").update_one(
        {"Id": exp_id},
        {"$set": {
            "ExpDate":     b.get("ExpDate", ""),
            "Category":    b.get("Category", ""),
            "SubCategory": b.get("SubCategory", ""),
            "PaymentMode": b.get("PaymentMode", ""),
            "Description": b.get("Description", ""),
            "Amount":      amt,
        }}
    )
    if result.matched_count == 0:
        return err("Expense not found", 404)
    return ok({"success": True})

def _exp_mark_field(user):
    """the name of the field that holds THIS user's 'continue from here' mark (one mark per user; user names are made safe for a field name)"""
    return "ContinueMark_" + (re.sub(r"[^A-Za-z0-9_]", "_", (user or "").strip())[:40] or "default")


@app.post("/api/expenses/{exp_id}/mark")
async def mark_expense(exp_id: int, request: Request):
    """'Continue from here': marks ONE expense per user as the last one entered (the mark moves when another is marked), or removes the mark (mark=false).
    It is a plain field on the expense row: the ledger entry of the expense is not touched, and editing the expense keeps the mark."""
    if not await ensure_db(): return err("Database not connected", 503)
    try:
        b = await request.json()
    except Exception:
        b = {}
    b = b if isinstance(b, dict) else {}
    field = _exp_mark_field(b.get("user"))
    on = bool(b.get("mark", True))
    if not col("daily_expenses").find_one({"Id": exp_id}, {"_id": 0, "Id": 1}):
        return err("Expense not found", 404)
    at = datetime.utcnow().isoformat(timespec="seconds") + "Z"
    col("daily_expenses").update_many({field: {"$exists": True}}, {"$unset": {field: ""}})          # one mark per user
    if on:
        col("daily_expenses").update_one({"Id": exp_id}, {"$set": {field: at}})
    return ok({"success": True, "marked": exp_id if on else None, "at": at if on else None})


@app.delete("/api/expenses/{exp_id}")
async def delete_expense(exp_id: int):
    if not await ensure_db(): return err("Database not connected", 503)
    col("account_ledger").delete_many({"ExpenseRef": exp_id})
    col("daily_expenses").delete_one({"Id": exp_id})
    return ok()

# ─────────────────────────────────────────────
#  NOTES
# ─────────────────────────────────────────────
@app.get("/api/notes")
async def get_notes(fr: Optional[str] = Query(None, alias="from"), to: Optional[str] = Query(None)):
    query = {}
    if fr: query["NoteDate"] = {"$gte": fr}
    if to: query.setdefault("NoteDate", {})["$lte"] = to
    rows = list(col("notes").find(query, {"_id": 0}).sort([("NoteDate", DESCENDING), ("Id", DESCENDING)]))
    return JSONResponse(content=rows)

@app.post("/api/notes")
async def post_notes(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    new_id = next_id("notes")
    col("notes").insert_one({"Id": new_id, "NoteDate": b.get("NoteDate"), "NoteText": b.get("NoteText", ""), "NoteDescription": b.get("NoteDescription", "")})
    return ok()

@app.put("/api/notes/{note_id}")
async def put_notes(note_id: int, request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    col("notes").update_one({"Id": note_id}, {"$set": {"NoteDate": b.get("NoteDate"), "NoteText": b.get("NoteText", ""), "NoteDescription": b.get("NoteDescription", "")}})
    return ok()

@app.delete("/api/notes/{note_id}")
async def delete_notes(note_id: int):
    if not await ensure_db(): return err("Database not connected", 503)
    col("notes").delete_one({"Id": note_id})
    return ok()

# ─────────────────────────────────────────────
#  FOLLOWUPS
# ─────────────────────────────────────────────
def get_user_from_request(request: Request):
    """Extracts the current logged-in user from the Authorization: Bearer
    header the frontend's api() helper already sends on every call, reusing
    the same session_token lookup Renu Contacts uses for its query-param
    version. Returns None if there's no valid session."""
    auth = request.headers.get("authorization", "")
    token = auth[7:] if auth.lower().startswith("bearer ") else ""
    return verify_user_token(token)

@app.get("/api/followups")
async def get_followups():
    if not await ensure_db(): return JSONResponse(content=[], status_code=503)
    rows = list(col("followups").find({}, {"_id": 0}).sort([("IsAddressed", ASCENDING), ("FollowupDate", ASCENDING), ("Id", ASCENDING)]))
    return JSONResponse(content=rows)

@app.post("/api/followups")
async def post_followups(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    new_id = next_id("followups")
    user = get_user_from_request(request)
    col("followups").insert_one({
        "Id": new_id,
        "FollowupDate": b.get("FollowupDate"),
        "FollowupTime": b.get("FollowupTime") or "09:00",
        "Priority":     b.get("Priority", ""),
        "FollowupText": b.get("FollowupText", ""),
        "IsAddressed":  0,
        "CreatedBy":    user.get("username") if user else None,
        "SnoozedUntil": None,
    })
    return ok()


# ─────────────────────────────────────────────
#  CONTACTS
# ─────────────────────────────────────────────

@app.get("/api/contacts")
async def get_contacts(
    search: Optional[str] = Query(None),
    category: Optional[str] = Query(None),
    page: int = Query(1, ge=1),
    limit: int = Query(50, ge=1, le=200),
    user: Optional[str] = Query(None)
):
    if not await ensure_db(): return err("Database not connected", 503)
    query = {}
    if search:
        rgx = {"$regex": search, "$options": "i"}
        query["$or"] = [{"Name": rgx}, {"Phone": rgx}, {"Place": rgx}]
    if category and category != "all":
        query["Category"] = category
    skip = (page - 1) * limit
    total = shared_col("contacts").count_documents(query)
    rows = list(shared_col("contacts").find(query, {"_id": 0})
                .sort("Name", 1).skip(skip).limit(limit))
    return JSONResponse(content={"total": total, "page": page, "limit": limit, "rows": rows})

@app.post("/api/contacts")
async def save_contact(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    b.pop("_id", None)
    contact_id = b.get("Id")
    if contact_id:
        # Update existing
        shared_col("contacts").update_one({"Id": contact_id}, {"$set": b})
    else:
        # Check duplicate phone
        phone = b.get("Phone", "").strip()
        if phone:
            existing = shared_col("contacts").find_one({"Phone": phone}, {"_id": 0})
            if existing:
                return err(f"Phone {phone} already exists for {existing.get('Name','')}", 409)
        new_id = next_id("contacts")
        b["Id"] = new_id
        shared_col("contacts").insert_one(b)
    return ok({"Id": b.get("Id")})

@app.delete("/api/contacts/{contact_id}")
async def delete_contact(contact_id: int):
    if not await ensure_db(): return err("Database not connected", 503)
    shared_col("contacts").delete_one({"Id": contact_id})
    return ok()

# ── Renu Contacts — separate feature, separate collection, Rio-only (not
# shared with Rainbow the way the main Contacts tab is) ────────────────
@app.get("/api/renu-contacts")
async def get_renu_contacts(
    search: Optional[str] = Query(None),
    page: int = Query(1, ge=1),
    limit: int = Query(50, ge=1, le=200),
):
    if not await ensure_db(): return err("Database not connected", 503)
    query = {}
    if search:
        rgx = {"$regex": search, "$options": "i"}
        query["$or"] = [{"Name": rgx}, {"Phone": rgx}, {"Place": rgx}, {"Details": rgx}]
    skip = (page - 1) * limit
    total = col("renu_contacts").count_documents(query)
    rows = list(col("renu_contacts").find(query, {"_id": 0})
                .sort("Name", 1).skip(skip).limit(limit))
    return JSONResponse(content={"total": total, "page": page, "limit": limit, "rows": rows})

@app.post("/api/renu-contacts")
async def save_renu_contact(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    b.pop("_id", None)
    contact_id = b.get("Id")
    if contact_id:
        col("renu_contacts").update_one({"Id": contact_id}, {"$set": b})
    else:
        phone = (b.get("Phone") or "").strip()
        if phone:
            existing = col("renu_contacts").find_one({"Phone": phone}, {"_id": 0})
            if existing:
                return err(f"Phone {phone} already exists for {existing.get('Name','')}", 409)
        new_id = next_id("renu_contacts")
        b["Id"] = new_id
        col("renu_contacts").insert_one(b)
    return ok({"Id": b.get("Id")})

@app.delete("/api/renu-contacts/{contact_id}")
async def delete_renu_contact(contact_id: int):
    if not await ensure_db(): return err("Database not connected", 503)
    col("renu_contacts").delete_one({"Id": contact_id})
    return ok()

# -- Bonus Details - the festival bonus paid to each person, and the sweets given with it.
# One collection per company (Rio and Rainbow keep their own lists, like Renu Contacts). The checks are done HERE too, so a wrong value can never be stored.
_BONUS_QTY = (0.25, 0.5)
def _bonus_clean(b: dict):
    """returns (document, None) or (None, 'what is wrong')"""
    name = str(b.get("Name") or "").strip()
    dept = str(b.get("Department") or "").strip()
    date = str(b.get("Date") or "").strip()[:10]
    if not name: return None, "Name is required"
    if not dept: return None, "Department is required"
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", date): return None, "Date is required"
    try: amount = round(float(b.get("Amount")), 2)
    except (TypeError, ValueError): return None, "Amount must be a number"
    if amount < 0: return None, "Amount cannot be negative"
    sweets = "Yes" if str(b.get("Sweets") or "No").strip().lower() == "yes" else "No"
    qty = 0.0
    if sweets == "Yes":                                    # the quantity only counts when sweets were given; it must be one of the allowed values
        try: qty = float(b.get("SweetQty"))
        except (TypeError, ValueError): return None, "Sweet quantity must be 0.25 or 0.5"
        if qty not in _BONUS_QTY: return None, "Sweet quantity must be 0.25 or 0.5"
    status = "Pending" if str(b.get("Status") or "").strip().lower() == "pending" else "Paid"
    return {"Name": name, "Department": dept, "Date": date, "Amount": amount, "Sweets": sweets, "SweetQty": qty,
            "Occasion": str(b.get("Occasion") or "").strip()[:40], "Mode": str(b.get("Mode") or "").strip()[:20], "Status": status,
            "Description": str(b.get("Description") or "").strip()[:300]}, None

@app.get("/api/bonus-details")
async def get_bonus_details():
    if not await ensure_db(): return err("Database not connected", 503)
    rows = list(col("bonus_details").find({}, {"_id": 0}).sort([("Date", -1), ("Id", -1)]))
    return JSONResponse(content={"rows": rows})

@app.post("/api/bonus-details")
async def save_bonus_detail(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    doc, why = _bonus_clean(b if isinstance(b, dict) else {})
    if why: return err(why, 400)
    who = str(b.get("AddedBy") or "").strip()[:40]
    stamp = datetime.now().isoformat(timespec="seconds")
    bid = b.get("Id")
    if bid not in (None, "", 0):
        try: bid = int(bid)
        except (TypeError, ValueError): return err("Bad Id", 400)
        if not col("bonus_details").find_one({"Id": bid}, {"_id": 0}): return err("Entry not found", 404)
        doc["UpdatedBy"], doc["UpdatedAt"] = who, stamp
        col("bonus_details").update_one({"Id": bid}, {"$set": doc})
    else:
        bid = next_id("bonus_details")
        doc["Id"], doc["AddedBy"], doc["AddedAt"] = bid, who, stamp
        col("bonus_details").insert_one(doc)
    return ok({"Id": bid})

@app.delete("/api/bonus-details/{bonus_id}")
async def delete_bonus_detail(bonus_id: int):
    if not await ensure_db(): return err("Database not connected", 503)
    col("bonus_details").delete_one({"Id": bonus_id})
    return ok()

# ── Debt & Loan — personal money lent to / borrowed from friends.
# Own, separate login here (not the main rio_users accounts) - a single
# set of credentials, auto-created on first run by ensure_default_debt_loan_auth.
def verify_debt_loan_token(token: str):
    if not token:
        return None
    acct = col("debt_loan_auth").find_one({"session_token": token}, {"_id": 0})
    return acct

@app.post("/api/debt-loan/login")
async def debt_loan_login(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    username = (b.get("username") or "").strip().lower()
    password = (b.get("password") or "").strip()
    if not username or not password:
        return err("Username and password required", 400)
    acct = col("debt_loan_auth").find_one({"username": username})
    if not acct or not verify_password(password, acct["password"]):
        return err("Invalid username or password", 401)
    token = secrets.token_hex(32)
    col("debt_loan_auth").update_one({"username": username}, {"$set": {"session_token": token}})
    return JSONResponse(content={"ok": True, "username": username, "token": token})

@app.post("/api/debt-loan/change-password")
async def debt_loan_change_password(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    token = (b.get("token") or "").strip()
    old_password = (b.get("old_password") or "").strip()
    new_password = (b.get("new_password") or "").strip()
    acct = verify_debt_loan_token(token)
    if not acct:
        return err("Session expired. Please log in again.", 401)
    if not verify_password(old_password, acct["password"]):
        return err("Current password is incorrect", 401)
    if len(new_password) < 6:
        return err("New password must be at least 6 characters", 400)
    col("debt_loan_auth").update_one(
        {"username": acct["username"]},
        {"$set": {"password": hash_password(new_password)}}
    )
    return ok()

# Two collections: members (the people), transactions (each amount
# given/taken/returned, referencing a member by Id). Rio-only, not
# shared with Rainbow. Balances are never stored directly — always
# computed live from the transaction history, so the numbers can't
# silently drift out of sync with reality.
@app.get("/api/debt-members")
async def get_debt_members(x_debt_token: str = Header(None)):
    if not await ensure_db(): return err("Database not connected", 503)
    if not verify_debt_loan_token(x_debt_token): return err("Not logged in", 401)
    members = list(col("debt_members").find({}, {"_id": 0}).sort("Name", 1))
    txns = list(col("debt_transactions").find({}, {"_id": 0}))
    balances = {}
    for t in txns:
        mid = t.get("MemberId")
        amt = float(t.get("Amount") or 0)
        bal = balances.get(mid, 0.0)
        ttype = t.get("Type")
        if ttype == "gave": bal += amt
        elif ttype == "returned_by_them": bal -= amt
        elif ttype == "took": bal -= amt
        elif ttype == "returned_by_me": bal += amt
        balances[mid] = bal
    for m in members:
        m["Balance"] = round(balances.get(m.get("Id"), 0.0), 2)
    return JSONResponse(content={"rows": members})

@app.post("/api/debt-members")
async def save_debt_member(request: Request, x_debt_token: str = Header(None)):
    if not await ensure_db(): return err("Database not connected", 503)
    if not verify_debt_loan_token(x_debt_token): return err("Not logged in", 401)
    b = await request.json()
    b.pop("_id", None)
    member_id = b.get("Id")
    if member_id:
        col("debt_members").update_one({"Id": member_id}, {"$set": b})
    else:
        name = (b.get("Name") or "").strip()
        if not name:
            return err("Name is required", 400)
        new_id = next_id("debt_members")
        b["Id"] = new_id
        col("debt_members").insert_one(b)
    return ok({"Id": b.get("Id")})

@app.delete("/api/debt-members/{member_id}")
async def delete_debt_member(member_id: int, x_debt_token: str = Header(None)):
    if not await ensure_db(): return err("Database not connected", 503)
    if not verify_debt_loan_token(x_debt_token): return err("Not logged in", 401)
    col("debt_members").delete_one({"Id": member_id})
    col("debt_transactions").delete_many({"MemberId": member_id})
    return ok()

@app.get("/api/debt-transactions")
async def get_debt_transactions(member_id: Optional[int] = Query(None), x_debt_token: str = Header(None)):
    if not await ensure_db(): return err("Database not connected", 503)
    if not verify_debt_loan_token(x_debt_token): return err("Not logged in", 401)
    query = {"MemberId": member_id} if member_id is not None else {}
    rows = list(col("debt_transactions").find(query, {"_id": 0}).sort("Date", -1))
    return JSONResponse(content={"rows": rows})

@app.post("/api/debt-transactions")
async def save_debt_transaction(request: Request, x_debt_token: str = Header(None)):
    if not await ensure_db(): return err("Database not connected", 503)
    if not verify_debt_loan_token(x_debt_token): return err("Not logged in", 401)
    b = await request.json()
    b.pop("_id", None)
    if not b.get("MemberId"):
        return err("MemberId is required", 400)
    if b.get("Type") not in ("gave", "returned_by_them", "took", "returned_by_me"):
        return err("Invalid transaction Type", 400)
    txn_id = b.get("Id")
    if txn_id:
        col("debt_transactions").update_one({"Id": txn_id}, {"$set": b})
    else:
        new_id = next_id("debt_transactions")
        b["Id"] = new_id
        col("debt_transactions").insert_one(b)
    return ok({"Id": b.get("Id")})

@app.delete("/api/debt-transactions/{txn_id}")
async def delete_debt_transaction(txn_id: int, x_debt_token: str = Header(None)):
    if not await ensure_db(): return err("Database not connected", 503)
    if not verify_debt_loan_token(x_debt_token): return err("Not logged in", 401)
    col("debt_transactions").delete_one({"Id": txn_id})
    return ok()

# ── Debt & Loan: Bank Loans — multiple separate loans taken from banks,
# each with its own monthly repayments (each repayment tagged with which
# member paid it) and its own "lent out to friends" balance, since money
# given to a friend can be sourced from a specific bank loan rather than
# your own money - see BankLoanId on debt_transactions below.
@app.get("/api/debt-bank-loans")
async def get_bank_loans(x_debt_token: str = Header(None)):
    if not await ensure_db(): return err("Database not connected", 503)
    if not verify_debt_loan_token(x_debt_token): return err("Not logged in", 401)
    loans = list(col("debt_bank_loans").find({}, {"_id": 0}).sort("DateTaken", -1))
    payments = list(col("debt_bank_loan_payments").find({}, {"_id": 0}))
    lent_out_txns = list(col("debt_transactions").find({"Source": "bank_loan"}, {"_id": 0}))
    repaid_by_loan = {}
    for p in payments:
        lid = p.get("BankLoanId")
        repaid_by_loan[lid] = repaid_by_loan.get(lid, 0.0) + float(p.get("Amount") or 0)
    lent_by_loan = {}
    for t in lent_out_txns:
        lid = t.get("BankLoanId")
        lent_by_loan[lid] = lent_by_loan.get(lid, 0.0) + float(t.get("Amount") or 0)
    for l in loans:
        principal = float(l.get("PrincipalAmount") or 0)
        repaid = round(repaid_by_loan.get(l.get("Id"), 0.0), 2)
        lent_out = round(lent_by_loan.get(l.get("Id"), 0.0), 2)
        # Outstanding must be measured against the TOTAL repayment (the
        # sum of every month's expected EMI, which includes interest when
        # the loan has any) - not the bare principal. Using bare principal
        # was the bug: once enough months are paid that repaid exceeds the
        # principal alone (which happens well before the loan is actually
        # finished whenever interest is involved), this went negative /
        # hit zero early, instead of tracking correctly to the real end.
        schedule = l.get("EMISchedule") or []
        total_repayment = sum(float(e.get("ExpectedAmount") or 0) for e in schedule) if schedule else principal
        l["RepaidToBank"] = repaid
        l["OutstandingToBank"] = round(max(total_repayment - repaid, 0), 2)
        l["LentOutToFriends"] = lent_out
        l["AvailableWithYou"] = round(principal - lent_out, 2)
    return JSONResponse(content={"rows": loans})

@app.post("/api/debt-bank-loans")
async def save_bank_loan(request: Request, x_debt_token: str = Header(None)):
    if not await ensure_db(): return err("Database not connected", 503)
    if not verify_debt_loan_token(x_debt_token): return err("Not logged in", 401)
    b = await request.json()
    b.pop("_id", None)
    loan_id = b.get("Id")
    if loan_id:
        col("debt_bank_loans").update_one({"Id": loan_id}, {"$set": b})
    else:
        name = (b.get("LoanName") or "").strip()
        if not name:
            return err("Loan name is required", 400)
        if not b.get("PrincipalAmount"):
            return err("Principal amount is required", 400)
        new_id = next_id("debt_bank_loans")
        b["Id"] = new_id
        col("debt_bank_loans").insert_one(b)
    return ok({"Id": b.get("Id")})

@app.delete("/api/debt-bank-loans/{loan_id}")
async def delete_bank_loan(loan_id: int, x_debt_token: str = Header(None)):
    if not await ensure_db(): return err("Database not connected", 503)
    if not verify_debt_loan_token(x_debt_token): return err("Not logged in", 401)
    col("debt_bank_loans").delete_one({"Id": loan_id})
    col("debt_bank_loan_payments").delete_many({"BankLoanId": loan_id})
    return ok()

@app.get("/api/debt-bank-loan-payments")
async def get_bank_loan_payments(loan_id: Optional[int] = Query(None), x_debt_token: str = Header(None)):
    if not await ensure_db(): return err("Database not connected", 503)
    if not verify_debt_loan_token(x_debt_token): return err("Not logged in", 401)
    query = {"BankLoanId": loan_id} if loan_id is not None else {}
    rows = list(col("debt_bank_loan_payments").find(query, {"_id": 0}).sort("Date", -1))
    return JSONResponse(content={"rows": rows})

@app.post("/api/debt-bank-loan-payments")
async def save_bank_loan_payment(request: Request, x_debt_token: str = Header(None)):
    if not await ensure_db(): return err("Database not connected", 503)
    if not verify_debt_loan_token(x_debt_token): return err("Not logged in", 401)
    b = await request.json()
    b.pop("_id", None)
    if not b.get("BankLoanId"):
        return err("BankLoanId is required", 400)
    if not b.get("Amount"):
        return err("Amount is required", 400)
    pay_id = b.get("Id")
    if pay_id:
        col("debt_bank_loan_payments").update_one({"Id": pay_id}, {"$set": b})
    else:
        new_id = next_id("debt_bank_loan_payments")
        b["Id"] = new_id
        col("debt_bank_loan_payments").insert_one(b)
    return ok({"Id": b.get("Id")})

@app.delete("/api/debt-bank-loan-payments/{payment_id}")
async def delete_bank_loan_payment(payment_id: int, x_debt_token: str = Header(None)):
    if not await ensure_db(): return err("Database not connected", 503)
    if not verify_debt_loan_token(x_debt_token): return err("Not logged in", 401)
    col("debt_bank_loan_payments").delete_one({"Id": payment_id})
    return ok()

# ── Login Logs — audit trail of every successful login, recorded from
# within /api/auth/login itself. Tracks what's actually available from a
# server-side request: IP address, OS/browser (parsed from User-Agent -
# not a real "machine name", since browsers don't expose the device's
# actual hostname to web pages), and an approximate city from IP
# geolocation. See get_client_ip / parse_user_agent / get_ip_geolocation.
@app.get("/api/login-logs")
async def get_login_logs(
    username: Optional[str] = Query(None),
    page: int = Query(1, ge=1),
    limit: int = Query(50, ge=1, le=200),
):
    if not await ensure_db(): return err("Database not connected", 503)
    query = {}
    if username:
        query["Username"] = {"$regex": username, "$options": "i"}
    skip = (page - 1) * limit
    total = col("rio_login_logs").count_documents(query)
    rows = list(col("rio_login_logs").find(query, {"_id": 0})
                .sort("LoginTime", -1).skip(skip).limit(limit))
    return JSONResponse(content={"total": total, "page": page, "limit": limit, "rows": rows})

@app.get("/api/contacts/categories")
async def get_contact_categories():
    if not await ensure_db(): return err("Database not connected", 503)
    # Get custom categories + defaults
    custom = list(shared_col("contact_categories").find({}, {"_id": 0}).sort("Name", 1))
    defaults = [
        {"Name": "Customer", "Color": "#1565c0"},
        {"Name": "Vendor",   "Color": "#e65100"},
        {"Name": "Staff",    "Color": "#2e7d32"},
        {"Name": "Other",    "Color": "#6a1b9a"}
    ]
    # Merge: custom overrides defaults if same name
    custom_names = {c["Name"] for c in custom}
    merged = [d for d in defaults if d["Name"] not in custom_names] + custom
    merged.sort(key=lambda x: x["Name"])
    return JSONResponse(content=merged)

@app.post("/api/contacts/categories")
async def save_contact_category(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    name = b.get("Name", "").strip()
    if not name: return err("Category name required")
    color = b.get("Color", "#607d8b")
    shared_col("contact_categories").update_one(
        {"Name": name}, {"$set": {"Name": name, "Color": color}}, upsert=True)
    return ok()

@app.delete("/api/contacts/categories/{name}")
async def delete_contact_category(name: str):
    if not await ensure_db(): return err("Database not connected", 503)
    shared_col("contact_categories").delete_one({"Name": name})
    return ok()


@app.put("/api/followups/{fid}/address")
async def address_followup(fid: int):
    if not await ensure_db(): return err("Database not connected", 503)
    col("followups").update_one({"Id": fid}, {"$set": {"IsAddressed": 1}})
    return ok()

@app.put("/api/followups/{fid}/reopen")
async def reopen_followup(fid: int, request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    new_date = b.get("FollowupDate") or datetime.now().strftime("%Y-%m-%d")
    col("followups").update_one({"Id": fid}, {"$set": {"IsAddressed": 0, "FollowupDate": new_date}})
    return ok()

@app.put("/api/followups/{fid}")
async def put_followup(fid: int, request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    col("followups").update_one({"Id": fid}, {"$set": {
        "FollowupDate": b.get("FollowupDate"),
        "FollowupTime": b.get("FollowupTime") or "09:00",
        "Priority":     b.get("Priority", ""),
        "FollowupText": b.get("FollowupText", ""),
    }})
    return ok()

@app.put("/api/followups/{fid}/snooze")
async def snooze_followup(fid: int, request: Request):
    """Pushes SnoozedUntil forward by the requested number of minutes from
    now, so the reminder popup won't re-trigger for this item until that
    time passes - checked client-side alongside FollowupDate/Time."""
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    minutes = int(b.get("minutes") or 10)
    snoozed_until = (datetime.now() + timedelta(minutes=minutes)).strftime("%Y-%m-%dT%H:%M:%S")
    col("followups").update_one({"Id": fid}, {"$set": {"SnoozedUntil": snoozed_until}})
    return ok({"SnoozedUntil": snoozed_until})

@app.delete("/api/followups/{fid}")
async def delete_followup(fid: int):
    if not await ensure_db(): return err("Database not connected", 503)
    col("followups").delete_one({"Id": fid})
    return ok()

# ─────────────────────────────────────────────
#  CLIENTS
# ─────────────────────────────────────────────
@app.get("/api/clients")
async def get_clients():
    # Clients list is a shared lookup — always return all (used for sales dropdown autocomplete)
    if not await ensure_db(): return JSONResponse(content=[], status_code=503)
    rows = list(shared_col("rio_clients").find({}, {"_id": 0, "ClientName": 1}).sort("ClientName", ASCENDING))
    return JSONResponse(content=[r["ClientName"] for r in rows if r.get("ClientName")])

@app.get("/api/rio_clients")
async def get_rio_clients(q: Optional[str] = Query(None)):
    """Alias for /api/billing/customers — used by customer autocomplete."""
    if not await ensure_db(): return JSONResponse(content=[], status_code=503)
    query = {}
    if q: query["Name"] = {"$regex": q, "$options": "i"}
    rows = list(shared_col("rio_clients").find(query, {"_id": 0}).sort("ClientName", ASCENDING))
    # Rename ClientName → Name for billing compatibility
    result = [{"Id": r.get("Id"), "Name": r.get("ClientName", r.get("Name", "")),
               "Mobile": r.get("Mobile",""), "GSTNo": r.get("GSTNo",""),
               "State": r.get("State",""), "StateCode": r.get("StateCode",""),
               "Type": r.get("Type","")} for r in rows]
    return JSONResponse(content=result)


@app.post("/api/clients")
async def post_clients(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    name = (b.get("ClientName") or "").strip()
    created_by = (b.get("createdBy") or "").strip()
    if name:
        shared_col("rio_clients").update_one(
            {"ClientName": name},
            {"$setOnInsert": {"Id": next_id("rio_clients"), "ClientName": name, "createdBy": created_by}},
            upsert=True
        )
    return ok()

# ─────────────────────────────────────────────
#  CATEGORIES
# ─────────────────────────────────────────────
@app.delete("/api/clients/{client_name:path}")
async def delete_client(client_name: str):
    """Delete a client from the sales tracker clientsList."""
    if not await ensure_db(): return JSONResponse(content={"error":"DB offline"}, status_code=503)
    name = client_name.strip()
    shared_col("rio_clients").delete_one({"ClientName": {"$regex": f"^{re.escape(name)}$", "$options": "i"}})
    return ok({"success": True, "deleted": name})


@app.get("/api/categories")
async def get_categories():
    if not await ensure_db(): return JSONResponse(content=[], status_code=503)
    rows = list(col("expense_categories").distinct("CategoryName"))
    return JSONResponse(content=sorted(rows))

@app.get("/api/expense_categories")
async def get_expense_categories_alias():
    """Alias for /api/categories — used by mobile/expense dropdown."""
    if not await ensure_db(): return JSONResponse(content=[], status_code=503)
    rows = list(col("expense_categories").find({}, {"_id": 0}).sort(
        [("CategoryName", ASCENDING), ("SubCategoryName", ASCENDING)]))
    return JSONResponse(content=rows)


@app.get("/api/categories/all")
async def get_categories_all():
    if not await ensure_db(): return JSONResponse(content=[], status_code=503)
    rows = list(col("expense_categories").find({}, {"_id": 0}).sort([("CategoryName", ASCENDING), ("SubCategoryName", ASCENDING)]))
    from collections import defaultdict
    mp = defaultdict(list)
    for r in rows:
        mp[r["CategoryName"]].append(r["SubCategoryName"])
    return JSONResponse(content=[{"category": k, "subcats": v} for k, v in mp.items()])

@app.get("/api/categories/subcats")
async def get_subcats(cat: str = Query("")):
    if not await ensure_db(): return JSONResponse(content=[], status_code=503)
    rows = list(col("expense_categories").find({"CategoryName": cat}, {"_id": 0, "SubCategoryName": 1}).sort("SubCategoryName", ASCENDING))
    subs = [r["SubCategoryName"] for r in rows]
    return JSONResponse(content=subs if subs else ["Other"])

@app.post("/api/categories")
async def post_category(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    cn = (b.get("CategoryName") or "").strip()
    sn = (b.get("SubCategoryName") or "").strip()
    if cn and sn:
        exists = col("expense_categories").find_one({"CategoryName": cn, "SubCategoryName": sn})
        if not exists:
            new_id = next_id("expense_categories")
            col("expense_categories").insert_one({"Id": new_id, "CategoryName": cn, "SubCategoryName": sn})
    return ok()

@app.post("/api/categories/sync")
async def sync_categories(request: Request):
    rows = await request.json()
    inserted = 0
    for row in (rows if isinstance(rows, list) else []):
        cn = (row.get("CategoryName") or "").strip()
        sn = (row.get("SubCategoryName") or "").strip()
        if cn and sn:
            exists = col("expense_categories").find_one({"CategoryName": cn, "SubCategoryName": sn})
            if not exists:
                new_id = next_id("expense_categories")
                col("expense_categories").insert_one({"Id": new_id, "CategoryName": cn, "SubCategoryName": sn})
                inserted += 1
    return ok({"ok": True, "inserted": inserted})

# NOTE: must stay ABOVE /categories/{cat_id}, or 'byname' is read as a category id (HTTP 422) and Manage Categories deletes fail.
@app.delete("/api/categories/byname")
@app.delete("/api/billing/categories/byname")
async def delete_category_byname(category: str = Query(""), subcategory: str = Query("")):
    """Delete a category or subcategory by name."""
    if not await ensure_db(): return err("Database not connected", 503)
    try:
        if subcategory:
            # Delete specific subcategory
            col("expense_categories").delete_many({"CategoryName": category, "SubCategoryName": subcategory})
        elif category:
            # Check if any expenses use this category
            count = col("daily_expenses").count_documents({"Category": category})
            if count > 0:
                return err(f"Cannot delete: {count} expense records use this category", 400)
            col("expense_categories").delete_many({"CategoryName": category})
        return ok({"success": True})
    except Exception as e:
        return err(str(e), 500)

@app.delete("/api/categories/{cat_id}")
async def delete_category(cat_id: int):
    if not await ensure_db(): return err("Database not connected", 503)
    col("expense_categories").delete_one({"Id": cat_id})
    return ok()

# ─────────────────────────────────────────────
#  JOBS
# ─────────────────────────────────────────────
@app.get("/api/jobs")
async def get_jobs(fr: Optional[str] = Query(None, alias="from"), to: Optional[str] = Query(None)):
    if not await ensure_db(): return JSONResponse(content=[], status_code=503)
    query = {}
    if fr: query["ConfirmedDate"] = {"$gte": fr}
    if to: query.setdefault("ConfirmedDate", {})["$lte"] = to
    rows = list(col("jobs").find(query, {"_id": 0}).sort("Id", DESCENDING))
    return JSONResponse(content=rows)

@app.post("/api/jobs")
async def post_jobs(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    new_id = next_id("jobs")
    # Auto-generate JobNo if not provided: J001, J002, ...
    job_no = (b.get("JobNo") or "").strip()
    if not job_no:
        pipeline = [{"$group": {"_id": None, "max": {"$max": "$Id"}}}]
        res = list(col("jobs").aggregate(pipeline))
        max_id = to_int(res[0]["max"]) if res else 0
        job_no = f"J{(max_id + 1):03d}"
    col("jobs").insert_one({
        "Id":           new_id,
        "JobNo":        job_no,
        "Customer":     b.get("Customer", ""),
        "JobName":      b.get("JobName", ""),
        "ConfirmedDate":b.get("ConfirmedDate"),
        "ProductSize":  b.get("ProductSize", ""),
        "Qty":          to_int(b.get("Qty")),
        "Status":       b.get("Status", ""),
        "DispatchDate": b.get("DispatchDate"),
    })
    return ok({"ok": True, "id": new_id, "jobNo": job_no})

@app.put("/api/jobs/{job_id}")
async def put_jobs(job_id: int, request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    update = {
        "Customer":     b.get("Customer", ""),
        "JobName":      b.get("JobName", ""),
        "ConfirmedDate":b.get("ConfirmedDate"),
        "ProductSize":  b.get("ProductSize", ""),
        "Qty":          to_int(b.get("Qty")),
        "Status":       b.get("Status", ""),
        "DispatchDate": b.get("DispatchDate"),
    }
    # Only update JobNo if provided (don't overwrite existing)
    if b.get("JobNo"):
        update["JobNo"] = b.get("JobNo")
    col("jobs").update_one({"Id": job_id}, {"$set": update})
    return ok()

@app.delete("/api/jobs/{job_id}")
async def delete_jobs(job_id: int):
    if not await ensure_db(): return err("Database not connected", 503)
    col("jobs").delete_one({"Id": job_id})
    return ok()

# ─────────────────────────────────────────────
#  ACCOUNT BALANCES
# ─────────────────────────────────────────────
@app.get("/api/accountbalances")
async def get_acct_balances():
    if not await ensure_db(): return JSONResponse(content=[], status_code=503)
    rows = list(col("account_balances").find({}, {"_id": 0}).sort([("EntryDate", DESCENDING), ("Id", DESCENDING)]))
    return JSONResponse(content=rows)

@app.post("/api/accountbalances")
async def post_acct_balance(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    new_id = next_id("account_balances")
    col("account_balances").insert_one({
        "Id":          new_id,
        "AccountName": b.get("AccountName", ""),
        "EntryDate":   b.get("EntryDate"),
        "Balance":     to_float(b.get("Balance"), 0.0),
        "Notes":       b.get("Notes", ""),
    })
    return ok({"ok": True, "id": new_id})

@app.delete("/api/accountbalances/{ab_id}")
async def delete_acct_balance(ab_id: int):
    if not await ensure_db(): return err("Database not connected", 503)
    col("account_balances").delete_one({"Id": ab_id})
    return ok()

# ─────────────────────────────────────────────
#  LEDGER
# ─────────────────────────────────────────────
# ─────────────────────────────────────────────
#  BANK LOANS — outstanding, interest %, EMI payments
#  A loan holds principal + interest rate. Each EMI payment is split into principal
#  and interest: principal reduces the outstanding; interest is posted as an expense
#  (so Profit/Loss sees it); both debit the paying account in the ledger.
#  Same trust model as the other admin screens: gated to admin in the UI.
# ─────────────────────────────────────────────
def _num(v) -> float:
    """Number or 0.0 - the shared to_float() returns None for missing values when no default is given."""
    r = to_float(v, 0.0)
    return 0.0 if r is None else r

LOAN_ACCOUNTS = {"KVB MOM": "KVB MOM", "KVB Mani": "KVB Mani", "Indian Bank": "Indian Bank", "Cash": "Cash Balance"}

def _loan_view(loan: dict, payments: list) -> dict:
    principal = _num(loan.get("Principal"))
    p_paid = round(sum(_num(p.get("Principal")) for p in payments), 2)
    i_paid = round(sum(_num(p.get("Interest")) for p in payments), 2)
    pays = sorted(payments, key=lambda p: (p.get("Date", ""), p.get("Id", 0)), reverse=True)
    return {**loan, "Payments": pays, "PrincipalPaid": p_paid, "InterestPaid": i_paid,
            "Outstanding": max(0.0, round(principal - p_paid, 2))}

@app.get("/api/billing/loans")
async def billing_get_loans(request: Request):
    _g = await admin_guard(request)
    if _g: return _g
    if not await ensure_db(): return err("Database not connected", 503)
    loans = list(col("bank_loans").find({}, {"_id": 0}).sort("Id", ASCENDING))
    by_loan = {}
    for p in col("loan_payments").find({}, {"_id": 0}):
        by_loan.setdefault(p.get("LoanId"), []).append(p)
    return JSONResponse(content=[_loan_view(l, by_loan.get(l.get("Id"), [])) for l in loans])

@app.post("/api/billing/loans")
async def billing_save_loan(request: Request):
    _g = await admin_guard(request)
    if _g: return _g
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    lender = (b.get("Lender") or "").strip()
    if not lender: return err("Lender is required")
    principal = _num(b.get("Principal"))
    if principal <= 0: return err("Loan amount must be greater than 0")
    rate = _num(b.get("Rate"))
    if rate < 0 or rate > 100: return err("Interest % must be between 0 and 100")
    emi = _num(b.get("EMI"))
    if emi < 0: return err("EMI cannot be negative")
    start = (b.get("StartDate") or "").strip()[:10]
    if start and not fy_from_date(start): return err("Invalid start date")
    acct = (b.get("Account") or "").strip()
    if acct and acct not in LOAN_ACCOUNTS: return err("Invalid paying account")
    fields = {"Lender": lender, "Name": (b.get("Name") or "").strip(), "Principal": round(principal, 2),
              "Rate": rate, "EMI": round(emi, 2), "StartDate": start, "Account": acct or "Indian Bank",
              "Status": "closed" if (b.get("Status") == "closed") else "active"}
    today = datetime.utcnow().strftime("%Y-%m-%d")
    loan_id = b.get("Id")
    if loan_id:
        loan_id = int(loan_id)
        existing = col("bank_loans").find_one({"Id": loan_id}, {"_id": 0})
        if not existing: return err("Loan not found", 404)
        paid = sum(_num(p.get("Principal")) for p in col("loan_payments").find({"LoanId": loan_id}, {"_id": 0}))
        if principal + 0.005 < paid:
            return err(f"Loan amount cannot be less than the principal already repaid (Rs.{paid:,.2f})")
        hist = list(existing.get("RateHistory") or [])
        if abs(_num(existing.get("Rate")) - rate) > 1e-9:
            hist.append({"from": (b.get("RateFrom") or "").strip()[:10] or today, "rate": rate})
        fields["RateHistory"] = hist
        col("bank_loans").update_one({"Id": loan_id}, {"$set": fields})
        return ok({"success": True, "id": loan_id})
    new_id = next_id("bank_loans")
    fields.update({"Id": new_id, "RateHistory": [{"from": start or today, "rate": rate}], "createdAt": datetime.utcnow().isoformat()})
    col("bank_loans").insert_one(fields)
    return ok({"success": True, "id": new_id})

@app.delete("/api/billing/loans/{loan_id}")
async def billing_delete_loan(loan_id: int, request: Request):
    _g = await admin_guard(request)
    if _g: return _g
    if not await ensure_db(): return err("Database not connected", 503)
    if col("loan_payments").count_documents({"LoanId": loan_id}) > 0:
        return err("This loan has EMI payments recorded. Delete those payments first (or mark the loan Closed instead).", 400)
    r = col("bank_loans").delete_one({"Id": loan_id})
    if r.deleted_count == 0: return err("Loan not found", 404)
    return ok({"success": True})

@app.post("/api/billing/loans/{loan_id}/payment")
async def billing_loan_payment(loan_id: int, request: Request):
    _g = await admin_guard(request)
    if _g: return _g
    if not await ensure_db(): return err("Database not connected", 503)
    loan = col("bank_loans").find_one({"Id": loan_id}, {"_id": 0})
    if not loan: return err("Loan not found", 404)
    b = await request.json()
    dt = (b.get("Date") or "").strip()[:10]
    fy = fy_from_date(dt) if dt else ""
    if not fy: return err("A valid payment date is required")
    pm = (b.get("Account") or "").strip()
    acct = LOAN_ACCOUNTS.get(pm)
    if not acct: return err("Choose the account the EMI was paid from")
    principal = round(_num(b.get("Principal")), 2)
    interest  = round(_num(b.get("Interest")), 2)
    if principal < 0 or interest < 0: return err("Amounts cannot be negative")
    if principal + interest <= 0: return err("Enter the principal and/or interest paid")
    paid_before = sum(_num(p.get("Principal")) for p in col("loan_payments").find({"LoanId": loan_id}, {"_id": 0}))
    outstanding = round(_num(loan.get("Principal")) - paid_before, 2)
    if principal > outstanding + 0.005:
        return err(f"Principal Rs.{principal:,.2f} is more than the outstanding Rs.{outstanding:,.2f}")
    note = (b.get("Note") or "").strip()
    lender = loan.get("Lender", "Loan")
    pay_id = next_id("loan_payments")
    exp_id = None
    if interest > 0:
        exp_id = next_id("daily_expenses")
        col("daily_expenses").insert_one({
            "Id": exp_id, "createdBy": "loan", "ExpDate": dt, "Category": "Admin & Finance",
            "SubCategory": "Bank Interest", "PaymentMode": pm,
            "Description": f"Loan interest — {lender}" + (f" ({note})" if note else ""),
            "Amount": interest, "LoanPayRef": pay_id})
        col("account_ledger").insert_one({
            "Id": next_id("account_ledger"), "AccountName": acct, "EntryDate": dt,
            "Description": f"Expense: Bank Interest — Loan interest — {lender}",
            "CreditAmt": 0, "DebitAmt": interest, "Balance": 0, "EntryType": "Expense", "FY": fy,
            "ExpenseRef": exp_id, "SalesRef": None, "LoanPayRef": pay_id})
    if principal > 0:
        col("account_ledger").insert_one({
            "Id": next_id("account_ledger"), "AccountName": acct, "EntryDate": dt,
            "Description": f"Loan repayment (principal) — {lender}",
            "CreditAmt": 0, "DebitAmt": principal, "Balance": 0, "EntryType": "Loan Repayment", "FY": fy,
            "ExpenseRef": None, "SalesRef": None, "LoanPayRef": pay_id})
    recalc_ledger_balances(acct, fy)
    col("loan_payments").insert_one({
        "Id": pay_id, "LoanId": loan_id, "Date": dt, "Account": pm, "Principal": principal, "Interest": interest,
        "Total": round(principal + interest, 2), "Note": note, "ExpenseId": exp_id, "FY": fy,
        "createdAt": datetime.utcnow().isoformat()})
    return ok({"success": True, "id": pay_id, "outstanding": round(outstanding - principal, 2)})

@app.delete("/api/billing/loan-payments/{pay_id}")
async def billing_delete_loan_payment(pay_id: int, request: Request):
    _g = await admin_guard(request)
    if _g: return _g
    if not await ensure_db(): return err("Database not connected", 503)
    p = col("loan_payments").find_one({"Id": pay_id}, {"_id": 0})
    if not p: return err("Payment not found", 404)
    col("account_ledger").delete_many({"LoanPayRef": pay_id})
    if p.get("ExpenseId"):
        col("daily_expenses").delete_one({"Id": p["ExpenseId"]})
    col("loan_payments").delete_one({"Id": pay_id})
    acct = LOAN_ACCOUNTS.get(p.get("Account", ""))
    fy = p.get("FY") or fy_from_date(p.get("Date", ""))
    if acct and fy: recalc_ledger_balances(acct, fy)
    return ok({"success": True})

@app.get("/api/ledger/debug")
async def ledger_debug():
    total = col("account_ledger").count_documents({})
    rows = list(col("account_ledger").find({}, {"_id": 0}).sort("Id", DESCENDING).limit(20))
    return JSONResponse(content={"total": total, "rows": rows})

@app.get("/api/ledger/prev-closing")
async def ledger_prev_closing(fy: str = Query("")):
    if not fy:
        return JSONResponse(content=[])
    fy_year = int(fy.split("-")[0])
    prev_fy = f"{fy_year-1}-{str(fy_year)[-2:]}"
    result = []
    for acct in ["KVB MOM", "KVB Mani", "Indian Bank", "Cash Balance"]:
        last = col("account_ledger").find_one(
            {"AccountName": acct, "FY": prev_fy},
            sort=[("EntryDate", DESCENDING), ("Id", DESCENDING)]
        )
        bal = to_float(last["Balance"]) if last else 0.0
        result.append({"AccountName": acct, "ClosingBalance": bal})
    return JSONResponse(content=result)

@app.get("/api/ledger/opening")
async def get_ledger_opening(fy: str = Query("")):
    if not fy:
        return JSONResponse(content=[])
    rows = list(col("account_opening_balances").find({"FY": fy}, {"_id": 0}))
    return JSONResponse(content=rows)

@app.post("/api/ledger/opening")
async def post_ledger_opening(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    fy = (b.get("FY") or "").strip()
    if not fy:
        return err("FY required")
    for acct in ["KVB MOM", "KVB Mani", "Indian Bank", "Cash Balance"]:
        val = to_float(b.get(acct), 0.0)
        exists = col("account_opening_balances").find_one({"AccountName": acct, "FY": fy})
        if exists:
            col("account_opening_balances").update_one(
                {"AccountName": acct, "FY": fy},
                {"$set": {"OpeningBal": val}}
            )
        else:
            col("account_opening_balances").insert_one({"AccountName": acct, "FY": fy, "OpeningBal": val})
    return ok()

@app.delete("/api/ledger/clear-opening")
async def clear_ledger_opening(fy: str = Query("")):
    if not await ensure_db(): return err("Database not connected", 503)
    if not fy:
        return ok({"ok": False})
    col("account_ledger").delete_many({"EntryType": "Opening", "FY": fy})
    col("account_opening_balances").delete_many({"FY": fy})
    return ok()

@app.get("/api/ledger")
async def get_ledger(
    account: Optional[str] = Query(None),
    fy: Optional[str] = Query(None),
    month: Optional[str] = Query(None)
):
    if not await ensure_db(): return JSONResponse(content=[], status_code=503)
    if not fy:
        return JSONResponse(content=[])
    query = {"FY": fy}
    if account: query["AccountName"] = account
    if month:   query["EntryDate"] = {"$regex": f"^{month}"}
    rows = list(col("account_ledger").find(query, {"_id": 0}).sort([("EntryDate", ASCENDING), ("Id", ASCENDING)]))
    return JSONResponse(content=rows)

@app.post("/api/ledger")
async def post_ledger(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    acct  = (b.get("AccountName") or "").strip()
    dt    = (b.get("EntryDate") or "").strip() or datetime.now().strftime("%Y-%m-%d")
    desc  = (b.get("Description") or "").strip()
    cr    = to_float(b.get("CreditAmt"), 0.0)
    dr    = to_float(b.get("DebitAmt"), 0.0)
    etype = (b.get("EntryType") or "Manual").strip()
    fy    = (b.get("FY") or "").strip()
    if not acct: return err("AccountName required")
    if not fy:   return err("FY required")
    if cr > 0 and dr > 0:
        return err("A ledger entry can only be a Credit or a Debit, not both — please enter one amount and leave the other at 0")
    if etype == "Opening":
        new_bal = cr - dr
    else:
        last = col("account_ledger").find_one(
            {"AccountName": acct, "FY": fy},
            sort=[("EntryDate", DESCENDING), ("Id", DESCENDING)]
        )
        if last:
            prev = to_float(last["Balance"], 0.0)
        else:
            ob = col("account_opening_balances").find_one({"AccountName": acct, "FY": fy})
            prev = to_float(ob["OpeningBal"]) if ob else 0.0
        new_bal = prev + cr - dr
    new_id = next_id("account_ledger")
    col("account_ledger").insert_one({
        "Id": new_id, "AccountName": acct, "EntryDate": dt,
        "Description": desc, "CreditAmt": cr, "DebitAmt": dr,
        "Balance": new_bal, "EntryType": etype, "FY": fy,
        "ExpenseRef": None, "SalesRef": None
    })
    return ok({"ok": True, "balance": new_bal})

@app.delete("/api/ledger/reset")
async def ledger_reset():
    if not await ensure_db(): return err("Database not connected", 503)
    col("account_ledger").delete_many({})
    col("account_opening_balances").delete_many({})
    return ok()

@app.delete("/api/ledger/{led_id}")
async def delete_ledger_entry(led_id: int):
    if not await ensure_db(): return err("Database not connected", 503)
    col("account_ledger").delete_one({"Id": led_id})
    return ok()

@app.post("/api/ledger/migrate")
async def ledger_migrate(request: Request):
    b = await request.json()
    fy = (b.get("FY") or "").strip()
    if not fy: return err("FY required")
    fy_from, fy_to = fy_range(fy)
    exp_count = sales_count = skip_count = 0

    # Import expenses
    exp_rows = list(col("daily_expenses").find(
        {"ExpDate": {"$gte": fy_from, "$lte": fy_to}},
        {"_id": 0}
    ).sort([("ExpDate", ASCENDING), ("Id", ASCENDING)]))

    for row in exp_rows:
        exp_id = to_int(row.get("Id"))
        already = col("account_ledger").count_documents({"ExpenseRef": exp_id})
        if already > 0: skip_count += 1; continue
        pm = (row.get("PaymentMode") or "").strip()
        acct_map = {"KVB MOM":"KVB MOM","KVB Mani":"KVB Mani","Indian Bank":"Indian Bank","Cash":"Cash Balance"}
        acct = acct_map.get(pm)
        if not acct: skip_count += 1; continue
        exp_date = row.get("ExpDate", "")
        amt = to_float(row.get("Amount"), 0.0)
        sub_cat = (row.get("SubCategory") or "").strip()
        desc_str = (row.get("Description") or "").strip()
        desc = f"Expense: {sub_cat} — {desc_str}" if desc_str else f"Expense: {sub_cat}"
        last = col("account_ledger").find_one({"AccountName": acct, "FY": fy}, sort=[("EntryDate", DESCENDING), ("Id", DESCENDING)])
        prev = to_float(last["Balance"]) if last else 0.0
        new_bal = prev - amt
        led_id = next_id("account_ledger")
        col("account_ledger").insert_one({
            "Id": led_id, "AccountName": acct, "EntryDate": exp_date,
            "Description": desc, "CreditAmt": 0, "DebitAmt": amt,
            "Balance": new_bal, "EntryType": "Expense", "FY": fy,
            "ExpenseRef": exp_id, "SalesRef": None
        })
        exp_count += 1

    # Import sales payments
    sales_rows = list(col("sales_records").find(
        {"OrderDate": {"$gte": fy_from, "$lte": fy_to}},
        {"_id": 0}
    ).sort([("OrderDate", ASCENDING), ("SNo", ASCENDING)]))

    acct_map = {"KVB MOM":"KVB MOM","KVB Mani":"KVB Mani","Indian Bank":"Indian Bank","Cash":"Cash Balance"}
    for row in sales_rows:
        sno = to_int(row.get("SNo"))
        already = col("account_ledger").count_documents({"SalesRef": sno})
        if already > 0: skip_count += 1; continue
        cust = (row.get("Customer") or "").strip()
        job  = (row.get("JobName") or "").strip()
        jn_str = f" — {job}" if job else ""
        desc = f"Sales: {cust}{jn_str}"
        payments = [
            {"Amt": row.get("AdvanceAmt"),        "Date": row.get("AdvanceDate"),  "Mode": row.get("AdvanceMode","")},
            {"Amt": row.get("BalanceSettledAmt"), "Date": row.get("BalanceDate"),  "Mode": row.get("BalanceMode","")},
            {"Amt": row.get("Balance2Amt"),       "Date": row.get("Balance2Date"), "Mode": row.get("Balance2Mode","")},
            {"Amt": row.get("Balance3Amt"),       "Date": row.get("Balance3Date"), "Mode": row.get("Balance3Mode","")},
            {"Amt": row.get("Balance4Amt"),       "Date": row.get("Balance4Date"), "Mode": row.get("Balance4Mode","")},
        ]
        added = False
        for pay in payments:
            amt  = to_float(pay["Amt"])
            pdate = (pay["Date"] or "").strip()
            mode = (pay["Mode"] or "").strip()
            if not amt or amt <= 0 or not pdate: continue
            acct = acct_map.get(mode)
            if not acct: continue
            last = col("account_ledger").find_one({"AccountName": acct, "FY": fy}, sort=[("EntryDate", DESCENDING), ("Id", DESCENDING)])
            prev = to_float(last["Balance"]) if last else 0.0
            new_bal = prev + amt
            led_id = next_id("account_ledger")
            col("account_ledger").insert_one({
                "Id": led_id, "AccountName": acct, "EntryDate": pdate,
                "Description": desc, "CreditAmt": amt, "DebitAmt": 0,
                "Balance": new_bal, "EntryType": "Credit", "FY": fy,
                "ExpenseRef": None, "SalesRef": sno
            })
            added = True
            sales_count += 1
        if not added: skip_count += 1

    return ok({"ok": True, "expenseEntries": exp_count, "salesEntries": sales_count, "skipped": skip_count})

# ─────────────────────────────────────────────
#  BILLING — CUSTOMERS
# ─────────────────────────────────────────────
@app.get("/api/billing/status")
async def billing_status():
    cc = shared_col("rio_clients").count_documents({})
    pc = col("products").count_documents({})
    ic = col("sales_invoices").count_documents({"Status": {"$ne": "Cancelled"}})
    return JSONResponse(content={"ready": True, "server": "MongoDB Atlas", "database": MONGO_DB, "version": "3.0", "customers": cc, "products": pc, "invoices": ic})

@app.get("/api/billing/customers")
async def billing_get_customers(q: Optional[str] = Query(None), scope: Optional[str] = Query(None), user: Optional[str] = Query(None)):
    if q:
        query = {"$or": [
            {"ClientName": {"$regex": q, "$options": "i"}},
            {"Mobile": {"$regex": q, "$options": "i"}},
            {"GSTNo": {"$regex": q, "$options": "i"}},
        ]}
    else:
        query = {}
    # Customers are shared data — do NOT filter by createdBy/scope.
    # Scope (own/all) applies only to transactional data (sales, invoices, quotations).
    rows = list(shared_col("rio_clients").find(query, {"_id": 0}).sort("ClientName", ASCENDING))
    # Rename ClientName → Name for billing compatibility
    result = []
    for r in rows:
        result.append({
            "Id": r.get("Id"), "Name": r.get("ClientName",""),
            "BillToAddress": r.get("BillToAddress",""), "ShipToAddress": r.get("ShipToAddress",""),
            "State": r.get("State",""), "StateCode": r.get("StateCode",""),
            "Mobile": r.get("Mobile",""), "GSTNo": r.get("GSTNo",""),
            "Email": r.get("Email",""), "CustomerType": r.get("CustomerType",""),
        })
    return JSONResponse(content=result)

@app.post("/api/billing/customers")
async def billing_post_customer(request: Request):
    b = await request.json()
    name = (b.get("Name") or "").strip()
    if not name: return err("Name required")
    existing = shared_col("rio_clients").find_one({"ClientName": {"$regex": f"^{re.escape(name)}$", "$options": "i"}})
    update_doc = {
        "BillToAddress": b.get("BillToAddress",""), "ShipToAddress": b.get("ShipToAddress",""),
        "State": b.get("State",""), "StateCode": b.get("StateCode",""),
        "Mobile": b.get("Mobile",""), "GSTNo": b.get("GSTNo",""),
        "Email": b.get("Email",""), "CustomerType": b.get("CustomerType",""),
    }
    if existing:
        shared_col("rio_clients").update_one({"Id": existing["Id"]}, {"$set": update_doc})
        return ok({"success": True, "id": existing["Id"]})
    else:
        new_id = next_id("rio_clients")
        created_by = (b.get("createdBy") or "").strip()
        shared_col("rio_clients").insert_one({"Id": new_id, "ClientName": name, "createdBy": created_by, **update_doc})
        return ok({"success": True, "id": new_id})

@app.get("/api/billing/customers/byname")
async def billing_customer_byname(name: str = Query("")):
    if not name: return err("name required")
    r = shared_col("rio_clients").find_one({"ClientName": name}, {"_id": 0})
    if not r:
        r = shared_col("rio_clients").find_one({"ClientName": {"$regex": name, "$options": "i"}}, {"_id": 0})
    if not r: return err("Not found", 404)
    return JSONResponse(content={"Id": r.get("Id"), "Name": r.get("ClientName",""), **{k: r.get(k,"") for k in ["BillToAddress","ShipToAddress","State","StateCode","Mobile","GSTNo","Email","CustomerType"]}})

def _filled(v):
    return v is not None and bool(str(v).strip())

_CUST_DETAIL_FIELDS = ("BillToAddress", "ShipToAddress", "State", "StateCode", "Mobile", "GSTNo", "Email", "CustomerType")

def _cust_completeness(r):
    """Which duplicate to keep: the one with a GST number first, then a billing address, then the one with the
    most of the other details (shipping address, mobile, email, state, state code, type) filled in."""
    others = sum(1 for k in ("ShipToAddress", "Mobile", "Email", "State", "StateCode", "CustomerType") if _filled(r.get(k)))
    return (_filled(r.get("GSTNo")), _filled(r.get("BillToAddress")), others)

# NOTE: these two fixed-path routes must stay ABOVE the /{cust_id} routes - otherwise the server reads the word
# 'duplicates' as a customer id and answers HTTP 422.
@app.get("/api/billing/customers/duplicates")
async def billing_find_duplicate_customers():
    """Group existing customers by a normalized (trimmed, lowercased) name
    and return only the groups with more than one record - i.e. actual
    duplicates already sitting in the data, regardless of how they got
    there (case differences, pre-fix renames, etc.)."""
    if not await ensure_db(): return err("Database not connected", 503)
    all_custs = list(shared_col("rio_clients").find({}, {"_id": 0}))
    groups = {}
    for c in all_custs:
        name = (c.get("ClientName") or c.get("Name") or "").strip()
        if not name: continue
        groups.setdefault(name.lower(), []).append(c)
    dup_groups = []
    for recs in groups.values():
        if len(recs) < 2: continue
        # most complete record first (GST, then address, then the rest); on a tie the older record (lower Id) first
        recs.sort(key=lambda r: (_cust_completeness(r), -(r.get("Id") or 0)), reverse=True)
        dup_groups.append([{
            "Id": r.get("Id"), "Name": (r.get("ClientName") or r.get("Name") or "").strip(),
            "Mobile": r.get("Mobile", ""), "GSTNo": r.get("GSTNo", ""), "State": r.get("State", ""),
            "BillToAddress": r.get("BillToAddress", ""), "ShipToAddress": r.get("ShipToAddress", ""),
            "Email": r.get("Email", ""), "StateCode": r.get("StateCode", ""), "CustomerType": r.get("CustomerType", ""),
            "createdBy": r.get("createdBy", ""),
        } for r in recs])
    return JSONResponse(content={"groups": dup_groups, "count": len(dup_groups)})

@app.post("/api/billing/customers/merge-duplicates")
async def billing_merge_duplicate_customers(request: Request):
    """Merge one or more duplicate customer records into a single
    'keep' record: rewrites historical sales/invoices/quotations that
    used any of the removed records' names over to the kept record's
    current name, then deletes the removed records."""
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    keep_id = b.get("keepId")
    remove_ids = b.get("removeIds") or []
    if not keep_id or not remove_ids:
        return err("keepId and removeIds are required")
    keep = shared_col("rio_clients").find_one({"Id": keep_id}, {"_id": 0})
    if not keep:
        return err("Keep-customer not found", 404)
    current_name = (keep.get("ClientName") or keep.get("Name") or "").strip()
    if not current_name:
        return err("Kept customer has no name on record", 400)

    # Before anything is deleted, copy any detail the kept record is missing from the records being removed, so a GST
    # number / address / mobile held only by a duplicate is not lost. Where both have a value the kept record's wins.
    donors = []
    for rid in remove_ids:
        if rid == keep_id: continue
        d = shared_col("rio_clients").find_one({"Id": rid}, {"_id": 0})
        if d: donors.append(d)
    donors.sort(key=_cust_completeness, reverse=True)
    backfill = {}
    for k in _CUST_DETAIL_FIELDS:
        if not _filled(keep.get(k)):
            for d in donors:
                if _filled(d.get(k)):
                    backfill[k] = d[k]; break
    if backfill:
        shared_col("rio_clients").update_one({"Id": keep_id}, {"$set": backfill})
        keep.update(backfill)

    # What is written onto existing invoices / quotations: the name always, and a detail only when it HAS a value -
    # a blank never overwrites what an old invoice already says (e.g. its GST number).
    inv_update = {"CustomerName": current_name}
    for dst, src in (("CustomerGST", "GSTNo"), ("CustomerStateCode", "StateCode"), ("CustomerAddress", "BillToAddress"),
                     ("CustomerState", "State"), ("CustomerMobile", "Mobile"), ("CustomerEmail", "Email")):
        if _filled(keep.get(src)):
            inv_update[dst] = keep.get(src)
    sales_total = inv_total = quot_total = 0
    removed = []
    for rid in remove_ids:
        if rid == keep_id: continue
        rec = shared_col("rio_clients").find_one({"Id": rid}, {"_id": 0})
        if not rec: continue
        old_name = (rec.get("ClientName") or rec.get("Name") or "").strip()
        if old_name:
            name_regex = re.compile(f"^{re.escape(old_name)}$", re.IGNORECASE)
            sales_total += col("sales_records").update_many(
                {"Customer": name_regex}, {"$set": {"Customer": current_name}}
            ).modified_count
            inv_total += col("sales_invoices").update_many(
                {"$or": [{"CustomerId": rid}, {"CustomerName": name_regex}]}, {"$set": inv_update}
            ).modified_count
            quot_total += col("quotations").update_many(
                {"$or": [{"CustomerId": rid}, {"CustomerName": name_regex}]}, {"$set": inv_update}
            ).modified_count
        shared_col("rio_clients").delete_one({"Id": rid})
        removed.append(rid)

    return ok({"success": True, "removed": removed, "sales": sales_total, "invoices": inv_total, "quotations": quot_total, "carried": sorted(backfill)})

@app.get("/api/billing/customers/{cust_id}")
async def billing_get_customer(cust_id: int):
    r = shared_col("rio_clients").find_one({"Id": cust_id}, {"_id": 0})
    if not r: return err("Not found", 404)
    return JSONResponse(content={"Id": r.get("Id"), "Name": r.get("ClientName",""), **{k: r.get(k,"") for k in ["BillToAddress","ShipToAddress","State","StateCode","Mobile","GSTNo","Email","CustomerType"]}})

@app.put("/api/billing/customers/{cust_id}")
async def billing_put_customer(cust_id: int, request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    name = (b.get("Name") or "").strip()
    if not name:
        return err("Customer name required")
    name_collision = shared_col("rio_clients").find_one(
        {"ClientName": {"$regex": f"^{re.escape(name)}$", "$options": "i"}, "Id": {"$ne": cust_id}},
        {"_id": 0, "Id": 1}
    )
    if name_collision:
        return err(f"Another customer already has the name \"{name}\" (Id {name_collision['Id']}). "
                    f"Use Check Duplicates to merge them instead of renaming into a collision.", 409)
    ship = (b.get("ShipToAddress") or "").strip() or (b.get("BillToAddress") or "").strip()
    existing = shared_col("rio_clients").find_one({"Id": cust_id}, {"_id": 0, "ClientName": 1, "Name": 1, "PreviousNames": 1}) or {}
    update_set = {
        "ClientName":    name,
        "Name":          name,
        "Address":       b.get("Address", b.get("BillToAddress", "")),
        "BillToAddress": b.get("BillToAddress", ""),
        "ShipToAddress": ship,
        "State":         b.get("State", ""),
        "StateCode":     b.get("StateCode", ""),
        "Mobile":        b.get("Mobile", ""),
        "GSTNo":         b.get("GSTNo", ""),
        "Email":         b.get("Email", ""),
        "CustomerType":  b.get("CustomerType", ""),
    }
    # If the name actually changed, remember the old name so "Update
    # Everywhere" can still find historical sales/invoices/quotations that
    # were saved under that old spelling, even after this rename.
    old_name = (existing.get("ClientName") or existing.get("Name") or "").strip()
    if old_name and old_name.lower() != name.lower():
        prev = existing.get("PreviousNames") or []
        if old_name not in prev:
            prev.append(old_name)
        update_set["PreviousNames"] = prev
    result = shared_col("rio_clients").update_one({"Id": cust_id}, {"$set": update_set})
    if result.matched_count == 0:
        return err("Customer not found", 404)
    return ok({"success": True})

@app.post("/api/customers/{cust_id}/update-everywhere")
@app.post("/api/billing/customers/{cust_id}/update-everywhere")
async def customer_update_everywhere(cust_id: int, request: Request):
    """
    Push this customer's CURRENT details (name, GST, state, mobile, email,
    address) onto every existing sales record, invoice and quotation that
    was saved under this customer's current name OR any of its previously
    known names (tracked automatically whenever the customer is renamed).
    This does not change any totals/amounts — only the customer-identifying
    text fields that were copied onto those records at the time they were
    created.

    Optional body: {"oldName": "..."} — manually add an old spelling to
    search for, useful if a rename happened before this tracking existed.
    """
    if not await ensure_db(): return err("Database not connected", 503)
    cust = shared_col("rio_clients").find_one({"Id": cust_id}, {"_id": 0})
    if not cust:
        return err("Customer not found", 404)

    try:
        body = await request.json()
    except Exception:
        body = {}
    manual_old_name = (body.get("oldName") or "").strip() if isinstance(body, dict) else ""

    current_name = (cust.get("ClientName") or cust.get("Name") or "").strip()
    if not current_name:
        return err("This customer has no name on record", 400)
    prev_names = cust.get("PreviousNames") or []
    all_names = list({current_name, *prev_names})
    if manual_old_name:
        all_names.append(manual_old_name)
        # Persist it for next time too, so this only needs to be done once.
        if manual_old_name not in prev_names:
            shared_col("rio_clients").update_one(
                {"Id": cust_id},
                {"$addToSet": {"PreviousNames": manual_old_name}}
            )

    name_regex = {"$in": [re.compile(f"^{re.escape(n)}$", re.IGNORECASE) for n in all_names]}

    # ── Sales records: only the plain Customer text field exists here ──
    sales_result = col("sales_records").update_many(
        {"Customer": name_regex},
        {"$set": {"Customer": current_name}}
    )

    # ── Invoices: name + GST + state code + address/mobile/email ──
    inv_update = {
        "CustomerName":       current_name,
        "CustomerGST":        cust.get("GSTNo", ""),
        "CustomerStateCode":  cust.get("StateCode", ""),
        "CustomerAddress":    cust.get("BillToAddress", ""),
        "CustomerState":      cust.get("State", ""),
        "CustomerMobile":     cust.get("Mobile", ""),
        "CustomerEmail":      cust.get("Email", ""),
    }
    inv_result = col("sales_invoices").update_many(
        {"$or": [{"CustomerId": cust_id}, {"CustomerName": name_regex}]},
        {"$set": inv_update}
    )

    # ── Quotations: same fields as invoices ──
    quot_result = col("quotations").update_many(
        {"$or": [{"CustomerId": cust_id}, {"CustomerName": name_regex}]},
        {"$set": inv_update}
    )

    return ok({
        "success": True,
        "sales": sales_result.modified_count,
        "invoices": inv_result.modified_count,
        "quotations": quot_result.modified_count,
    })

@app.delete("/api/billing/customers/{cust_id}")
async def billing_delete_customer(cust_id: int, user: Optional[str] = Query(None), scope: Optional[str] = Query(None)):
    if not await ensure_db(): return err("Database not connected", 503)
    # IMPORTANT: find_one with an inclusion projection like {"createdBy": 1}
    # returns an EMPTY DICT {} (not None) when the document exists but has
    # no createdBy field — and {} is falsy in Python, so `if not record`
    # incorrectly treated "found, but no createdBy" the same as "not found".
    # Fix: check existence explicitly with `record is None`, and rely on
    # full deletion only after we've confirmed it actually exists.
    exists = shared_col("rio_clients").count_documents({"Id": cust_id}, limit=1) > 0
    if not exists:
        return err("Customer not found", 404)
    record = shared_col("rio_clients").find_one({"Id": cust_id}, {"_id": 0, "createdBy": 1}) or {}
    # Scope check: scoped users can only delete their own records
    if scope == "own" and user:
        record_owner = record.get("createdBy", "")
        if record_owner and record_owner != user:
            return err("Access denied — you can only delete customers you created.", 403)
    shared_col("rio_clients").delete_one({"Id": cust_id})
    return ok({"success": True})

# ─────────────────────────────────────────────
#  ADMIN — FULL DATABASE BACKUP / RESTORE
#  Covers both company databases (RioPrintMedia and RainbowUmbrellas),
#  every collection in each. Gated to admin-only in the UI; this endpoint
#  itself doesn't carry its own auth check, same trust model as the rest
#  of this backend's admin-ish endpoints - the button is simply never
#  shown to non-admins.
# ─────────────────────────────────────────────
@app.get("/api/admin/backup")
async def admin_backup_database(request: Request):
    _g = await admin_guard(request)
    if _g: return _g
    if not await ensure_db(): return err("Database not connected", 503)
    if not _client: return err("No DB client")
    from bson import json_util
    result = {}
    warnings = []
    for db_name in [MONGO_DB, MONGO_DB_RAINBOW]:
        try:
            db = _client[db_name]
            db_dump = {}
            for coll_name in db.list_collection_names():
                try:
                    db_dump[coll_name] = list(db[coll_name].find({}, {"_id": 0}))
                except Exception as e:
                    warnings.append(f"{db_name}.{coll_name}: {e}")
            result[db_name] = db_dump
        except Exception as e:
            # One database being unreachable (permissions, doesn't exist on this
            # cluster tier, etc.) shouldn't sink the whole backup - record it and
            # keep going so the other database still gets backed up.
            warnings.append(f"{db_name}: {e}")
    payload = {
        "takenAt": datetime.utcnow().isoformat(),
        "databases": result,
        "warnings": warnings,
    }
    try:
        # json_util.dumps (not plain json.dumps/JSONResponse) is what actually
        # handles datetime, ObjectId, Decimal128 and other BSON types that real
        # Mongo documents commonly contain - a plain JSONResponse throws on the
        # first such field it hits anywhere in any collection, which is almost
        # certainly what the HTTP 500 was.
        body = json_util.dumps(payload)
        return Response(content=body, media_type="application/json")
    except Exception as e:
        return err(f"Backup built but could not be serialized: {e}", 500)

@app.post("/api/admin/restore")
async def admin_restore_database(request: Request):
    _g = await admin_guard(request)
    if _g: return _g
    if not await ensure_db(): return err("Database not connected", 503)
    if not _client: return err("No DB client")
    from bson import json_util
    try:
        raw = await request.body()
        body = json_util.loads(raw)
    except Exception as e:
        return err(f"Could not parse backup file: {e}")
    databases = body.get("databases")
    if not isinstance(databases, dict) or not databases:
        return err("Backup file has no 'databases' section - is this a valid backup file?")
    try:
        summary = {}
        for db_name, collections in databases.items():
            if not isinstance(collections, dict): continue
            db = _client[db_name]
            db_summary = {}
            for coll_name, docs in collections.items():
                if not isinstance(docs, list): continue
                db[coll_name].delete_many({})
                if docs:
                    db[coll_name].insert_many([{k: v for k, v in d.items() if k != "_id"} for d in docs], ordered=False)
                db_summary[coll_name] = len(docs)
            summary[db_name] = db_summary
        if MONGO_DB in databases:
            reseed_counters()                  # the restored counters have no _id: rebuild them, or the next new entry could get a number that is already taken
        return ok({"success": True, "restored": summary})
    except Exception as e:
        return err(str(e), 500)

# ─────────────────────────────────────────────
#  BILLING — PRODUCTS
# ─────────────────────────────────────────────
@app.get("/api/billing/products/nextcode")
async def billing_nextcode():
    return JSONResponse(content={"code": next_product_code()})

@app.get("/api/billing/products")
async def billing_get_products(q: Optional[str] = Query(None)):
    if q:
        query = {"$or": [{"Name": {"$regex": q, "$options": "i"}}, {"Code": {"$regex": q, "$options": "i"}}]}
    else:
        query = {}
    rows = list(col("products").find(query, {"_id": 0}).sort("Code", ASCENDING))
    return JSONResponse(content=rows)

@app.post("/api/billing/products")
async def billing_post_product(request: Request):
    b = await request.json()
    name = (b.get("Name") or "").strip()
    if not name: return err("Name required")
    code = (b.get("Code") or "").strip() or next_product_code()
    new_id = next_id("products")
    col("products").insert_one({
        "Id": new_id, "Code": code, "Name": name,
        "createdBy": (b.get("createdBy") or "").strip(),
        "PrintName": b.get("PrintName",""), "HSN": b.get("HSN",""),
        "Category": b.get("Category",""), "Unit": b.get("Unit","Nos"),
        "GSTRate": to_float(b.get("GSTRate"), 18.0),
    })
    return ok({"success": True, "id": new_id, "code": code})

@app.get("/api/billing/products/{prod_id}")
async def billing_get_product(prod_id: int):
    r = col("products").find_one({"Id": prod_id}, {"_id": 0})
    if not r: return err("Not found", 404)
    return JSONResponse(content=r)

@app.put("/api/billing/products/{prod_id}")
async def billing_put_product(prod_id: int, request: Request):
    b = await request.json()
    col("products").update_one({"Id": prod_id}, {"$set": {
        "Code": b.get("Code",""), "Name": b.get("Name",""),
        "PrintName": b.get("PrintName",""), "HSN": b.get("HSN",""),
        "Category": b.get("Category",""), "Unit": b.get("Unit","Nos"),
        "GSTRate": to_float(b.get("GSTRate"), 18.0),
    }})
    return ok({"success": True})

@app.delete("/api/billing/products/{prod_id}")
async def billing_delete_product(prod_id: int, user: Optional[str] = Query(None), scope: Optional[str] = Query(None)):
    if not await ensure_db(): return err("Database not connected", 503)
    exists = col("products").count_documents({"Id": prod_id}, limit=1) > 0
    if not exists:
        return err("Product not found", 404)
    record = col("products").find_one({"Id": prod_id}, {"_id": 0, "createdBy": 1}) or {}
    # Scope check: scoped users can only delete their own records
    if scope == "own" and user:
        record_owner = record.get("createdBy", "")
        if record_owner and record_owner != user:
            return err("Access denied — you can only delete products you created.", 403)
    col("products").delete_one({"Id": prod_id})
    return ok({"success": True})

# ─────────────────────────────────────────────
#  BILLING — INVOICE SEQUENCES
# ─────────────────────────────────────────────
# ── Invoice numbering: cancel instead of delete ─────────────────────────────────────────────────────
# An issued invoice keeps its number for ever. Mistakes are fixed by CANCELLING (number kept, record kept,
# marked CANCELLED, left out of totals and reports) rather than deleting, so the series never has silent gaps.
def _inv_prefix(inv_no):
    m = re.match(r'^([A-Za-z]+)\d', (inv_no or '').strip())
    return m.group(1) if m else ''

def _inv_series_regex(inv_no):
    p = _inv_prefix(inv_no)
    return (r'^%s\d' % re.escape(p)) if p else r'^\d'

def _inv_is_nongst(inv_no):
    return _inv_prefix(inv_no).upper() in ("RN", "RUN", "GDN")

async def _caller_username(request: Request):
    try:
        tok = _bearer_token(request)
        u = _db["rio_users"].find_one({"session_token": tok}, {"_id": 0}) if tok else None
        return (u or {}).get("username", "") or ""
    except Exception:
        return ""

@app.post("/api/billing/invoices/mark-issued")
async def billing_mark_invoice_issued(invno: str = Query("")):
    """Called when an invoice is printed / turned into a PDF: from then on it can only be cancelled, not deleted."""
    if not await ensure_db(): return err("Database not connected", 503)
    if not invno: return err("invno required")
    inv = col("sales_invoices").find_one({"InvoiceNo": invno}, {"_id": 0, "Id": 1, "Status": 1, "Issued": 1}, sort=[("Id", DESCENDING)])
    if not inv: return ok({"success": True, "found": False})
    if inv.get("Status") != "Cancelled" and not inv.get("Issued"):
        col("sales_invoices").update_one({"Id": inv["Id"]}, {"$set": {"Issued": True, "IssuedAt": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}})
    return ok({"success": True, "found": True})

@app.get("/api/billing/invoices/gaps")
async def billing_invoice_gaps(fy: str = Query("")):
    """Numbering check: for each series (R01.. / RN01.. / RU01.. ...) in the financial year, which numbers are missing -
    and which numbers are used by MORE THAN ONE invoice (duplicates)."""
    if not await ensure_db(): return err("Database not connected", 503)
    if not fy: fy = current_fy()
    fy_from, fy_to = fy_range(fy)
    rows = list(col("sales_invoices").find({"$or": [{"FY": fy}, {"$and": [{"FY": None}, {"InvoiceDate": {"$gte": fy_from, "$lte": fy_to}}]}]},
                                           {"_id": 0, "Id": 1, "InvoiceNo": 1, "InvoiceDate": 1, "CustomerId": 1, "CustomerName": 1, "TotalAmount": 1, "Status": 1, "Issued": 1, "createdBy": 1}))
    series = {}; by_no = {}
    for r in rows:
        no = (r.get("InvoiceNo") or "").strip()
        if no: by_no.setdefault(no, []).append(r)
        m = re.match(r'^([A-Za-z]+)(\d+)$', no)
        if not m: continue
        d = series.setdefault(m.group(1), {"numbers": set(), "cancelled": set()})
        n = int(m.group(2)); d["numbers"].add(n)
        if r.get("Status") == "Cancelled": d["cancelled"].add(n)
    out = []
    for pfx, d in sorted(series.items()):
        mx = max(d["numbers"])
        out.append({"prefix": pfx, "count": len(d["numbers"]), "max": mx,
                    "missing": ["%s%02d" % (pfx, n) for n in range(1, mx + 1) if n not in d["numbers"]],
                    "cancelled": ["%s%02d" % (pfx, n) for n in sorted(d["cancelled"])]})
    dups = []
    for no, lst in sorted(by_no.items()):
        if len([x for x in lst if x.get("Status") != "Cancelled"]) > 1:      # a number is in conflict only while TWO OR MORE live (not cancelled) invoices use it
            dups.append({"InvoiceNo": no, "invoices": [
                {"Id": x.get("Id"), "InvoiceDate": x.get("InvoiceDate", ""), "CustomerId": x.get("CustomerId", 0), "CustomerName": x.get("CustomerName", ""), "TotalAmount": x.get("TotalAmount", 0),
                 "Status": x.get("Status", "") or "", "Issued": bool(x.get("Issued")), "createdBy": x.get("createdBy", "") or "",
                 # a live copy can be REMOVED when another live copy has the same number and the same customer
                 "canRemove": x.get("Status") != "Cancelled" and any(y is not x and y.get("Status") != "Cancelled" and _same_customer(x, y) for y in lst)}
                for x in sorted(lst, key=lambda x: x.get("Id") or 0)]})
    return JSONResponse(content={"fy": fy, "series": out, "duplicates": dups})

@app.post("/api/billing/invoices/{inv_id}/cancel")
async def billing_cancel_invoice(inv_id: int, request: Request):
    """Cancel an invoice (admin only, reason required). The number and the record are kept."""
    _g = await admin_guard(request)
    if _g: return _g
    b = await request.json()
    reason = (b.get("reason") or "").strip()
    if len(reason) < 3: return err("Please give a reason for cancelling the invoice.", 400)
    inv = col("sales_invoices").find_one({"Id": inv_id}, {"_id": 0})
    if not inv: return err("Invoice not found", 404)
    if inv.get("Status") == "Cancelled": return err("This invoice is already cancelled.", 409)
    inv_no = inv.get("InvoiceNo", "")
    # If ANOTHER live invoice of the same year uses the same number (a duplicate), the sale linked to that number may belong to it - leave the number-only link alone.
    shared = _number_shared(inv)
    linked = _sales_of_invoice(inv, shared)
    col("sales_invoices").update_one({"Id": inv_id}, {"$set": {
        "Status": "Cancelled", "CancelReason": reason, "CancelledBy": await _caller_username(request),
        "CancelledAt": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "CancelledSalesSNo": linked}})
    # the sale it was made for can be invoiced again (with a NEW number)
    _release_sales(linked)
    return ok({"success": True, "invoiceNo": inv_no, "unlinkedSales": linked, "sharedNumber": shared})

def _same_customer(a, b):
    """same customer = same customer id, or the same name (ignoring case and extra spaces)"""
    ia, ib = a.get("CustomerId"), b.get("CustomerId")
    if ia and ib and str(ia) == str(ib): return True
    na = re.sub(r"\s+", " ", str(a.get("CustomerName") or "").strip()).lower()
    nb = re.sub(r"\s+", " ", str(b.get("CustomerName") or "").strip()).lower()
    return bool(na) and na == nb

@app.post("/api/billing/invoices/{inv_id}/remove-duplicate")
async def billing_remove_duplicate_invoice(inv_id: int, request: Request):
    """Admin only. Remove one copy of an invoice that exists TWICE for the same customer under the same number.
    Allowed only while another live (not cancelled) invoice with the same number AND the same customer remains.
    The removed copy (with its lines) is kept in the 'removed_invoices' table; sales stay linked (the number is still used)."""
    _g = await admin_guard(request)
    if _g: return _g
    if not await ensure_db(): return err("Database not connected", 503)
    inv = col("sales_invoices").find_one({"Id": inv_id}, {"_id": 0})
    if inv is None: return err("Invoice not found", 404)
    if inv.get("Status") == "Cancelled": return err("A cancelled invoice is kept for the record and cannot be removed.", 409)
    inv_no = (inv.get("InvoiceNo") or "").strip()
    fy = inv.get("FY") or fy_from_date((inv.get("InvoiceDate") or "")[:10])
    f0, f1 = fy_range(fy)
    others = list(col("sales_invoices").find({"InvoiceNo": inv_no, "Id": {"$ne": inv_id}, "Status": {"$ne": "Cancelled"},
                  "$or": [{"FY": fy}, {"$and": [{"FY": None}, {"InvoiceDate": {"$gte": f0, "$lte": f1}}]}]}, {"_id": 0}))
    twins = [o for o in others if _same_customer(inv, o)]
    if not twins:
        return err("No other invoice with the same number AND the same customer exists, so this is not a duplicate. If it is a different bill, give it a new number instead.", 409)
    items = list(col("sales_items").find({"InvoiceId": inv_id}, {"_id": 0}))
    col("removed_invoices").insert_one({"RemovedAt": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "RemovedBy": await _caller_username(request),
                                        "Reason": "duplicate (same number and same customer)", "WasPrinted": bool(inv.get("Issued")), "KeptIds": [t.get("Id") for t in twins],
                                        "Invoice": inv, "Items": items})
    col("sales_items").delete_many({"InvoiceId": inv_id})
    col("sales_invoices").delete_one({"Id": inv_id})
    return ok({"success": True, "invoiceNo": inv_no, "removedId": inv_id, "keptIds": [t.get("Id") for t in twins]})

@app.post("/api/billing/invoices/{inv_id}/renumber")
async def billing_renumber_invoice(inv_id: int, request: Request):
    """Admin only. Give ONE invoice, whose number is shared with another invoice, the next free number of its series.
    Refused when the number is not actually shared, and for cancelled invoices (they keep their number)."""
    _g = await admin_guard(request)
    if _g: return _g
    if not await ensure_db(): return err("Database not connected", 503)
    inv = col("sales_invoices").find_one({"Id": inv_id}, {"_id": 0})
    if inv is None: return err("Invoice not found", 404)
    if inv.get("Status") == "Cancelled": return err("A cancelled invoice keeps its number.", 409)
    old_no = (inv.get("InvoiceNo") or "").strip()
    if not old_no: return err("This invoice has no number.", 400)
    fy = inv.get("FY") or fy_from_date((inv.get("InvoiceDate") or "")[:10])
    f0, f1 = fy_range(fy)
    others = list(col("sales_invoices").find({"InvoiceNo": old_no, "Id": {"$ne": inv_id}, "Status": {"$ne": "Cancelled"},
                  "$or": [{"FY": fy}, {"$and": [{"FY": None}, {"InvoiceDate": {"$gte": f0, "$lte": f1}}]}]}, {"_id": 0, "Id": 1}))
    if not others: return err("Number " + old_no + " is not shared with another live invoice, so there is nothing to renumber.", 409)
    new_no = next_invoice_no("NonGST" if _inv_is_nongst(old_no) else "GST", fy)
    # sales are linked to an invoice by its number; with a shared number we cannot tell which sale belongs to which invoice, so they are left alone and reported
    linked = [r.get("SNo") for r in col("sales_records").find({"InvoiceNo": old_no}, {"_id": 0, "SNo": 1})]
    col("sales_invoices").update_one({"Id": inv_id}, {"$set": {"InvoiceNo": new_no, "FY": fy, "RenumberedFrom": old_no,
        "RenumberedBy": await _caller_username(request), "RenumberedAt": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}})
    return ok({"success": True, "oldNo": old_no, "newNo": new_no, "linkedSales": linked})

@app.get("/api/billing/invoices/peek")
async def billing_invoice_peek(type: str = Query("GST"), fy: str = Query("")):
    if not fy: fy = current_fy()
    return JSONResponse(content={"invoiceNo": next_invoice_no(type, fy)})

@app.get("/api/billing/invoices/next")
async def billing_invoice_next(type: str = Query("GST"), fy: str = Query("")):
    if not fy: fy = current_fy()
    return JSONResponse(content={"invoiceNo": next_invoice_no(type, fy)})

@app.post("/api/billing/invoices/resetsequence")
async def billing_reset_sequence(type: str = Query("GST")):
    return ok({"success": True, "type": type})

# ─────────────────────────────────────────────
#  BILLING — INVOICES
# ─────────────────────────────────────────────
@app.get("/api/billing/invoices/byno")
async def billing_invoice_byno(invno: str = Query(""), fy: str = Query("")):
    if not invno: return err("invno required")
    query = {"InvoiceNo": invno}
    if fy:
        fy_from, fy_to = fy_range(fy)
        query["InvoiceDate"] = {"$gte": fy_from, "$lte": fy_to}
    inv = col("sales_invoices").find_one(query, {"_id": 0}, sort=[("Id", DESCENDING)])
    if not inv: return err("Not found", 404)
    inv_id = inv.get("Id")
    items = list(col("sales_items").find({"InvoiceId": inv_id}, {"_id": 0}).sort("SNo", ASCENDING))
    # Fetch customer details
    cust = {}
    if inv.get("CustomerId"):
        c = shared_col("rio_clients").find_one({"Id": inv["CustomerId"]}, {"_id": 0})
        if c:
            cust = {"CustomerAddress": c.get("BillToAddress",""), "CustomerState": c.get("State",""),
                    "CustomerStateCode": c.get("StateCode",""), "CustomerMobile": c.get("Mobile",""),
                    "CustomerGST": c.get("GSTNo",""), "CustomerEmail": c.get("Email","")}
    # Keep InvoiceDate as the raw YYYY-MM-DD stored in MongoDB. Previously
    # this was reformatted to DD-MM-YYYY, which broke the edit form's date
    # input (which requires YYYY-MM-DD) and is unreliable for fd()'s
    # new Date(d) parsing on the frontend (DD-MM-YYYY is ambiguous/invalid
    # in JS Date parsing across browsers).
    return JSONResponse(content={**inv, **cust, "Items": items})

@app.get("/api/billing/invoices")
async def billing_get_invoices(
    page: int = Query(1), pageSize: int = Query(50),
    fr: Optional[str] = Query(None, alias="from"), to: Optional[str] = Query(None),
    type: Optional[str] = Query(None), q: Optional[str] = Query(None),
    scope: Optional[str] = Query(None), user: Optional[str] = Query(None),
    includeCancelled: int = Query(0)
):
    pageSize = max(1, min(pageSize, 500))
    query = {}
    if fr or to:
        query["InvoiceDate"] = {}
        if fr: query["InvoiceDate"]["$gte"] = fr
        if to: query["InvoiceDate"]["$lte"] = to
    if type == "GST":    query["BillingType"] = {"$in": ["GST", "IGST"]}
    if type == "NONGST": query["BillingType"] = "NON-GST"
    if q:
        # Also search by product name — find invoice IDs that have matching items
        matching_item_inv_ids = [
            r["InvoiceId"] for r in col("sales_items").find(
                {"ProductName": {"$regex": q, "$options": "i"}}, {"InvoiceId": 1, "_id": 0}
            )
        ]
        query["$or"] = [
            {"CustomerName": {"$regex": q, "$options": "i"}},
            {"InvoiceNo":    {"$regex": q, "$options": "i"}},
            {"Id":           {"$in": matching_item_inv_ids}},
        ]
    if scope == "own" and user: query["createdBy"] = user
    if not includeCancelled: query["Status"] = {"$ne": "Cancelled"}   # cancelled invoices stay out of totals and reports
    total = col("sales_invoices").count_documents(query)
    skip  = (page - 1) * pageSize
    rows  = list(col("sales_invoices").find(query, {"_id": 0, "Id":1,"InvoiceNo":1,"InvoiceDate":1,"CustomerName":1,"BillingType":1,"SubTotal":1,"CGST":1,"SGST":1,"IGST":1,"TotalAmount":1,"Counter":1,"PaymentTerms":1,"createdBy":1,"CustomerGST":1,"PlaceOfSupply":1,"Status":1,"CancelReason":1,"CancelledAt":1,"CancelledBy":1,"Issued":1})
                .sort([("InvoiceDate", DESCENDING), ("Id", DESCENDING)]).skip(skip).limit(pageSize))
    
    # Build product HSN lookup map (Name/PrintName → HSN)
    hsn_lookup = {}
    try:
        for prod in col("products").find({}, {"_id": 0, "Name": 1, "PrintName": 1, "HSN": 1}):
            hsn = prod.get("HSN", "")
            if prod.get("Name"):  hsn_lookup[prod["Name"].strip().lower()] = hsn
            if prod.get("PrintName"): hsn_lookup[prod["PrintName"].strip().lower()] = hsn
    except Exception:
        pass

    # Fetch HSN and Qty from sales_items for each invoice
    processed_rows = []
    for r in rows:
        row_data = dict(r)
        row_data["HSN"] = ""
        row_data["Quantity"] = 0

        # Get first item from sales_items collection
        item = col("sales_items").find_one({"InvoiceId": r.get("Id")}, {"_id": 0, "HSN": 1, "Qty": 1, "ProductName": 1, "Description": 1})
        if item:
            hsn = (item.get("HSN") or "").strip()
            # If HSN empty in item, look up from product catalog
            if not hsn:
                pname = (item.get("ProductName") or item.get("Description") or "").strip().lower()
                hsn = hsn_lookup.get(pname, "")
            row_data["HSN"] = hsn
            row_data["Quantity"] = to_float(item.get("Qty", 0), 0)

        processed_rows.append(row_data)
    
    return JSONResponse(content={"data": processed_rows, "total": total, "page": page, "pageSize": pageSize})

@app.post("/api/admin/backfill-hsn")
async def backfill_hsn():
    """One-time fix for invoices/sales created before HSN capture existed.
    Matches each old line item to the product catalog by ProductId first
    (most reliable), falling back to a case-insensitive name match, and
    fills in HSN wherever a match with a real HSN value is found. Items
    whose product has no HSN in the catalog either are left as-is and
    reported separately, since there's nothing to backfill them from."""
    if not await ensure_db(): return err("Database not connected", 503)

    products = list(col("products").find({}, {"_id": 0, "Id": 1, "Name": 1, "PrintName": 1, "HSN": 1}))
    by_id = {str(p.get("Id")): p.get("HSN", "") for p in products if p.get("Id")}
    by_name = {}
    for p in products:
        hsn = p.get("HSN", "")
        if not hsn:
            continue
        for key in (p.get("Name", ""), p.get("PrintName", "")):
            k = (key or "").strip().lower()
            if k:
                by_name[k] = hsn

    def resolve_hsn(product_id, product_name):
        hsn = by_id.get(str(product_id), "")
        if hsn:
            return hsn
        return by_name.get((product_name or "").strip().lower(), "")

    results = {}
    for coll_name, is_invoice_items in [("sales_items", True), ("sales_records", False)]:
        fixed = 0
        unmatched = 0
        if is_invoice_items:
            for doc in col(coll_name).find({"$or": [{"HSN": ""}, {"HSN": {"$exists": False}}]}):
                hsn = resolve_hsn(doc.get("ProductId"), doc.get("ProductName"))
                if hsn:
                    col(coll_name).update_one({"_id": doc["_id"]}, {"$set": {"HSN": hsn}})
                    fixed += 1
                elif doc.get("ProductName"):
                    unmatched += 1
        else:
            for doc in col(coll_name).find({"Items": {"$exists": True, "$ne": []}}):
                items = doc.get("Items") or []
                changed = False
                for it in items:
                    if it.get("HSN"):
                        continue
                    hsn = resolve_hsn(it.get("ProductId"), it.get("ProductName"))
                    if hsn:
                        it["HSN"] = hsn
                        changed = True
                        fixed += 1
                    elif it.get("ProductName"):
                        unmatched += 1
                if changed:
                    col(coll_name).update_one({"_id": doc["_id"]}, {"$set": {"Items": items}})
        results[coll_name] = {"fixed": fixed, "still_unmatched_no_catalog_hsn": unmatched}

    return ok(results)

@app.get("/api/billing/invoices/{inv_id}")
async def billing_get_invoice(inv_id: int):
    r = col("sales_invoices").find_one({"Id": inv_id}, {"_id": 0})
    if not r: return err("Invoice not found", 404)
    # Include line items and customer details in the same response so the
    # frontend doesn't need a second round-trip (to /byno) just to get them —
    # that extra call was adding a real, avoidable delay every time an
    # invoice was opened for editing.
    items = list(col("sales_items").find({"InvoiceId": inv_id}, {"_id": 0}).sort("SNo", ASCENDING))
    cust = {}
    if r.get("CustomerId"):
        c = shared_col("rio_clients").find_one({"Id": r["CustomerId"]}, {"_id": 0})
        if c:
            cust = {"CustomerAddress": c.get("BillToAddress",""), "CustomerState": c.get("State",""),
                    "CustomerStateCode": c.get("StateCode",""), "CustomerMobile": c.get("Mobile",""),
                    "CustomerGST": c.get("GSTNo",""), "CustomerEmail": c.get("Email","")}
    return JSONResponse(content={**r, **cust, "Items": items})

@app.post("/api/billing/invoices")
async def billing_post_invoice(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    inv_no = (b.get("InvoiceNo") or "").strip()
    if not inv_no: return err("InvoiceNo required")
    raw_date = b.get("InvoiceDate", "")
    try:
        inv_date = datetime.strptime(raw_date[:10], "%Y-%m-%d").strftime("%Y-%m-%d")
    except:
        inv_date = datetime.now().strftime("%Y-%m-%d")
    fy = fy_from_date(inv_date)
    _f0, _f1 = fy_range(fy)
    if col("sales_invoices").find_one({"InvoiceNo": inv_no, "$or": [{"FY": fy}, {"$and": [{"FY": None}, {"InvoiceDate": {"$gte": _f0, "$lte": _f1}}]}]}, {"_id": 0, "Id": 1}):
        _nx = next_invoice_no("NonGST" if _inv_is_nongst(inv_no) else "GST", fy)
        return err(f"Invoice number {inv_no} is already used by another invoice (someone may have just saved it). The next free number is {_nx} - refresh the number and save again.", 409)
    # ---- an invoice made FROM a sales entry (SalesSNo): one sales entry, one invoice ----
    sales_sno = to_int(b.get("SalesSNo"), 0)
    sale, prev_link = None, None
    if sales_sno:
        sale = col("sales_records").find_one({"SNo": sales_sno}, {"_id": 0, "SNo": 1, "InvoiceNo": 1, "InvoiceId": 1, "OrderDate": 1, "Customer": 1})
        if sale:
            prev_link = sale.get("InvoiceNo")
            have = _linked_invoice(sale)
            if have and have.get("Status") != "Cancelled":
                return err2(f"Invoice {have.get('InvoiceNo')} was already generated for this sales entry. A new one can be made only after that invoice is deleted.", 409,
                            alreadyGenerated=True, invoiceNo=have.get("InvoiceNo"), invoiceId=have.get("Id"), invoiceDate=have.get("InvoiceDate"), fy=_inv_fy(have))
    new_id = next_id("sales_invoices")
    doc = {
        "Id": new_id, "Branch": "HO", "InvoiceNo": inv_no, "InvoiceDate": inv_date,
        "createdBy": (b.get("createdBy") or "").strip(),
        "CustomerId": to_int(b.get("CustomerId"), 0),
        "CustomerName": b.get("CustomerName",""), "BillingType": b.get("BillingType",""),
        "CustomerGST": b.get("CustomerGST",""),
        "PlaceOfSupply": b.get("PlaceOfSupply",""), "PlaceOfSupplyCode": b.get("PlaceOfSupplyCode",""),
        "SubTotal": to_float(b.get("SubTotal"),0), "CGST": to_float(b.get("CGST"),0),
        "SGST": to_float(b.get("SGST"),0), "IGST": to_float(b.get("IGST"),0),
        "TotalAmount": to_float(b.get("TotalAmount"),0),
        "Counter": b.get("Counter",""), "PaymentTerms": b.get("PaymentTerms",""), "FY": fy
    }
    col("sales_invoices").insert_one(doc)
    sno = 1
    for item in (b.get("Items") or []):
        if not item: continue
        qty = to_float(item.get("Qty"),0); rate = to_float(item.get("Rate"),0)
        tv  = to_float(item.get("TaxableValue"), qty*rate if qty and rate else 0)
        it  = to_float(item.get("Total"), tv)
        if not item.get("ProductName") and not tv: continue
        col("sales_items").insert_one({
            "InvoiceId": new_id, "SNo": sno,
            "ProductName": item.get("ProductName",""), "HSN": item.get("HSN",""),
            "Qty": qty, "Rate": rate, "TaxableValue": tv,
            "GSTRate": to_float(item.get("GSTRate"),0), "Total": it,
            "SizeNotes": item.get("SizeNotes","")
        })
        sno += 1
    if sale is not None:
        # link the sales entry to this invoice, but only if nobody linked it in the meantime (two clicks, two users): the filter is the value we read
        r = col("sales_records").update_one({"SNo": sales_sno, "InvoiceNo": prev_link}, {"$set": {"InvoiceNo": inv_no, "InvoiceId": new_id}})
        if getattr(r, "matched_count", 1) == 0:
            col("sales_items").delete_many({"InvoiceId": new_id}); col("sales_invoices").delete_one({"Id": new_id})          # undo ours
            now = col("sales_records").find_one({"SNo": sales_sno}, {"_id": 0, "SNo": 1, "InvoiceNo": 1, "InvoiceId": 1, "OrderDate": 1}) or {}
            have = _linked_invoice(now) or {}
            return err2(f"Invoice {have.get('InvoiceNo') or now.get('InvoiceNo') or ''} was already generated for this sales entry.", 409, alreadyGenerated=True,
                        invoiceNo=have.get("InvoiceNo") or now.get("InvoiceNo") or "", invoiceId=have.get("Id"), invoiceDate=have.get("InvoiceDate"), fy=_inv_fy(have) if have else "")
    return ok({"success": True, "id": new_id, "invoiceNo": inv_no, "invoiceDate": inv_date, "fy": fy})


@app.patch("/api/billing/invoices/{inv_id}/refresh-customer")
async def refresh_invoice_customer(inv_id: int):
    if not await ensure_db(): return err("Database not connected", 503)
    exists = col("sales_invoices").count_documents({"Id": inv_id}, limit=1) > 0
    if not exists: return err("Invoice not found", 404)
    inv = col("sales_invoices").find_one({"Id": inv_id}, {"_id": 0, "CustomerId": 1}) or {}
    cust_id = inv.get("CustomerId")
    if not cust_id: return err("No customer linked to this invoice", 400)
    cust = shared_col("rio_clients").find_one({"Id": cust_id}, {"_id": 0})
    if not cust: return err("Customer not found", 404)
    update = {
        "CustomerName":    cust.get("Name") or cust.get("ClientName") or "",
        "CustomerGST":     cust.get("GSTNo") or cust.get("GSTIN") or "",
        "CustomerMobile":  cust.get("Mobile") or cust.get("Phone") or "",
        "CustomerEmail":   cust.get("Email") or "",
        "BillToAddress":   cust.get("BillToAddress") or cust.get("Address") or "",
        "ShipToAddress":   cust.get("ShipToAddress") or cust.get("BillToAddress") or cust.get("Address") or "",
        "PlaceOfSupply":   cust.get("State") or "",
    }
    col("sales_invoices").update_one({"Id": inv_id}, {"$set": update})
    return ok({"success": True, "updated": update})

@app.patch("/api/quotations/{qid}/refresh-customer")
async def refresh_quotation_customer(qid: str):
    if not await ensure_db(): return err("Database not connected", 503)
    try: qid_int = int(qid)
    except: qid_int = None
    query = {"Id": qid_int} if qid_int else {"_id": __import__("bson").ObjectId(qid)}
    exists = col("quotations").count_documents(query, limit=1) > 0
    if not exists: return err("Quotation not found", 404)
    quot = col("quotations").find_one(query, {"_id": 0, "CustomerId": 1, "CustomerName": 1}) or {}
    cust_id = quot.get("CustomerId")
    cust = None
    if cust_id:
        cust = shared_col("rio_clients").find_one({"Id": cust_id}, {"_id": 0})
    if not cust:
        # Quotations created by typing a customer name (e.g. from the mobile
        # "New Quote" form) never get a CustomerId — fall back to a
        # case-insensitive name match so Update still works for them.
        cust_name = (quot.get("CustomerName") or "").strip()
        if not cust_name: return err("No customer linked to this quotation", 400)
        import re as _re
        cust = shared_col("rio_clients").find_one(
            {"Name": {"$regex": f"^{_re.escape(cust_name)}$", "$options": "i"}},
            {"_id": 0}
        )
        if not cust:
            return err("No matching customer record found for '" + cust_name + "'", 404)
    update = {
        "CustomerName":   cust.get("Name") or cust.get("ClientName") or "",
        "CustomerGST":    cust.get("GSTNo") or cust.get("GSTIN") or "",
        "CustomerMobile": cust.get("Mobile") or cust.get("Phone") or "",
        "CustomerEmail":  cust.get("Email") or "",
        "BillToAddress":  cust.get("BillToAddress") or cust.get("Address") or "",
        "ShipToAddress":  cust.get("ShipToAddress") or cust.get("BillToAddress") or cust.get("Address") or "",
        "PlaceOfSupply":  cust.get("State") or "",
    }
    col("quotations").update_one(query, {"$set": update})
    return ok({"success": True, "updated": update})

# Alias with /billing/ prefix so mobile can use a consistent URL pattern
@app.patch("/api/billing/quotations/{qid}/refresh-customer")
async def billing_refresh_quotation_customer(qid: str):
    return await refresh_quotation_customer(qid)

# Alias without /billing/ prefix for invoice (was missing — needed for mobile Update button)
@app.patch("/api/invoices/{inv_id}/refresh-customer")
async def refresh_invoice_customer_alias(inv_id: int):
    return await refresh_invoice_customer(inv_id)

@app.put("/api/billing/invoices/{inv_id}")
async def billing_put_invoice(inv_id: int, request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    _cur = col("sales_invoices").find_one({"Id": inv_id}, {"_id": 0, "Status": 1})
    if _cur is None: return err("Invoice not found", 404)      # NB: a found invoice with no Status field comes back as {} (falsy) - so test for None, not "not _cur"
    if _cur.get("Status") == "Cancelled": return err("This invoice is cancelled and cannot be edited.", 409)
    b = await request.json()
    raw_date = b.get("InvoiceDate","")
    try: inv_date = datetime.strptime(raw_date[:10], "%Y-%m-%d").strftime("%Y-%m-%d")
    except: inv_date = datetime.now().strftime("%Y-%m-%d")
    col("sales_invoices").update_one({"Id": inv_id}, {"$set": {
        "InvoiceDate": inv_date, "FY": fy_from_date(inv_date),
        "CustomerId": to_int(b.get("CustomerId"),0),
        "CustomerName": b.get("CustomerName",""), "BillingType": b.get("BillingType",""),
        "CustomerGST": b.get("CustomerGST",""),
        "PlaceOfSupply": b.get("PlaceOfSupply",""), "PlaceOfSupplyCode": b.get("PlaceOfSupplyCode",""),
        "SubTotal": to_float(b.get("SubTotal"),0), "CGST": to_float(b.get("CGST"),0),
        "SGST": to_float(b.get("SGST"),0), "IGST": to_float(b.get("IGST"),0),
        "TotalAmount": to_float(b.get("TotalAmount"),0),
        "Counter": b.get("Counter",""), "PaymentTerms": b.get("PaymentTerms",""),
    }})
    col("sales_items").delete_many({"InvoiceId": inv_id})
    sno = 1
    for item in (b.get("Items") or []):
        if not item: continue
        qty = to_float(item.get("Qty"),0); rate = to_float(item.get("Rate"),0)
        tv  = to_float(item.get("TaxableValue"), qty*rate if qty and rate else 0)
        it  = to_float(item.get("Total"), tv)
        if not item.get("ProductName") and not tv: continue
        col("sales_items").insert_one({
            "InvoiceId": inv_id, "SNo": sno,
            "ProductName": item.get("ProductName",""), "HSN": item.get("HSN",""),
            "Qty": qty, "Rate": rate, "TaxableValue": tv,
            "GSTRate": to_float(item.get("GSTRate"),0), "Total": it,
            "SizeNotes": item.get("SizeNotes","")
        })
        sno += 1
    inv_no = col("sales_invoices").find_one({"Id": inv_id}, {"InvoiceNo": 1})
    return ok({"success": True, "id": inv_id, "invoiceNo": inv_no.get("InvoiceNo","") if inv_no else ""})

@app.delete("/api/billing/invoices/{inv_id}")
async def billing_delete_invoice(inv_id: int, request: Request, confirmPrinted: int = Query(0)):
    """Delete the MOST RECENT invoice of its series (a mistake should not use up a number).
    An invoice that was already printed or shared can be deleted only by an admin who confirms it (confirmPrinted=1).
    Every deleted invoice (with its lines) is kept in the 'removed_invoices' table, so it can be recovered.
    Anything that is not the most recent invoice of its series is cancelled instead (see /cancel), which keeps the number."""
    if not await ensure_db(): return err("Database not connected", 503)
    inv = col("sales_invoices").find_one({"Id": inv_id}, {"_id": 0})
    if inv is None: return err("Invoice not found", 404)
    inv_no = inv.get("InvoiceNo", "")
    if inv.get("Status") == "Cancelled":
        return err("A cancelled invoice is kept for the record and cannot be deleted.", 409)
    latest = col("sales_invoices").find_one({"InvoiceNo": {"$regex": _inv_series_regex(inv_no)}}, {"_id": 0, "Id": 1}, sort=[("Id", DESCENDING)])
    if not latest or latest.get("Id") != inv_id:
        return err("Only the most recent invoice in this series can be deleted. Use Cancel for an older one.", 403)
    if inv.get("Issued"):
        if await admin_guard(request):                                     # not an admin
            return err(f"Invoice {inv_no} was already printed or shared, so only an admin can delete it. Ask an admin, or use Cancel (the number is kept).", 403)
        if not confirmPrinted:
            return err(f"Invoice {inv_no} was already printed or shared - please confirm that you really want to delete it (a customer may hold a copy).", 409)
    items = list(col("sales_items").find({"InvoiceId": inv_id}, {"_id": 0}))
    col("removed_invoices").insert_one({"RemovedAt": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "RemovedBy": await _caller_username(request),
                                        "Reason": "deleted (most recent invoice of its series)", "WasPrinted": bool(inv.get("Issued")), "Invoice": inv, "Items": items})
    col("sales_items").delete_many({"InvoiceId": inv_id})
    col("sales_invoices").delete_one({"Id": inv_id})
    still_used = _number_shared(inv)                                       # another live invoice of the SAME year has this number
    _release_sales(_sales_of_invoice(inv, still_used))                     # the sale can be invoiced again (exact link by Id; older links only within the same year)
    return ok({"success": True, "invoiceNo": inv_no, "wasPrinted": bool(inv.get("Issued")), "sharedNumber": still_used})

# ─────────────────────────────────────────────
#  BILLING — QUOTATIONS
# ─────────────────────────────────────────────
@app.get("/api/billing/quotations/peek")
async def billing_quotation_peek(type: str = Query("GST"), fy: str = Query("")):
    if not fy: fy = current_fy()
    return JSONResponse(content={"quotationNo": next_quotation_no(type, fy)})

@app.get("/api/billing/quotations/next")
async def billing_quotation_next(type: str = Query("GST"), fy: str = Query("")):
    if not fy: fy = current_fy()
    return JSONResponse(content={"quotationNo": next_quotation_no(type, fy)})

@app.get("/api/billing/quotations/byno")
async def billing_quotation_byno(qno: str = Query("")):
    if not qno: return err("qno required")
    q = col("quotations").find_one({"QuotationNo": qno}, {"_id": 0})
    if not q: return err("Not found", 404)
    q_id = q.get("Id")
    items = list(col("quotation_items").find({"QuotationId": q_id}, {"_id": 0}).sort("SNo", ASCENDING))
    # Keep QuotationDate/ValidTill as raw YYYY-MM-DD from MongoDB. Previously
    # reformatted to DD-MM-YYYY, which broke the edit form's date input
    # (requires YYYY-MM-DD) and is unreliable for fd()'s new Date(d) parsing
    # on the frontend.
    return JSONResponse(content={**q, "Items": items})

@app.get("/api/billing/quotations")
async def billing_get_quotations(
    page: int = Query(1), pageSize: int = Query(50),
    fr: Optional[str] = Query(None, alias="from"), to: Optional[str] = Query(None),
    type: Optional[str] = Query(None), q: Optional[str] = Query(None),
    scope: Optional[str] = Query(None), user: Optional[str] = Query(None),
    mobile: Optional[str] = Query(None)
):
    pageSize = max(1, min(pageSize, 500))
    query = {}
    if fr or to:
        query["QuotationDate"] = {}
        if fr: query["QuotationDate"]["$gte"] = fr
        if to: query["QuotationDate"]["$lte"] = to
    if type == "GST":    query["BillingType"] = {"$in": ["GST","IGST"]}
    if type == "NONGST": query["BillingType"] = "NON-GST"
    if q:
        # Also search by product name — find quotation IDs that have matching items
        matching_item_quot_ids = [
            r["QuotationId"] for r in col("quotation_items").find(
                {"ProductName": {"$regex": q, "$options": "i"}}, {"QuotationId": 1, "_id": 0}
            )
        ]
        query["$or"] = [
            {"CustomerName":  {"$regex": q, "$options": "i"}},
            {"QuotationNo":   {"$regex": q, "$options": "i"}},
            {"Id":            {"$in": matching_item_quot_ids}},
        ]
    if scope == "own" and user: query["createdBy"] = user
    if mobile == "true": query["mobile_visible"] = True
    total = col("quotations").count_documents(query)
    skip  = (page - 1) * pageSize
    rows  = list(col("quotations").find(query, {"_id": 0})
                .sort([("QuotationDate", DESCENDING), ("Id", DESCENDING)]).skip(skip).limit(pageSize))
    return JSONResponse(content={"data": rows, "total": total, "page": page, "pageSize": pageSize})

@app.get("/api/billing/quotations/{quot_id}")
async def billing_get_quotation(quot_id: int):
    q = col("quotations").find_one({"Id": quot_id}, {"_id": 0})
    if not q: return err("Quotation not found", 404)
    items = list(col("quotation_items").find({"QuotationId": quot_id}, {"_id": 0}).sort("SNo", ASCENDING))
    return JSONResponse(content={**q, "Items": items})

@app.post("/api/billing/quotations")
async def billing_post_quotation(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    q_no = (b.get("QuotationNo") or "").strip()
    if not q_no: return err("QuotationNo required")
    try: q_date = datetime.strptime(b.get("QuotationDate","")[:10], "%Y-%m-%d").strftime("%Y-%m-%d")
    except: q_date = datetime.now().strftime("%Y-%m-%d")
    try: vt = datetime.strptime(b.get("ValidTill","")[:10], "%Y-%m-%d").strftime("%Y-%m-%d")
    except: vt = q_date
    new_id = next_id("quotations")
    doc = {
        "Id": new_id, "QuotationNo": q_no, "QuotationDate": q_date,
        "createdBy": (b.get("createdBy") or "").strip(),
        "CustomerId": to_int(b.get("CustomerId"),0),
        "CustomerName": b.get("CustomerName",""), "BillingType": b.get("BillingType",""),
        "PlaceOfSupply": b.get("PlaceOfSupply",""), "PlaceOfSupplyCode": b.get("PlaceOfSupplyCode",""),
        "SubTotal": to_float(b.get("SubTotal"),0), "CGST": to_float(b.get("CGST"),0),
        "SGST": to_float(b.get("SGST"),0), "IGST": to_float(b.get("IGST"),0),
        "TotalAmount": to_float(b.get("TotalAmount"),0),
        "PaymentTerms": b.get("PaymentTerms",""), "ValidTill": vt
    }
    col("quotations").insert_one(doc)
    sno = 1
    for item in (b.get("Items") or []):
        if not item: continue
        qty = to_float(item.get("Qty"),0); rate = to_float(item.get("Rate"),0)
        tv  = to_float(item.get("TaxableValue"), qty*rate if qty and rate else 0)
        it  = to_float(item.get("Total"), tv)
        if not item.get("ProductName") and not tv: continue
        col("quotation_items").insert_one({
            "QuotationId": new_id, "SNo": sno,
            "ProductName": item.get("ProductName",""), "HSN": item.get("HSN",""),
            "Qty": qty, "Rate": rate, "TaxableValue": tv,
            "GSTRate": to_float(item.get("GSTRate"),0), "Total": it,
            "SizeNotes": item.get("SizeNotes","")
        })
        sno += 1
    return ok({"success": True, "id": new_id, "quotationNo": q_no})


@app.put("/api/billing/quotations/{quot_id}")
async def billing_put_quotation(quot_id: int, request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    q_no = (b.get("QuotationNo") or "").strip()
    if not q_no: return err("QuotationNo required")
    try: q_date = datetime.strptime(b.get("QuotationDate","")[:10], "%Y-%m-%d").strftime("%Y-%m-%d")
    except: q_date = datetime.now().strftime("%Y-%m-%d")
    try: vt = datetime.strptime(b.get("ValidTill","")[:10], "%Y-%m-%d").strftime("%Y-%m-%d")
    except: vt = q_date
    update_doc = {
        "QuotationNo": q_no, "QuotationDate": q_date,
        "CustomerId": to_int(b.get("CustomerId"),0),
        "CustomerName": b.get("CustomerName",""), "BillingType": b.get("BillingType",""),
        "PlaceOfSupply": b.get("PlaceOfSupply",""), "PlaceOfSupplyCode": b.get("PlaceOfSupplyCode",""),
        "SubTotal": to_float(b.get("SubTotal"),0), "CGST": to_float(b.get("CGST"),0),
        "SGST": to_float(b.get("SGST"),0), "IGST": to_float(b.get("IGST"),0),
        "TotalAmount": to_float(b.get("TotalAmount"),0),
        "PaymentTerms": b.get("PaymentTerms",""), "ValidTill": vt
    }
    col("quotations").update_one({"Id": quot_id}, {"$set": update_doc})
    # Replace items
    col("quotation_items").delete_many({"QuotationId": quot_id})
    sno = 1
    for item in (b.get("Items") or []):
        if not item: continue
        qty = to_float(item.get("Qty"),0); rate = to_float(item.get("Rate"),0)
        tv  = to_float(item.get("TaxableValue"), qty*rate if qty and rate else 0)
        it  = to_float(item.get("Total"), tv)
        if not item.get("ProductName") and not tv: continue
        col("quotation_items").insert_one({
            "QuotationId": quot_id, "SNo": sno,
            "ProductName": item.get("ProductName",""), "HSN": item.get("HSN",""),
            "Qty": qty, "Rate": rate, "TaxableValue": tv,
            "GSTRate": to_float(item.get("GSTRate"),0), "Total": it,
            "SizeNotes": item.get("SizeNotes","")
        })
        sno += 1
    return ok({"success": True, "quotationNo": q_no})

@app.delete("/api/billing/quotations/{quot_id}")
async def billing_delete_quotation(quot_id: int):
    if not await ensure_db(): return err("Database not connected", 503)
    # Find this quotation first to determine its series (GST vs Non-GST)
    quot_exists = col("quotations").count_documents({"Id": quot_id}, limit=1) > 0
    if not quot_exists:
        return err("Quotation not found", 404)
    this_quot = col("quotations").find_one({"Id": quot_id}, {"QuotationNo": 1}) or {}
    qno = this_quot.get("QuotationNo", "")
    # Find the latest quotation in the SAME series
    if qno.startswith("QN"):
        latest = col("quotations").find_one({"QuotationNo": {"$regex": r"^QN"}}, sort=[("Id", DESCENDING)])
    else:
        latest = col("quotations").find_one({"QuotationNo": {"$regex": r"^Q\d"}}, sort=[("Id", DESCENDING)])
    if not latest or latest.get("Id") != quot_id:
        return err("Only the most recent quotation in this series can be deleted.", 403)
    col("quotation_items").delete_many({"QuotationId": quot_id})
    col("quotations").delete_one({"Id": quot_id})
    return ok({"success": True})

# ─────────────────────────────────────────────
#  BILLING — REPORTS
# ─────────────────────────────────────────────
@app.get("/api/billing/reports/sales")
async def billing_reports_sales(
    fr: Optional[str] = Query(None, alias="from"), to: Optional[str] = Query(None),
    type: Optional[str] = Query(None)
):
    query = {}
    if fr or to:
        query["InvoiceDate"] = {}
        if fr: query["InvoiceDate"]["$gte"] = fr
        if to: query["InvoiceDate"]["$lte"] = to
    if type == "GST":    query["BillingType"] = {"$in": ["GST","IGST"]}
    if type == "NONGST": query["BillingType"] = "NON-GST"
    query["Status"] = {"$ne": "Cancelled"}
    rows = list(col("sales_invoices").find(query, {"_id":0,"InvoiceNo":1,"InvoiceDate":1,"CustomerName":1,"CustomerGST":1,"PlaceOfSupply":1,"Items":1,"BillingType":1,"CreatedBy":1,"SubTotal":1,"CGST":1,"SGST":1,"IGST":1,"TotalAmount":1})
                .sort([("InvoiceDate", DESCENDING), ("Id", DESCENDING)]))
    
    # Process rows to extract HSN and Quantity from sales_items collection
    processed_rows = []
    for r in rows:
        row_data = {
            "InvoiceNo": r.get("InvoiceNo", ""),
            "InvoiceDate": r.get("InvoiceDate", ""),
            "CustomerName": r.get("CustomerName", ""),
            "CustomerGST": r.get("CustomerGST", ""),
            "PlaceOfSupply": r.get("PlaceOfSupply", ""),
            "HSN": "",
            "Quantity": 0,
            "BillingType": r.get("BillingType", ""),
            "CreatedBy": r.get("CreatedBy", ""),
            "SubTotal": r.get("SubTotal", 0),
            "CGST": r.get("CGST", 0),
            "SGST": r.get("SGST", 0),
            "IGST": r.get("IGST", 0),
            "TotalAmount": r.get("TotalAmount", 0)
        }
        
        # Get first item from sales_items collection
        item = col("sales_items").find_one({"InvoiceId": r.get("Id")}, {"_id": 0, "HSN": 1, "Qty": 1})
        if item:
            row_data["HSN"] = item.get("HSN", "")
            row_data["Quantity"] = to_float(item.get("Qty", 0), 0)
        
        processed_rows.append(row_data)
    
    totals = {"SubTotal":0,"CGST":0,"SGST":0,"IGST":0,"TotalAmount":0}
    for r in processed_rows:
        for k in totals:
            totals[k] += to_float(r.get(k),0)
    return JSONResponse(content={"data": processed_rows, "count": len(processed_rows), "totals": totals})

# ─────────────────────────────────────────────
#  BILLING — BACKUP (stub — data is in MongoDB)
# ─────────────────────────────────────────────
@app.post("/api/billing/backup")
async def billing_backup():
    return ok({"success": True, "message": "Data is stored in MongoDB Atlas — no local backup needed. Use MongoDB Atlas backup features.", "recentBackups": []})

@app.get("/api/billing/backups")
async def billing_backups():
    return JSONResponse(content=[])

@app.post("/api/billing/reset-sequences")
async def billing_reset_sequences():
    return ok({"message": "Sequences are auto-calculated from existing records in MongoDB.", "invoiceCount": 0, "quotationCount": 0})

# ─────────────────────────────────────────────
#  REPORTS (non-billing)
# ─────────────────────────────────────────────
@app.get("/api/reports/sales")
async def reports_sales(
    fr: Optional[str] = Query(None, alias="from"), to: Optional[str] = Query(None),
    type: Optional[str] = Query(None)
):
    return await billing_reports_sales(fr=fr, to=to, type=type)

# ─────────────────────────────────────────────
#  CLIENT-SIDE LOGGING  →  uses main logger
# ─────────────────────────────────────────────
# Reuse the top-level logger (already configured above with file + stdout)
_log = logging.getLogger("rio_erp_api")
# LOG_FILE exposed for /api/log/tail endpoint
LOG_FILE = _LOG_FILE  # None on Render, Path on Windows

class LogEntry(BaseModel):
    level:   str = "INFO"
    user:    str = "unknown"
    action:  str = ""
    detail:  str = ""
    page:    str = ""
    ts:      str = ""

@app.get("/api/log/where")
async def log_where():
    """Shows where the log file is (or tells you it's on Render stdout)."""
    import platform as _p
    return {
        "platform": _p.system(),
        "log_file": str(LOG_FILE) if LOG_FILE else None,
        "log_exists": LOG_FILE.exists() if LOG_FILE else False,
        "note": (
            f"Log file at: {LOG_FILE}" if LOG_FILE and LOG_FILE.exists()
            else "Running on Render/Linux — logs go to Render dashboard Logs tab, not a file."
        )
    }

@app.get("/api/log/tail")
async def log_tail(n: int = 100):
    """Return last n lines of the log file (Windows only; Render uses stdout)."""
    if not LOG_FILE or not LOG_FILE.exists():
        return {"lines": [], "note": "Log file not available on this platform. On Render, check the Logs tab in the dashboard."}
    try:
        lines = LOG_FILE.read_text(encoding="utf-8").splitlines()
        return {"lines": lines[-n:], "total": len(lines), "file": str(LOG_FILE)}
    except Exception as e:
        return {"lines": [], "error": str(e)}


# ─────────────────────────────────────────────
#  ATTENDANCE — matches PS1 v2.1 structure
#  Collection: att_records, att_staff
# ─────────────────────────────────────────────
@app.get("/api/attendance/ping")
async def att_ping():
    if not await ensure_db(): return JSONResponse(content={"ok": False}, status_code=503)
    return {"ok": True}

@app.get("/api/attendance/staff")
async def get_att_staff():
    if not await ensure_db(): return JSONResponse(content=[], status_code=503)
    try:
        rows = list(col("att_staff").find({}, {"_id": 0}).sort("name", ASCENDING))
        return JSONResponse(content=rows)
    except Exception as e:
        return JSONResponse(content=[], status_code=500)

@app.post("/api/attendance/delete-employee")
async def delete_employee_attendance(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    name = b.get("name", "").strip()
    if not name: return err("Employee name required", 400)
    result = col("attendance").delete_many({"name": name})
    return ok({"success": True, "deleted": result.deleted_count})

@app.post("/api/attendance/staff")
async def post_att_staff(request: Request):
    staff = await request.json()
    if not isinstance(staff, list): return err("Expected array")
    if not await ensure_db(): return err("DB offline")
    try:
        col("att_staff").delete_many({})
        if staff:
            col("att_staff").insert_many(
                [{k:v for k,v in s.items()} for s in staff], ordered=False
            )
    except Exception as e:
        return err(str(e))
    return ok({"success": True})

# ── SALARY (part-time, calculated from attendance) ─────────────────────────
@app.post("/api/salary")
async def save_salary_record(request: Request):
    if not await ensure_db(): return err("DB offline")
    rec = await request.json()
    try:
        rec.pop("_id", None)
        rec["savedAt"] = datetime.utcnow().isoformat()
        rec["id"] = next_id("salary_records")
        col("salary_records").insert_one(rec)
        return ok({"success": True})
    except Exception as e:
        return err(str(e))

@app.get("/api/salary")
async def get_salary_records(
    date_from: Optional[str] = Query(None),
    date_to:   Optional[str] = Query(None),
):
    if not await ensure_db(): return JSONResponse(content=[], status_code=503)
    query = {}
    if date_from or date_to:
        rng = {}
        if date_from: rng["$gte"] = date_from
        if date_to:   rng["$lte"] = date_to
        query["fromDate"] = rng
    rows = list(col("salary_records").find(query, {"_id": 0}).sort("savedAt", -1))
    return JSONResponse(content=rows)

# get_attendance: replaced by full version from attendance_api below
@app.post("/api/attendance/upsert")
async def att_upsert(request: Request):
    rec = await request.json()
    if not await ensure_db(): return err("DB offline")
    try:
        rec_id = rec.get("id")
        name   = rec.get("name","").strip()
        date   = rec.get("date","").strip()
        if not name or not date: return err("name and date required")
        # Remove MongoDB _id if present
        rec.pop("_id", None)
        col("att_records").replace_one({"name": name, "date": date}, rec, upsert=True)
        return ok({"success": True})
    except Exception as e:
        return err(str(e))

@app.get("/api/attendance/all")
async def att_get_all():
    if not await ensure_db(): return JSONResponse(content=[], status_code=503)
    try:
        rows = list(col("att_records").find({}, {"_id": 0}).sort([("date", ASCENDING), ("name", ASCENDING)]))
        return JSONResponse(content=rows)
    except Exception as e:
        return JSONResponse(content=[], status_code=500)

@app.get("/api/attendance/search")
async def att_search(
    fr:   Optional[str] = Query(None, alias="from"),
    to:   Optional[str] = Query(None),
    name: Optional[str] = Query(None),
    jobType: Optional[str] = Query(None)
):
    if not await ensure_db(): return JSONResponse(content=[], status_code=503)
    try:
        query = {}
        if fr or to:
            query["date"] = {}
            if fr: query["date"]["$gte"] = fr
            if to: query["date"]["$lte"] = to
        if name:    query["name"]    = name
        if jobType: query["jobType"] = jobType
        rows = list(col("att_records").find(query, {"_id": 0}).sort([("date", ASCENDING), ("name", ASCENDING)]))
        return JSONResponse(content=rows)
    except Exception as e:
        return JSONResponse(content=[], status_code=500)

@app.delete("/api/attendance/delete")
async def att_delete(
    fr:   Optional[str] = Query(None, alias="from"),
    to:   Optional[str] = Query(None),
    name: Optional[str] = Query(None)
):
    if not await ensure_db(): return err("DB offline")
    try:
        query = {}
        if fr or to:
            query["date"] = {}
            if fr: query["date"]["$gte"] = fr
            if to: query["date"]["$lte"] = to
        if name: query["name"] = name
        result = col("att_records").delete_many(query)
        return ok({"deleted": result.deleted_count})
    except Exception as e:
        return err(str(e))

# upsert_attendance: replaced by attendance_api version below
@app.post("/api/auth/login")
async def login(request: Request):
    if not await ensure_db():
        return JSONResponse(content={"ok": False, "error": "Database not connected. Please try again in a moment."}, status_code=503)
    b = await request.json()
    username = (b.get("username") or "").strip().lower()
    password = (b.get("password") or "").strip()
    if not username or not password:
        return err("Username and password required", 400)
    user = _db["rio_users"].find_one({"username": username}, {"_id": 0})
    if not user:
        return err("Invalid username or password", 401)
    if not verify_password(password, user["password"]):
        return err("Invalid username or password", 401)
    # Accept any role — built-in or custom roles created in User Management
    role = user.get("role", "guest") or "guest"
    scope = user.get("scope", "all")
    # Generate a session token and store it so protected endpoints can verify
    token = secrets.token_hex(32)
    _db["rio_users"].update_one(
        {"username": username},
        {"$set": {"session_token": token}}
    )
    mobile_access = bool(user.get("mobile_access", False))
    # If login is from mobile app, block users without mobile_access
    source = (b.get("source") or "web").strip().lower()
    if source == "mobile" and not mobile_access and role != "admin":
        return err("Mobile access not enabled for this account. Please contact your administrator.", 403)

    # Record this login in the audit log - IP, OS/browser (there's no way
    # to get a real "machine name"/hostname from a browser, this is the
    # closest actual equivalent), and an approximate city from IP
    # geolocation. Wrapped in try/except so a logging failure never blocks
    # an otherwise-successful login.
    try:
        client_ip = get_client_ip(request)
        ua_info = parse_user_agent(request.headers.get("user-agent", ""))
        geo = await get_ip_geolocation(client_ip)
        col("rio_login_logs").insert_one({
            "Id": next_id("rio_login_logs"),
            "Username": username,
            "Role": role,
            "LoginTime": datetime.utcnow().isoformat(),
            "IP": client_ip,
            "OS": ua_info["os"],
            "Browser": ua_info["browser"],
            "City": geo["city"],
            "Region": geo["region"],
            "Country": geo["country"],
            "Source": source,
        })
    except Exception as e:
        logger.warning(f"Login logging failed (non-fatal): {e}")

    return JSONResponse(content={
        "ok": True,
        "username": user["username"],
        "name": user.get("name", username),
        "role": role,
        "scope": scope,
        "token": token,
        "mobile_access": mobile_access
    })

@app.get("/api/billing/users")
@app.get("/api/auth/users")
async def get_users():
    if not await ensure_db():
        return JSONResponse(content={"error": "Database not connected"}, status_code=503)
    # Always read from master DB regardless of company context
    users = list(_db["rio_users"].find({}, {"_id": 0, "password": 0, "session_token": 0}))
    return JSONResponse(content=users)

@app.post("/api/auth/users")
async def create_user(request: Request):
    _g = await admin_guard(request)
    if _g: return _g
    b = await request.json()
    username = (b.get("username") or "").strip().lower()
    password = (b.get("password") or "").strip()
    role     = (b.get("role") or "expense").strip()
    name     = (b.get("name") or username).strip()
    if not username or not password:
        return err("Username and password required")
    # Accept any role — including custom roles created in User Management
    if not role:
        role = "guest"
    if col("rio_users").find_one({"username": username}):
        return err("Username already exists")
    scope = (b.get("scope") or "all").strip()
    if scope not in {"all", "own"}: scope = "all"
    mobile_access_flag = bool(b.get("mobile_access", False))
    col("rio_users").insert_one({
        "username": username,
        "password": hash_password(password),
        "role": role,
        "name": name,
        "scope": scope,
        "mobile_access": mobile_access_flag
    })
    return ok({"ok": True})

@app.put("/api/auth/users/{username}")
async def update_user(username: str, request: Request):
    b = await request.json()
    if _enforce_admin():
        if not await ensure_db(): return err("Database not connected", 503)
        tok = _bearer_token(request)
        me = _db["rio_users"].find_one({"session_token": tok}, {"_id": 0}) if tok else None
        if not me:
            return err("Login required - please log out and log in again.", 401)
        if (me.get("role") or "").lower() != "admin":
            if (me.get("username") or "") != username.strip().lower():
                return err("Admin access is required for this action.", 403)
            # ordinary users may only change their own password (used by the first-login password change)
            b = {"password": b.get("password")} if b.get("password") else {}
    update = {}
    if b.get("password"): update["password"] = hash_password(b["password"])
    if b.get("role"):     update["role"]     = b["role"]
    if b.get("name"):     update["name"]     = b["name"]
    if b.get("scope") in {"all","own"}: update["scope"] = b["scope"]
    if "mobile_access" in b: update["mobile_access"] = bool(b["mobile_access"])
    if not update: return ok()
    col("rio_users").update_one({"username": username}, {"$set": update})
    return ok()

@app.delete("/api/auth/users/{username}")
async def delete_user(username: str, request: Request):
    _g = await admin_guard(request)
    if _g: return _g
    if username == "admin":
        return err("Cannot delete admin user")
    col("rio_users").delete_one({"username": username})
    return ok()


# ══════════════════════════════════════════════════════════════
# MOBILE — quotation toggle, split-up CRUD
# ══════════════════════════════════════════════════════════════

@app.patch("/api/quotations/{qid}/mobile-toggle")
async def mobile_toggle_quotation(qid: int):
    """Toggle mobile_visible flag on a quotation."""
    if not await ensure_db(): return err("Database not connected", 503)
    q = col("quotations").find_one({"Id": qid}, {"_id": 0, "mobile_visible": 1})
    if q is None: return err("Quotation not found", 404)      # a quotation without the flag comes back as {} - still found
    new_val = not bool(q.get("mobile_visible", False))
    col("quotations").update_one({"Id": qid}, {"$set": {"mobile_visible": new_val}})
    return JSONResponse(content={"ok": True, "mobile_visible": new_val})

@app.get("/api/mobile/splitups")
async def get_mobile_splitups(
    user: Optional[str] = Query(None),
    role: Optional[str] = Query(None),
    limit: int = Query(100)
):
    """List split-ups. Admin sees all; others see only their own."""
    if not await ensure_db(): return err("Database not connected", 503)
    query = {}
    if role != "admin" and user:
        query["createdBy"] = user
    rows = list(col("mobile_splitups").find(query, {"_id": 0})
                .sort("createdAt", DESCENDING).limit(limit))
    return JSONResponse(content={"data": rows, "total": len(rows)})

@app.post("/api/mobile/splitups")
async def post_mobile_splitup(request: Request):
    """Save a new split-up calculation."""
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    from datetime import datetime, timezone, timedelta
    now = datetime.now(timezone.utc)
    doc = {
        "size":        b.get("size", ""),
        "billingType": b.get("billingType", "GST"),
        "qty":         int(b.get("qty", 0)),
        "gstQty":      int(b.get("gstQty", 0)),
        "nonGstQty":   int(b.get("nonGstQty", 0)),
        "rate":        float(b.get("rate", 0)),
        "gstRate":     float(b.get("gstRate", 18)),
        "gstAmount":   float(b.get("gstAmount", 0)),
        "gstValue":    float(b.get("gstValue", 0)),
        "gstTotal":    float(b.get("gstTotal", 0)),
        "nonGstAmount":float(b.get("nonGstAmount", 0)),
        "nonGstTotal": float(b.get("nonGstTotal", 0)),
        "grandTotal":  float(b.get("grandTotal", 0)),
        "createdBy":   b.get("createdBy", ""),
        "customerName": b.get("customerName", ""),
    }
    # Belt-and-braces dedup: an identical calculation from the same user
    # within the last 15s is a double-fire (double tap / duplicate event),
    # not a new entry — return the already-saved record instead of inserting.
    cutoff = (now - timedelta(seconds=15)).isoformat()
    dup = col("mobile_splitups").find_one(
        {**doc, "createdAt": {"$gte": cutoff}}, {"Id": 1, "_id": 0}
    )
    if dup:
        return JSONResponse(content={"ok": True, "Id": dup.get("Id"), "deduped": True})
    last = col("mobile_splitups").find_one({}, {"Id": 1, "_id": 0}, sort=[("Id", DESCENDING)])
    new_id = (last["Id"] if last and "Id" in last else 0) + 1
    doc["Id"] = new_id
    doc["createdAt"] = now.isoformat()
    col("mobile_splitups").insert_one(doc)
    return JSONResponse(content={"ok": True, "Id": new_id})

@app.delete("/api/mobile/splitups/{split_id}")
async def delete_mobile_splitup(split_id: int):
    """Delete a split-up record."""
    if not await ensure_db(): return err("Database not connected", 503)
    r = col("mobile_splitups").delete_one({"Id": split_id})
    if r.deleted_count == 0: return err("Split-up not found", 404)
    return JSONResponse(content={"ok": True})


# ══════════════════════════════════════════════════════════════
# CUSTOM ROLES — stored in MongoDB so all machines share them
# ══════════════════════════════════════════════════════════════

@app.get("/api/sizes")
async def get_sizes(company: str = "rio"):
    """Return the sizes list for a company. Stored in MongoDB sizes_list collection
    (one document per company); falls back to a legacy shared doc, then to defaults."""
    if not await ensure_db(): return err("Database not connected", 503)
    company = (company or "rio").lower()
    stored = col("sizes_list").find_one({"company": company}, {"_id": 0})
    if stored and stored.get("sizes"):
        return JSONResponse(content={"sizes": stored["sizes"]})
    # Legacy shared doc (pre-company-scoping) — use once, then let POST re-save per company
    legacy = col("sizes_list").find_one({"type": "main"}, {"_id": 0})
    if legacy and legacy.get("sizes"):
        return JSONResponse(content={"sizes": legacy["sizes"]})
    # Return hardcoded defaults
    defaults = [
        "16x6 Inches","18x6 Inches","12x18 Inches","12x12 Inches",
        "16x16 Inches","24x18 Inches","24x12 Inches","24x24 Inches",
        "36x12 Inches","36x24 Inches","48x4 Inches","Others"
    ]
    return JSONResponse(content={"sizes": defaults})

@app.post("/api/sizes")
async def save_sizes(request: Request):
    """Persist the full sizes list for a company to MongoDB, so every device
    (desktop and mobile) reads the same list via GET /api/sizes?company=..."""
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    company = (b.get("company") or "rio").lower()
    sizes = b.get("sizes")
    if not isinstance(sizes, list):
        return err("sizes must be a list")
    col("sizes_list").update_one(
        {"company": company},
        {"$set": {"company": company, "sizes": sizes, "UpdatedAt": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}},
        upsert=True
    )
    return JSONResponse(content={"success": True, "count": len(sizes)})

@app.post("/api/sizes/rename")
async def rename_size(request: Request):
    """Cascade a size rename across all sales records, invoice items, and quotation items."""
    b = await request.json()
    old_name = (b.get("oldName") or "").strip()
    new_name = (b.get("newName") or "").strip()
    if not old_name or not new_name or old_name == new_name:
        return err("oldName and newName required and must differ")
    results = {}
    # Sales records: Size1, Size2 and Size3 fields
    r1 = col("sales_records").update_many({"Size1": old_name}, {"$set": {"Size1": new_name}})
    r2 = col("sales_records").update_many({"Size2": old_name}, {"$set": {"Size2": new_name}})
    r2b = col("sales_records").update_many({"Size3": old_name}, {"$set": {"Size3": new_name}})
    results["sales"] = r1.modified_count + r2.modified_count + r2b.modified_count
    # Invoice line items: SizeNotes field
    r3 = col("sales_items").update_many({"SizeNotes": old_name}, {"$set": {"SizeNotes": new_name}})
    results["invoice_items"] = r3.modified_count
    # Quotation line items: SizeNotes field
    r4 = col("quotation_items").update_many({"SizeNotes": old_name}, {"$set": {"SizeNotes": new_name}})
    results["quotation_items"] = r4.modified_count
    logger.info(f"Size rename '{old_name}' → '{new_name}': {results}")
    return ok({"renamed": results})

@app.post("/api/billing/invoices/{inv_id}/sync-from-sales")
async def sync_invoice_from_sales(inv_id: int):
    """Fully sync an invoice from its linked sales record — rebuilds all items and recalculates totals."""
    if not await ensure_db(): return err("Database not connected", 503)
    inv = col("sales_invoices").find_one({"Id": inv_id}, {"_id": 0})
    if not inv: return err("Invoice not found", 404)
    if inv.get("Status") == "Cancelled": return err("This invoice is cancelled and cannot be updated.", 409)
    inv_no = inv.get("InvoiceNo", "")
    if not inv_no: return err("Invoice has no InvoiceNo", 400)

    # Find the linked sales record
    sale = col("sales_records").find_one({"InvoiceId": inv_id}, {"_id": 0}) or col("sales_records").find_one({"InvoiceNo": inv_no}, {"_id": 0})
    if not sale: return err(f"No sales record linked to invoice {inv_no}", 404)

    # Determine billing type
    is_gst = sale.get("BillingType", "") == "With Bill"
    billing_type_str = "GST"  # default — overridden below with IGST if needed

    # Look up product for HSN and GSTRate
    prod_name = sale.get("ProductSize") or sale.get("Category") or ""
    hsn = ""; gst_rate = 18.0
    product = col("rio_products").find_one(
        {"$or": [{"Name": prod_name}, {"name": prod_name}]}, {"_id": 0}
    )
    if product:
        hsn      = product.get("HSN") or product.get("hsn") or ""
        gst_rate = to_float(product.get("GSTRate") or product.get("gstrate"), 18.0)

    # Build line items — same logic as generateInvoiceFromSales
    items = []
    sno = 1
    q1 = to_float(sale.get("Qty1"), 0); r1 = to_float(sale.get("Rate1"), 0)
    if q1 > 0 and r1 > 0:
        tax1 = round(q1 * r1, 2)
        items.append({"SNo": sno, "ProductName": prod_name, "HSN": hsn,
                      "Qty": q1, "Rate": r1, "TaxableValue": tax1,
                      "GSTRate": gst_rate, "Total": tax1, "SizeNotes": sale.get("Size1", "")})
        sno += 1
    q2 = to_float(sale.get("Qty2"), 0); r2 = to_float(sale.get("Rate2"), 0)
    if q2 > 0 and r2 > 0:
        tax2 = round(q2 * r2, 2)
        items.append({"SNo": sno, "ProductName": prod_name, "HSN": hsn,
                      "Qty": q2, "Rate": r2, "TaxableValue": tax2,
                      "GSTRate": gst_rate, "Total": tax2, "SizeNotes": sale.get("Size2", "")})
        sno += 1
    q3 = to_float(sale.get("Qty3"), 0); r3 = to_float(sale.get("Rate3"), 0)
    if q3 > 0 and r3 > 0:
        tax3 = round(q3 * r3, 2)
        items.append({"SNo": sno, "ProductName": prod_name, "HSN": hsn,
                      "Qty": q3, "Rate": r3, "TaxableValue": tax3,
                      "GSTRate": gst_rate, "Total": tax3, "SizeNotes": sale.get("Size3", "")})
        sno += 1

    # Packing & Forwarding line
    pf_amt   = to_float(sale.get("PFAmt"), 0)
    pf_gst   = to_float(sale.get("PFGst"), 0)
    pf_total = to_float(sale.get("PFTotal"), 0)
    if pf_amt > 0:
        pf_taxable = pf_amt
        items.append({"SNo": sno, "ProductName": "Packing and Forwarding", "HSN": "",
                      "Qty": 1, "Rate": pf_amt, "TaxableValue": pf_taxable,
                      "GSTRate": pf_gst, "Total": pf_total if pf_total > 0 else pf_taxable,
                      "SizeNotes": ""})
        sno += 1

    if not items:
        return err("Sales record has no line items (Qty/Rate missing)")

    # Look up customer state for IGST vs CGST/SGST
    cust_state = "Tamil Nadu"; cust_state_code = "33"; cust_id = inv.get("CustomerId", 0)
    cust_doc = shared_col("rio_clients").find_one({"ClientName": sale.get("Customer", "")}, {"_id": 0})
    if cust_doc:
        cust_state      = cust_doc.get("State")     or "Tamil Nadu"
        cust_state_code = cust_doc.get("StateCode") or "33"
        cust_id         = cust_doc.get("Id", cust_id)
    is_same_state = not cust_state or "tamil" in cust_state.lower()

    # Calculate totals per item GSTRate
    sub_total = round(sum(it["TaxableValue"] for it in items), 2)
    cgst = sgst = igst = 0.0
    if is_gst:
        for it in items:
            tax_amt = round(it["TaxableValue"] * it["GSTRate"] / 100, 2)
            if is_same_state:
                cgst += round(tax_amt / 2, 2); sgst += round(tax_amt / 2, 2)
            else:
                igst += tax_amt
        cgst = round(cgst, 2); sgst = round(sgst, 2); igst = round(igst, 2)
        billing_type_str = "GST" if is_same_state else "IGST"
    else:
        billing_type_str = "NON-GST"

    grand = round(sub_total + cgst + sgst + igst)

    # Rebuild sales_items
    col("sales_items").delete_many({"InvoiceId": inv_id})
    for it in items:
        col("sales_items").insert_one({
            "InvoiceId": inv_id,
            "SNo": it["SNo"], "ProductName": it["ProductName"], "HSN": it["HSN"],
            "Qty": it["Qty"], "Rate": it["Rate"], "TaxableValue": it["TaxableValue"],
            "GSTRate": it["GSTRate"], "Total": it["Total"], "SizeNotes": it["SizeNotes"]
        })

    # Update invoice header
    update = {
        "CustomerName":      sale.get("Customer", inv.get("CustomerName", "")),
        "CustomerId":        cust_id,
        "CustomerGST":       cust_doc.get("GSTNo", "") if cust_doc else inv.get("CustomerGST", ""),
        "BillingType":       billing_type_str,
        "PlaceOfSupply":     cust_state,
        "PlaceOfSupplyCode": cust_state_code,
        "SubTotal":          sub_total,
        "CGST":              cgst, "SGST": sgst, "IGST": igst,
        "TotalAmount":       grand,
        "PFDesc":            sale.get("PFDesc", ""),
        "PFAmt":             pf_amt, "PFGst": pf_gst, "PFTotal": pf_total,
        "PaymentTerms":      "NEFT" if is_gst else "Cash",
    }
    col("sales_invoices").update_one({"Id": inv_id}, {"$set": update})
    logger.info(f"Full sync: Invoice {inv_no} rebuilt from sales SNo={sale.get('SNo')} — {len(items)} items, Total={grand}")
    return ok({"synced": True, "invoiceNo": inv_no, "items": len(items), "total": grand,
               "billingType": billing_type_str, "CGST": cgst, "SGST": sgst, "IGST": igst})

@app.get("/api/roles")
async def get_roles():
    if not await ensure_db():
        return JSONResponse(content=[], status_code=503)
    roles = list(col("rio_custom_roles").find({}, {"_id": 0}))
    return JSONResponse(content=roles)

@app.post("/api/roles")
async def save_role(request: Request):
    _g = await admin_guard(request)
    if _g: return _g
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    role_id = (b.get("id") or "").strip()
    if not role_id: return err("role id required")
    col("rio_custom_roles").update_one(
        {"id": role_id},
        {"$set": b},
        upsert=True
    )
    return ok({"ok": True})

@app.delete("/api/roles/{role_id}")
async def delete_role(role_id: str, request: Request):
    _g = await admin_guard(request)
    if _g: return _g
    if not await ensure_db(): return err("Database not connected", 503)
    col("rio_custom_roles").delete_one({"id": role_id})
    return ok()

# ══════════════════════════════════════════════════════════════
# ATTENDANCE TRACKER — routes on /api/attendance/*
# ══════════════════════════════════════════════════════════════

SHIFT_START = 9  * 60   # 09:00 in minutes
SHIFT_END   = 20 * 60   # 20:00 in minutes
MAX_OUT     = 26 * 60   # safety cap

# ── Calculation helpers ───────────────────────────────────────────────────────
DAY_NAMES = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"]

def to_mins(t: str) -> int:
    if not t or ":" not in t:
        return 0
    parts = t.split(":")
    return int(parts[0]) * 60 + int(parts[1])

def get_day_name(ds: str) -> str:
    """Return weekday name for a YYYY-MM-DD date string."""
    try:
        parts = ds.split("-")
        if len(parts[0]) == 4:
            dt = date(int(parts[0]), int(parts[1]), int(parts[2]))
        else:
            dt = date(int(parts[2]), int(parts[1]), int(parts[0]))
        return DAY_NAMES[(dt.weekday() + 1) % 7]
    except Exception:
        return "?"

def norm_date(d: str) -> str:
    """Normalize to YYYY-MM-DD."""
    d = d.strip().replace("/", "-").replace("\\", "-")
    parts = d.split("-")
    if len(parts) != 3:
        return d
    if len(parts[0]) == 4:
        return f"{parts[0]}-{parts[1].zfill(2)}-{parts[2].zfill(2)}"
    return f"{parts[2]}-{parts[1].zfill(2)}-{parts[0].zfill(2)}"

LEGACY_SHIFT = {"start": SHIFT_START, "end": SHIFT_END, "grace": 0}

def week_monday(ds: str) -> str:
    """Monday (YYYY-MM-DD) of the Mon-Sun week containing the given date."""
    d = norm_date(ds)
    y, m, dd = [int(x) for x in d.split("-")]
    dt = date(y, m, dd)
    return (dt - timedelta(days=dt.weekday())).isoformat()

def norm_hhmm(t):
    """'9:5' / '09:05' -> '09:05'; anything invalid -> None."""
    mt = re.match(r"^(\d{1,2}):(\d{2})$", (t or "").strip())
    if not mt: return None
    h, mi = int(mt.group(1)), int(mt.group(2))
    if h > 23 or mi > 59: return None
    return f"{h:02d}:{mi:02d}"

def resolve_shift(staff_doc, ds: str) -> dict:
    """The shift that applied to this employee on this date: the latest history
    entry whose effective-from week start is on or before the date. Employees with
    no assignment (or no entry yet for that date) keep the legacy 09:00-20:00,
    no-grace behaviour, so nothing changes until a shift is actually assigned."""
    if not staff_doc: return dict(LEGACY_SHIFT)
    d = norm_date(ds)
    best = None
    for h in (staff_doc.get("shifts") or []):
        f = h.get("from") or ""
        if f <= d and (best is None or f >= (best.get("from") or "")):
            best = h
    if not best: return dict(LEGACY_SHIFT)
    try:
        return {"start": to_mins(best["start"]), "end": to_mins(best["end"]), "grace": int(best.get("grace") or 0)}
    except Exception:
        return dict(LEGACY_SHIFT)

def build_shift_history(existing, eff_from, start, end, grace) -> list:
    """Add/replace the entry for one effective week; earlier entries are untouched."""
    hist = [h for h in (existing or []) if h.get("from") != eff_from]
    hist.append({"from": eff_from, "start": start, "end": end, "grace": int(grace)})
    hist.sort(key=lambda h: h.get("from", ""))
    return hist

def calc(in_t: str, out_t: str, ds: str, rec_type: str, job_type: str = "fulltime", perm_mins: int = 0, shift: dict = None) -> dict:
    """Replicate PowerShell Calc() function, now relative to the employee's assigned shift.
    Late = minutes after (shift start + grace) [only the time PAST the grace counts]
           + minutes left before shift end. Extra = time before shift start + time after shift end."""
    sh = shift or LEGACY_SHIFT
    s_start, s_end, grace = sh["start"], sh["end"], sh.get("grace", 0)
    if rec_type == "holiday":
        return {"totalWorked": 0, "extraHrs": 0, "lateHrs": 0, "status": "holiday"}
    if rec_type == "sunday-off":
        return {"totalWorked": 0, "extraHrs": 0, "lateHrs": 0, "status": "sunday"}
    if job_type == "parttime" and (not in_t or not out_t):
        return {"totalWorked": 0, "extraHrs": 0, "lateHrs": 0, "status": "absent"}
    if rec_type == "absent" or (not in_t and not out_t):
        return {"totalWorked": 0, "extraHrs": 0, "lateHrs": 0, "status": "absent"}
    if not in_t or not out_t:
        return {"totalWorked": 0, "extraHrs": 0, "lateHrs": 0, "status": "absent"}

    in_m  = to_mins(in_t)
    out_m = to_mins(out_t)
    if out_m <= in_m:
        out_m += 1440
    cap = min(out_m, MAX_OUT)
    tw  = cap - in_m

    if job_type == "parttime":
        st = "sunday" if get_day_name(ds) == "Sunday" else "ok"
        return {"totalWorked": max(0, tw - perm_mins), "extraHrs": 0, "lateHrs": 0, "status": st, "permMins": perm_mins}

    if get_day_name(ds) == "Sunday":
        tw_net = max(0, tw - perm_mins)
        return {"totalWorked": tw_net, "extraHrs": tw_net, "lateHrs": 0, "status": "sunday", "permMins": perm_mins}

    eh = max(0, s_start - in_m) + max(0, cap - s_end)
    la = max(0, in_m - (s_start + grace))
    lv = max(0, s_end - out_m) if out_m < s_end else 0
    lh = la + lv
    if in_m < s_start:
        st = "early"
    elif in_m > s_start + grace:
        st = "late"
    else:
        st = "ok"
    tw_net = max(0, tw - perm_mins)
    return {"totalWorked": tw_net, "extraHrs": eh, "lateHrs": lh, "status": st, "permMins": perm_mins}

def rec_to_doc(r: dict) -> dict:
    """Strip MongoDB _id before returning to client."""
    r.pop("_id", None)
    return r

# ── Ping ──────────────────────────────────────────────────────────────────────
# /api/attendance/ping is already defined above — skipping duplicate

# ── Employees list ────────────────────────────────────────────────────────────
@app.get("/api/attendance/employees")
async def get_employees():
    if not await ensure_db():
        return JSONResponse(content=[], status_code=503)
    names = col("attendance").distinct("name")
    return JSONResponse(content=sorted(names))

# ── Get records ───────────────────────────────────────────────────────────────
@app.get("/api/attendance")
async def get_attendance(
    name:     Optional[str] = Query(None),
    job_type: Optional[str] = Query(None),
    date_from:Optional[str] = Query(None),
    date_to:  Optional[str] = Query(None),
):
    if not await ensure_db():
        return JSONResponse(content=[], status_code=503)

    query = {}
    if name:      query["name"] = name
    if job_type:  query["jobType"] = job_type

    rows = list(col("attendance").find(query, {"_id": 0}).sort([("date", ASCENDING), ("name", ASCENDING)]))

    # Date range filter in Python (dates stored as YYYY-MM-DD strings)
    if date_from or date_to:
        filtered = []
        for r in rows:
            rd = r.get("date", "")
            try:
                p = rd.split("-")
                if len(p[0]) == 4:
                    rdate = date(int(p[0]), int(p[1]), int(p[2]))
                else:
                    rdate = date(int(p[2]), int(p[1]), int(p[0]))
                if date_from:
                    df = date_from.split("-")
                    if rdate < date(int(df[0]), int(df[1]), int(df[2])):
                        continue
                if date_to:
                    dt = date_to.split("-")
                    if rdate > date(int(dt[0]), int(dt[1]), int(dt[2])):
                        continue
                filtered.append(r)
            except Exception:
                filtered.append(r)
        rows = filtered

    return JSONResponse(content=rows)

# ── Upsert (add or update) ────────────────────────────────────────────────────
@app.post("/api/attendance")
async def upsert_attendance(request: Request):
    if not await ensure_db():
        return err("Database not connected", 503)
    b = await request.json()

    name     = (b.get("name") or "").strip()
    date_str = norm_date((b.get("date") or "").strip())
    rec_type = (b.get("type") or "work").strip().lower()
    job_type = (b.get("jobType") or "fulltime").strip().lower()
    in_t      = (b.get("inTime") or "").strip()
    out_t     = (b.get("outTime") or "").strip()
    perm_mins = int(b.get("permMins") or 0)

    if not name:      return err("name is required")
    if not date_str:  return err("date is required")

    # Recalculate
    shift = resolve_shift(col("att_staff").find_one({"name": name}, {"_id": 0}), date_str)
    c = calc(in_t, out_t, date_str, rec_type, job_type, perm_mins, shift)

    doc = {
        "name":        name,
        "date":        date_str,
        "type":        rec_type,
        "jobType":     job_type,
        "inTime":      in_t  if rec_type == "work" else "",
        "outTime":     out_t if rec_type == "work" else "",
        "permMins":    perm_mins,
        "totalWorked": c["totalWorked"],
        "extraHrs":    c["extraHrs"],
        "lateHrs":     c["lateHrs"],
        "status":      c["status"],
    }

    col("attendance").update_one(
        {"name": name, "date": date_str},
        {"$set": doc},
        upsert=True
    )
    return ok({"record": doc})

# ── Bulk upsert (CSV import) ──────────────────────────────────────────────────
@app.post("/api/attendance/bulk")
async def bulk_upsert(request: Request):
    if not await ensure_db():
        return err("Database not connected", 503)
    b    = await request.json()
    rows = b if isinstance(b, list) else b.get("records", [])
    imported = 0
    skipped  = 0
    staff_map = {x.get("name"): x for x in col("att_staff").find({}, {"_id": 0})}
    for row in rows:
        name     = (row.get("name") or "").strip()
        date_str = norm_date((row.get("date") or "").strip())
        if not name or not date_str:
            skipped += 1
            continue
        rec_type = (row.get("type") or "work").strip().lower()
        job_type = (row.get("jobType") or "fulltime").strip().lower()
        in_t     = (row.get("inTime") or "").strip()
        out_t    = (row.get("outTime") or "").strip()
        perm_mins_row = int(row.get("permMins") or 0)
        c = calc(in_t, out_t, date_str, rec_type, job_type, perm_mins_row, resolve_shift(staff_map.get(name), date_str))
        doc = {
            "name":        name,
            "date":        date_str,
            "type":        rec_type,
            "jobType":     job_type,
            "inTime":      in_t  if rec_type == "work" else "",
            "outTime":     out_t if rec_type == "work" else "",
            "permMins":    perm_mins_row,
            "totalWorked": c["totalWorked"],
            "extraHrs":    c["extraHrs"],
            "lateHrs":     c["lateHrs"],
            "status":      c["status"],
        }
        col("attendance").update_one({"name": name, "date": date_str}, {"$set": doc}, upsert=True)
        imported += 1
    return ok({"imported": imported, "skipped": skipped})

# ── Assign shifts (full-time only; effective from a week, never touches earlier weeks) ──
@app.post("/api/attendance/shift-assign")
async def att_shift_assign(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    from_raw = (b.get("from") or "").strip()
    items = b.get("assignments") or []
    if not from_raw: return err("'from' is required ('start' or a date)")
    try:
        eff_from = "1900-01-01" if from_raw == "start" else week_monday(from_raw)
    except Exception:
        return err("Invalid 'from' date")
    assigned, recalculated, errors = 0, 0, []
    for it in items:
        name = (it.get("name") or "").strip()
        if not name: continue
        jt = (it.get("jobType") or "").strip().lower()
        if jt not in ("", "fulltime", "parttime"):
            errors.append(f"{name}: invalid job type"); continue
        existing = col("att_staff").find_one({"name": name}, {"_id": 0}) or {}
        eff_type = jt or existing.get("jobType") or "fulltime"
        update = {"name": name}
        if jt: update["jobType"] = jt
        shift_changed = False
        if it.get("start") or it.get("end"):
            s, e = norm_hhmm(it.get("start")), norm_hhmm(it.get("end"))
            if eff_type == "parttime":
                errors.append(f"{name}: shifts apply to full-time employees only")
            elif not s or not e or to_mins(e) <= to_mins(s):
                errors.append(f"{name}: shift end must be after start (same-day shifts only)")
            else:
                try:
                    g = it.get("grace")
                    grace = 15 if g in (None, "") else max(0, min(120, int(g)))
                except Exception:
                    grace = 15
                update["shifts"] = build_shift_history(existing.get("shifts"), eff_from, s, e, grace)
                shift_changed = True
        if len(update) == 1: continue
        col("att_staff").update_one({"name": name}, {"$set": update}, upsert=True)
        assigned += 1
        if shift_changed:
            doc = {**existing, **update}
            q = {"name": name} if eff_from == "1900-01-01" else {"name": name, "date": {"$gte": eff_from}}
            for r in list(col("attendance").find(q, {"_id": 0})):
                c = calc(r.get("inTime",""), r.get("outTime",""), r.get("date",""), r.get("type","work"),
                         r.get("jobType","fulltime"), int(r.get("permMins") or 0), resolve_shift(doc, r.get("date","")))
                col("attendance").update_one(
                    {"name": r["name"], "date": r["date"]},
                    {"$set": {"totalWorked": c["totalWorked"], "extraHrs": c["extraHrs"], "lateHrs": c["lateHrs"], "status": c["status"]}}
                )
                recalculated += 1
    return ok({"success": True, "assigned": assigned, "recalculated": recalculated, "errors": errors, "effectiveFrom": eff_from})

# ── Recalculate all ───────────────────────────────────────────────────────────
@app.post("/api/attendance/recalculate")
async def recalculate_all():
    if not await ensure_db():
        return err("Database not connected", 503)
    rows  = list(col("attendance").find({}, {"_id": 0}))
    staff_map = {x.get("name"): x for x in col("att_staff").find({}, {"_id": 0})}
    count = 0
    for r in rows:
        c = calc(r.get("inTime",""), r.get("outTime",""), r.get("date",""), r.get("type","work"), r.get("jobType","fulltime"), int(r.get("permMins") or 0), resolve_shift(staff_map.get(r.get("name")), r.get("date","")))
        col("attendance").update_one(
            {"name": r["name"], "date": r["date"]},
            {"$set": {"totalWorked": c["totalWorked"], "extraHrs": c["extraHrs"], "lateHrs": c["lateHrs"], "status": c["status"], "permMins": int(r.get("permMins") or 0)}}
        )
        count += 1
    return ok({"recalculated": count})

# ── Delete records ────────────────────────────────────────────────────────────
@app.delete("/api/attendance")
async def delete_attendance(
    name:      Optional[str] = Query(None),
    date_from: Optional[str] = Query(None),
    date_to:   Optional[str] = Query(None),
):
    if not await ensure_db():
        return err("Database not connected", 503)

    # If no filters at all — delete EVERYTHING in the collection
    if not name and not date_from and not date_to:
        result = col("attendance").delete_many({})
        return ok({"deleted": result.deleted_count})

    # Filtered delete — build query
    query = {}
    if name: query["name"] = name
    rows = list(col("attendance").find(query, {"_id": 1, "date": 1}))

    ids_to_delete = []
    for r in rows:
        rd = r.get("date", "")
        try:
            p = rd.split("-")
            if len(p[0]) == 4:
                rdate = date(int(p[0]), int(p[1]), int(p[2]))
            else:
                rdate = date(int(p[2]), int(p[1]), int(p[0]))
            if date_from:
                df = date_from.split("-")
                if rdate < date(int(df[0]), int(df[1]), int(df[2])):
                    continue
            if date_to:
                dt = date_to.split("-")
                if rdate > date(int(dt[0]), int(dt[1]), int(dt[2])):
                    continue
            ids_to_delete.append(r["_id"])
        except Exception:
            ids_to_delete.append(r["_id"])  # include undated records

    if ids_to_delete:
        result = col("attendance").delete_many({"_id": {"$in": ids_to_delete}})
        deleted = result.deleted_count
    else:
        deleted = 0

    return ok({"deleted": deleted})

# ── Delete ALL records (both collections) ────────────────────────────────────
@app.delete("/api/attendance/all")
async def delete_all_attendance():
    if not await ensure_db():
        return err("Database not connected", 503)
    try:
        r1 = col("attendance").delete_many({})
        r2 = col("att_records").delete_many({})
        return ok({"deleted": r1.deleted_count + r2.deleted_count,
                   "attendance": r1.deleted_count,
                   "att_records": r2.deleted_count})
    except Exception as e:
        return err(str(e))

# ── Delete single record by name+date ─────────────────────────────────────────

@app.get("/api/company")
async def get_company():
    # Uses col() which auto-routes to Rio or Rainbow DB
    record = col("company_details").find_one({}, {"_id": 0})
    return record or {}

@app.post("/api/company")
async def save_company(request: Request):
    data = await request.json()
    data.pop("_id", None)
    # Save only the specific section to avoid overwriting other sections
    section = data.pop("section", None)
    col("company_details").update_one({}, {"$set": data}, upsert=True)
    return {"success": True}



@app.post("/api/sales/migrate-customer-gst")
@app.post("/api/billing/sales/migrate-customer-gst")
async def migrate_customer_gst():
    """One-time migration: copy CustomerGST and StateCode from customers into sales records."""
    if not await ensure_db():
        return err("Database not connected", 503)
    try:
        # Build customer lookup map: Name → {GSTNo, StateCode}
        customers = list(col("customers").find({}, {"_id":0,"Name":1,"GSTNo":1,"StateCode":1}))
        cust_map = {c.get("Name","").strip().lower(): c for c in customers if c.get("Name")}

        # Find all sales records that don't have CustomerGST yet
        sales = list(col("sales_records").find(
            {"$or": [{"CustomerGST": {"$exists": False}}, {"CustomerGST": ""}]},
            {"_id":1, "Customer":1}
        ))
        updated = 0
        for s in sales:
            name = (s.get("Customer") or "").strip().lower()
            c = cust_map.get(name)
            if c and (c.get("GSTNo") or c.get("StateCode")):
                col("sales_records").update_one(
                    {"_id": s["_id"]},
                    {"$set": {
                        "CustomerGST": c.get("GSTNo", ""),
                        "CustomerStateCode": c.get("StateCode", "")
                    }}
                )
                updated += 1
        return {"success": True, "updated": updated, "total": len(sales)}
    except Exception as e:
        return err(str(e), 500)


@app.post("/api/customers/merge-shared")
@app.post("/api/billing/customers/merge-shared")
async def merge_customers_to_shared():
    """One-time migration: copy Rainbow customers into RioPrintMedia.rio_clients."""
    if not await ensure_db(): return err("Database not connected", 503)
    try:
        if not _client: return err("No DB client")
        rainbow_clients = list(_client[MONGO_DB_RAINBOW]["rio_clients"].find({}, {"_id": 0}))
        merged = 0
        skipped = 0
        for c in rainbow_clients:
            name = (c.get("ClientName") or c.get("Name") or "").strip()
            if not name:
                continue
            exists = shared_col("rio_clients").find_one({"ClientName": {"$regex": f"^{re.escape(name)}$", "$options": "i"}})
            if exists:
                skipped += 1
                continue
            # Assign new Id
            new_id = next_id("rio_clients")
            c["Id"] = new_id
            c.pop("_id", None)
            shared_col("rio_clients").insert_one(c)
            merged += 1
        return ok({"success": True, "merged": merged, "skipped": skipped, "total": len(rainbow_clients)})
    except Exception as e:
        return err(str(e), 500)


@app.put("/api/categories")
@app.put("/api/billing/categories")
async def put_category(request: Request):
    """Rename a category or subcategory."""
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    old_cat = (b.get("oldCategory") or "").strip()
    new_cat = (b.get("newCategory") or "").strip()
    old_sub = (b.get("oldSubCategory") or "").strip()
    new_sub = (b.get("newSubCategory") or "").strip()
    try:
        if old_sub and new_sub:
            # Rename subcategory
            col("expense_categories").update_many(
                {"CategoryName": old_cat, "SubCategoryName": old_sub},
                {"$set": {"SubCategoryName": new_sub}}
            )
            # Update existing expense records
            col("daily_expenses").update_many(
                {"Category": old_cat, "SubCategory": old_sub},
                {"$set": {"SubCategory": new_sub}}
            )
        elif old_cat and new_cat:
            # Rename category
            col("expense_categories").update_many(
                {"CategoryName": old_cat},
                {"$set": {"CategoryName": new_cat}}
            )
            # Update existing expense records
            col("daily_expenses").update_many(
                {"Category": old_cat},
                {"$set": {"Category": new_cat}}
            )
        return ok({"success": True})
    except Exception as e:
        return err(str(e), 500)

@app.post("/api/categories/add")
@app.post("/api/billing/categories/add")
async def add_category(request: Request):
    """Add a new category (no subcategory required)."""
    if not await ensure_db(): return err("Database not connected", 503)
    b = await request.json()
    cat = (b.get("CategoryName") or "").strip()
    sub = (b.get("SubCategoryName") or "").strip()
    if not cat: return err("Category name required")
    try:
        if sub:
            exists = col("expense_categories").find_one({"CategoryName": cat, "SubCategoryName": sub})
            if not exists:
                new_id = next_id("expense_categories")
                col("expense_categories").insert_one({"Id": new_id, "CategoryName": cat, "SubCategoryName": sub})
        else:
            # Add category with empty placeholder sub if it doesn't exist at all
            exists = col("expense_categories").find_one({"CategoryName": cat})
            if not exists:
                new_id = next_id("expense_categories")
                col("expense_categories").insert_one({"Id": new_id, "CategoryName": cat, "SubCategoryName": ""})
        return ok({"success": True})
    except Exception as e:
        return err(str(e), 500)


@app.post("/api/billing/sales/migrate-gst-rates")
@app.post("/api/sales/migrate-gst-rates")
async def migrate_gst_rates():
    """Patch GSTRate1 on old sales records from products collection."""
    if not await ensure_db(): return err("Database not connected", 503)
    try:
        sales = list(col("sales").find({"$or": [{"GSTRate1": {"$exists": False}}, {"GSTRate1": 0}]}))
        products = {p.get("ProductCode") or p.get("Id"): p for p in col("products").find({})}
        updated = 0
        for s in sales:
            pid = s.get("ProductId")
            if pid and str(pid) in products:
                gst = products[str(pid)].get("GSTRate") or products[str(pid)].get("gstRate") or 0
                if gst:
                    col("sales").update_one({"_id": s["_id"]}, {"$set": {"GSTRate1": float(gst)}})
                    updated += 1
        return ok({"success": True, "updated": updated})
    except Exception as e:
        return err(str(e), 500)


@app.delete("/api/attendance/record")
async def delete_record(name: str = Query(...), date: str = Query(...)):
    if not await ensure_db():
        return err("Database not connected", 503)
    result = col("attendance").delete_one({"name": name, "date": norm_date(date)})
    return ok({"deleted": result.deleted_count})

# ══════════════════════════════════════════════════════════════
# END ATTENDANCE
# ══════════════════════════════════════════════════════════════

# ══════════════════════════════════════════════════════════════
# PURCHASE AND STOCK MODULE
# ══════════════════════════════════════════════════════════════
# Collections (company-separated via existing middleware):
#   suppliers        — supplier master
#   purchases        — purchase headers (P001, P002…)
#   purchase_items   — line items per purchase
#   stock_ledger     — every IN/OUT movement with running balance

# ── SUPPLIERS ─────────────────────────────────────────────────

@app.get("/api/billing/suppliers")
async def get_suppliers(q: Optional[str] = Query(None)):
    if not await ensure_db(): return err("Database not connected", 503)
    query = {}
    if q:
        query = {"$or": [
            {"Name":    {"$regex": q, "$options": "i"}},
            {"GSTNo":   {"$regex": q, "$options": "i"}},
            {"Phone":   {"$regex": q, "$options": "i"}},
        ]}
    docs = list(col("suppliers").find(query, {"_id": 0}).sort("Name", 1))
    return JSONResponse(content={"data": docs, "total": len(docs)})

@app.get("/api/billing/suppliers/{sup_id}")
async def get_supplier(sup_id: int):
    if not await ensure_db(): return err("Database not connected", 503)
    doc = col("suppliers").find_one({"Id": sup_id}, {"_id": 0})
    if not doc: return err("Supplier not found", 404)
    return JSONResponse(content=doc)

@app.post("/api/billing/suppliers")
async def create_supplier(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    data = await request.json()
    if not data.get("Name"): return err("Name is required")
    new_id = next_id("suppliers")
    doc = {
        "Id":            new_id,
        "Name":          data.get("Name", "").strip(),
        "ContactPerson": data.get("ContactPerson", "").strip(),
        "Phone":         data.get("Phone", "").strip(),
        "Email":         data.get("Email", "").strip(),
        "GSTNo":         data.get("GSTNo", "").strip(),
        "BillToAddress": data.get("BillToAddress", "").strip(),
        "BankDetails":   data.get("BankDetails", "").strip(),
        "CreatedAt":     datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    col("suppliers").insert_one(doc)
    return ok({"Id": new_id, "Name": doc["Name"]})

@app.put("/api/billing/suppliers/{sup_id}")
async def update_supplier(sup_id: int, request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    data = await request.json()
    if not data.get("Name"): return err("Name is required")
    update = {
        "Name":          data.get("Name", "").strip(),
        "ContactPerson": data.get("ContactPerson", "").strip(),
        "Phone":         data.get("Phone", "").strip(),
        "Email":         data.get("Email", "").strip(),
        "GSTNo":         data.get("GSTNo", "").strip(),
        "BillToAddress": data.get("BillToAddress", "").strip(),
        "BankDetails":   data.get("BankDetails", "").strip(),
    }
    result = col("suppliers").update_one({"Id": sup_id}, {"$set": update})
    if result.matched_count == 0: return err("Supplier not found", 404)
    return ok({"updated": True})

@app.delete("/api/billing/suppliers/{sup_id}")
async def delete_supplier(sup_id: int):
    if not await ensure_db(): return err("Database not connected", 503)
    # Block deletion if there are purchases referencing this supplier
    if col("purchases").find_one({"SupplierId": sup_id}):
        return err("Cannot delete — supplier has purchase records", 400)
    result = col("suppliers").delete_one({"Id": sup_id})
    if result.deleted_count == 0: return err("Supplier not found", 404)
    return ok({"deleted": True})

# ── PURCHASES ─────────────────────────────────────────────────

@app.get("/api/billing/purchases/next-no")
async def get_next_purchase_no():
    if not await ensure_db(): return err("Database not connected", 503)
    last = col("purchases").find_one({}, sort=[("Id", -1)])
    next_num = (last["Id"] + 1) if last else 1
    return ok({"PurchaseNo": f"P{next_num:03d}", "next": next_num})

@app.get("/api/billing/purchases")
async def get_purchases(q: Optional[str] = Query(None),
                        supplier_id: Optional[int] = Query(None),
                        page: int = Query(1), page_size: int = Query(50)):
    if not await ensure_db(): return err("Database not connected", 503)
    query = {}
    if q:
        query["$or"] = [
            {"PurchaseNo":    {"$regex": q, "$options": "i"}},
            {"SupplierName":  {"$regex": q, "$options": "i"}},
        ]
    if supplier_id:
        query["SupplierId"] = supplier_id
    total = col("purchases").count_documents(query)
    skip  = (page - 1) * page_size
    docs  = list(col("purchases").find(query, {"_id": 0})
                 .sort("Id", -1).skip(skip).limit(page_size))
    return JSONResponse(content={"data": docs, "total": total, "page": page, "pageSize": page_size})

@app.get("/api/billing/purchases/{purchase_id}")
async def get_purchase(purchase_id: int):
    if not await ensure_db(): return err("Database not connected", 503)
    doc = col("purchases").find_one({"Id": purchase_id}, {"_id": 0})
    if not doc: return err("Purchase not found", 404)
    items = list(col("purchase_items").find(
        {"PurchaseId": purchase_id}, {"_id": 0}).sort("SNo", 1))
    return JSONResponse(content={**doc, "Items": items})

@app.post("/api/billing/purchases")
async def create_purchase(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    data = await request.json()
    if not data.get("SupplierId"): return err("SupplierId is required")
    items = data.get("Items", [])
    if not items: return err("At least one item is required")

    purchase_id   = next_id("purchases")
    purchase_no   = f"P{purchase_id:03d}"
    purchase_date = data.get("PurchaseDate", datetime.now().strftime("%Y-%m-%d"))
    supplier      = col("suppliers").find_one({"Id": int(data["SupplierId"])}, {"_id": 0})
    supplier_name = supplier["Name"] if supplier else data.get("SupplierName", "")

    sub_total = 0.0
    processed = []
    for i, it in enumerate(items):
        qty    = float(it.get("Qty", 0))
        rate   = float(it.get("Rate", 0))
        total  = qty * rate
        sub_total += total
        processed.append({
            "PurchaseId":  purchase_id,
            "SNo":         i + 1,
            "ProductName": it.get("ProductName", "").strip(),
            "HSN":         it.get("HSN", "").strip(),
            "Qty":         qty,
            "Unit":        it.get("Unit", "Nos").strip(),
            "Rate":        rate,
            "Total":       round(total, 2),
        })

    doc = {
        "Id":           purchase_id,
        "PurchaseNo":   purchase_no,
        "PurchaseDate": purchase_date,
        "SupplierId":   int(data["SupplierId"]),
        "SupplierName": supplier_name,
        "InvoiceRef":   data.get("InvoiceRef", "").strip(),
        "SubTotal":     round(sub_total, 2),
        "TotalAmount":  round(sub_total, 2),
        "Notes":        data.get("Notes", "").strip(),
        "CreatedAt":    datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    col("purchases").insert_one(doc)
    if processed:
        col("purchase_items").insert_many(processed)

    # Automatically write Stock IN entries for each item
    for it in processed:
        if it["ProductName"] and it["Qty"] > 0:
            stock_id = next_id("stock_ledger")
            col("stock_ledger").insert_one({
                "Id":          stock_id,
                "Date":        purchase_date,
                "ProductName": it["ProductName"],
                "Type":        "IN",
                "Qty":         it["Qty"],
                "Unit":        it["Unit"],
                "Rate":        it["Rate"],
                "Reference":   purchase_no,
                "Remarks":     f"Purchase from {supplier_name}",
                "CreatedAt":   datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            })

    return ok({"Id": purchase_id, "PurchaseNo": purchase_no})

@app.put("/api/billing/purchases/{purchase_id}")
async def update_purchase(purchase_id: int, request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    purchase = col("purchases").find_one({"Id": purchase_id})
    if not purchase: return err("Purchase not found", 404)
    data = await request.json()
    if not data.get("SupplierId"): return err("SupplierId is required")
    items = data.get("Items", [])
    if not items: return err("At least one item is required")

    old_no        = purchase["PurchaseNo"]
    purchase_date = data.get("PurchaseDate", purchase.get("PurchaseDate"))
    supplier      = col("suppliers").find_one({"Id": int(data["SupplierId"])}, {"_id": 0})
    supplier_name = supplier["Name"] if supplier else data.get("SupplierName", "")

    sub_total = 0.0
    processed = []
    for i, it in enumerate(items):
        qty    = float(it.get("Qty", 0))
        rate   = float(it.get("Rate", 0))
        total  = qty * rate
        sub_total += total
        processed.append({
            "PurchaseId":  purchase_id,
            "SNo":         i + 1,
            "ProductName": it.get("ProductName", "").strip(),
            "HSN":         it.get("HSN", "").strip(),
            "Qty":         qty,
            "Unit":        it.get("Unit", "Nos").strip(),
            "Rate":        rate,
            "Total":       round(total, 2),
        })

    col("purchases").update_one({"Id": purchase_id}, {"$set": {
        "PurchaseDate": purchase_date,
        "SupplierId":   int(data["SupplierId"]),
        "SupplierName": supplier_name,
        "InvoiceRef":   data.get("InvoiceRef", "").strip(),
        "SubTotal":     round(sub_total, 2),
        "TotalAmount":  round(sub_total, 2),
        "Notes":        data.get("Notes", "").strip(),
    }})

    # Replace purchase_items
    col("purchase_items").delete_many({"PurchaseId": purchase_id})
    if processed:
        col("purchase_items").insert_many(processed)

    # Replace the auto-generated Stock IN entries for this purchase
    col("stock_ledger").delete_many({"Reference": old_no, "Type": "IN"})
    for it in processed:
        if it["ProductName"] and it["Qty"] > 0:
            stock_id = next_id("stock_ledger")
            col("stock_ledger").insert_one({
                "Id":          stock_id,
                "Date":        purchase_date,
                "ProductName": it["ProductName"],
                "Type":        "IN",
                "Qty":         it["Qty"],
                "Unit":        it["Unit"],
                "Rate":        it["Rate"],
                "Reference":   old_no,
                "Remarks":     f"Purchase from {supplier_name}",
                "CreatedAt":   datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            })

    return ok({"Id": purchase_id, "PurchaseNo": old_no})

@app.delete("/api/billing/purchases/{purchase_id}")
async def delete_purchase(purchase_id: int):
    if not await ensure_db(): return err("Database not connected", 503)
    purchase = col("purchases").find_one({"Id": purchase_id})
    if not purchase: return err("Purchase not found", 404)
    # Remove the auto-generated stock IN entries for this purchase
    col("stock_ledger").delete_many({"Reference": purchase["PurchaseNo"], "Type": "IN"})
    col("purchase_items").delete_many({"PurchaseId": purchase_id})
    col("purchases").delete_one({"Id": purchase_id})
    return ok({"deleted": True})

# ── STOCK LEDGER ──────────────────────────────────────────────

@app.get("/api/billing/stock/ledger")
async def get_stock_ledger(product: Optional[str] = Query(None),
                           type_filter: Optional[str] = Query(None),
                           date_from: Optional[str] = Query(None),
                           date_to: Optional[str] = Query(None)):
    if not await ensure_db(): return err("Database not connected", 503)
    query = {}
    if product:
        query["ProductName"] = {"$regex": product, "$options": "i"}
    if type_filter in ("IN", "OUT"):
        query["Type"] = type_filter
    if date_from or date_to:
        query["Date"] = {}
        if date_from: query["Date"]["$gte"] = date_from
        if date_to:   query["Date"]["$lte"] = date_to
    docs = list(col("stock_ledger").find(query, {"_id": 0}).sort([("Date", 1), ("Id", 1)]))
    # Compute running balance per product
    balances = {}
    for d in docs:
        p = d["ProductName"]
        balances.setdefault(p, 0)
        qty = float(d.get("Qty", 0))
        if d["Type"] == "IN":  balances[p] += qty
        else:                  balances[p] -= qty
        d["Balance"] = round(balances[p], 2)
    docs.reverse()   # most recent first for display
    return JSONResponse(content={"data": docs, "total": len(docs)})

@app.get("/api/billing/stock/products")
async def get_stock_products():
    """Distinct product names that appear in the ledger — for dropdowns."""
    if not await ensure_db(): return err("Database not connected", 503)
    names = col("stock_ledger").distinct("ProductName")
    names.sort()
    return JSONResponse(content={"data": names})

@app.get("/api/billing/stock/summary")
async def get_stock_summary():
    """Current balance per product — for dashboard widget."""
    if not await ensure_db(): return err("Database not connected", 503)
    pipeline = [
        {"$group": {
            "_id": "$ProductName",
            "in_qty":  {"$sum": {"$cond": [{"$eq": ["$Type","IN"]},  {"$toDouble": "$Qty"}, 0]}},
            "out_qty": {"$sum": {"$cond": [{"$eq": ["$Type","OUT"]}, {"$toDouble": "$Qty"}, 0]}},
        }},
        {"$project": {
            "ProductName": "$_id",
            "Balance": {"$subtract": ["$in_qty", "$out_qty"]},
            "InTotal": "$in_qty", "OutTotal": "$out_qty",
        }},
        {"$sort": {"ProductName": 1}}
    ]
    docs = list(col("stock_ledger").aggregate(pipeline))
    for d in docs: d.pop("_id", None)
    return JSONResponse(content={"data": docs})

@app.post("/api/billing/stock/out")
async def add_stock_out(request: Request):
    """Manual OUT entry — posted by office after raising an invoice."""
    if not await ensure_db(): return err("Database not connected", 503)
    data = await request.json()
    product = data.get("ProductName", "").strip()
    qty     = float(data.get("Qty", 0))
    if not product: return err("ProductName is required")
    if qty <= 0:    return err("Qty must be positive")
    stock_id = next_id("stock_ledger")
    col("stock_ledger").insert_one({
        "Id":          stock_id,
        "Date":        data.get("Date", datetime.now().strftime("%Y-%m-%d")),
        "ProductName": product,
        "Type":        "OUT",
        "Qty":         qty,
        "Unit":        data.get("Unit", "Nos").strip(),
        "Rate":        float(data.get("Rate", 0)),
        "CustomerName": data.get("CustomerName", "").strip(),
        "JobName":     data.get("JobName", "").strip(),
        "JobSize":     data.get("JobSize", "").strip(),
        "JobQty":      data.get("JobQty", "").strip(),
        "UpdatedBy":   data.get("UpdatedBy", "").strip(),
        "Reference":   data.get("Reference", "").strip(),
        "Remarks":     data.get("Remarks", "").strip(),
        "CreatedAt":   datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    })
    return ok({"Id": stock_id})

@app.put("/api/billing/stock/ledger/{entry_id}")
async def update_stock_entry(entry_id: int, request: Request):
    """Edit a manual OUT entry only (auto IN entries are only changed via the Purchase)."""
    if not await ensure_db(): return err("Database not connected", 503)
    data = await request.json()
    entry = col("stock_ledger").find_one({"Id": entry_id})
    if not entry: return err("Entry not found", 404)
    if entry.get("Type") == "IN":
        return err("Cannot edit an auto IN entry — edit the Purchase instead", 400)
    product = data.get("ProductName", "").strip()
    qty     = float(data.get("Qty", 0))
    if not product: return err("ProductName is required")
    if qty <= 0:    return err("Qty must be positive")
    col("stock_ledger").update_one({"Id": entry_id}, {"$set": {
        "Date":        data.get("Date", entry.get("Date")),
        "ProductName": product,
        "Qty":         qty,
        "Unit":        data.get("Unit", "Nos").strip(),
        "Rate":        float(data.get("Rate", 0)),
        "CustomerName": data.get("CustomerName", "").strip(),
        "JobName":     data.get("JobName", "").strip(),
        "JobSize":     data.get("JobSize", "").strip(),
        "JobQty":      data.get("JobQty", "").strip(),
        "UpdatedBy":   data.get("UpdatedBy", "").strip(),
        "Reference":   data.get("Reference", "").strip(),
        "Remarks":     data.get("Remarks", "").strip(),
    }})
    return ok({"updated": True})

@app.delete("/api/billing/stock/ledger/{entry_id}")
async def delete_stock_entry(entry_id: int):
    """Delete a manual OUT entry only (auto IN entries deleted via purchase delete)."""
    if not await ensure_db(): return err("Database not connected", 503)
    entry = col("stock_ledger").find_one({"Id": entry_id})
    if not entry: return err("Entry not found", 404)
    if entry.get("Type") == "IN":
        return err("Cannot delete an auto IN entry — delete the Purchase instead", 400)
    col("stock_ledger").delete_one({"Id": entry_id})
    return ok({"deleted": True})

# ── PURCHASE PRODUCTS CATALOG (Name + HSN, used by Purchases and Stock OUT) ──

@app.get("/api/billing/purchase-products")
async def get_purchase_products():
    if not await ensure_db(): return err("Database not connected", 503)
    docs = list(col("purchase_products").find({}, {"_id": 0}).sort("Name", 1))
    return JSONResponse(content={"data": docs})

@app.post("/api/billing/purchase-products")
async def add_purchase_product(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    data = await request.json()
    name = data.get("Name", "").strip()
    if not name: return err("Product name is required")
    prod_id = next_id("purchase_products")
    col("purchase_products").insert_one({
        "Id": prod_id, "Name": name, "Size": data.get("Size", "").strip(), "HSN": data.get("HSN", "").strip(),
        "CreatedAt": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    })
    return ok({"Id": prod_id})

@app.put("/api/billing/purchase-products/{prod_id}")
async def update_purchase_product(prod_id: int, request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    data = await request.json()
    name = data.get("Name", "").strip()
    if not name: return err("Product name is required")
    r = col("purchase_products").update_one({"Id": prod_id}, {"$set": {
        "Name": name, "Size": data.get("Size", "").strip(), "HSN": data.get("HSN", "").strip(),
    }})
    if r.matched_count == 0: return err("Product not found", 404)
    return ok({"updated": True})

@app.delete("/api/billing/purchase-products/{prod_id}")
async def delete_purchase_product(prod_id: int):
    if not await ensure_db(): return err("Database not connected", 503)
    col("purchase_products").delete_one({"Id": prod_id})
    return ok({"deleted": True})

# ── EMPLOYEES (used by "Updated By" on Stock OUT entries) ────────────

@app.get("/api/billing/employees")
async def get_employees():
    if not await ensure_db(): return err("Database not connected", 503)
    docs = list(col("employees").find({}, {"_id": 0}).sort("Name", 1))
    return JSONResponse(content={"data": docs})

@app.post("/api/billing/employees")
async def add_employee(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    data = await request.json()
    name = data.get("Name", "").strip()
    if not name: return err("Employee name is required")
    emp_id = next_id("employees")
    col("employees").insert_one({
        "Id": emp_id, "Name": name,
        "CreatedAt": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    })
    return ok({"Id": emp_id})

@app.put("/api/billing/employees/{emp_id}")
async def update_employee(emp_id: int, request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    data = await request.json()
    name = data.get("Name", "").strip()
    if not name: return err("Employee name is required")
    r = col("employees").update_one({"Id": emp_id}, {"$set": {"Name": name}})
    if r.matched_count == 0: return err("Employee not found", 404)
    return ok({"updated": True})

@app.delete("/api/billing/employees/{emp_id}")
async def delete_employee(emp_id: int):
    if not await ensure_db(): return err("Database not connected", 503)
    col("employees").delete_one({"Id": emp_id})
    return ok({"deleted": True})

# ── STOCK MOBILE PIN GATE + ACCESS LOG ────────────────────────
# Shared across both companies (one link, one team) — not company-scoped.

def _client_ip(request: Request) -> str:
    xff = request.headers.get("x-forwarded-for")
    if xff:
        return xff.split(",")[0].strip()
    return request.client.host if request.client else "unknown"

DEFAULT_STOCK_PIN = "1234"  # change this on first use via the Access Log screen in Purchase & Stock
DEFAULT_STOCK_PIN_SESSION_DAYS = 7

@app.get("/api/billing/stock-pin/config")
async def get_stock_pin_config():
    """Returns whether a PIN is set and how many days a device stays remembered.
    Never returns the PIN itself."""
    if not await ensure_db(): return err("Database not connected", 503)
    cfg = shared_col("stock_pin_config").find_one({"_key": "main"}, {"_id": 0})
    return JSONResponse(content={
        "sessionDays": (cfg or {}).get("SessionDays", DEFAULT_STOCK_PIN_SESSION_DAYS),
        "configured": bool(cfg and cfg.get("Pin")),
    })

@app.post("/api/billing/stock-pin/set")
async def set_stock_pin(request: Request):
    """Admin-only in practice (gated on the frontend, like other admin actions in this app)."""
    if not await ensure_db(): return err("Database not connected", 503)
    data = await request.json()
    pin = str(data.get("Pin", "")).strip()
    if not re.fullmatch(r"\d{4}", pin):
        return err("PIN must be exactly 4 digits")
    session_days = int(data.get("SessionDays", DEFAULT_STOCK_PIN_SESSION_DAYS) or DEFAULT_STOCK_PIN_SESSION_DAYS)
    shared_col("stock_pin_config").update_one(
        {"_key": "main"},
        {"$set": {"_key": "main", "Pin": pin, "SessionDays": session_days,
                   "UpdatedAt": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}},
        upsert=True
    )
    return ok({"updated": True})

@app.post("/api/billing/stock-pin/verify")
async def verify_stock_pin(request: Request):
    if not await ensure_db(): return err("Database not connected", 503)
    data = await request.json()
    pin = str(data.get("Pin", "")).strip()
    device = str(data.get("Device", "")).strip()[:200]
    cfg = shared_col("stock_pin_config").find_one({"_key": "main"}, {"_id": 0})
    correct_pin = (cfg or {}).get("Pin", DEFAULT_STOCK_PIN)
    success = (pin == correct_pin)
    log_id = next_id("stock_access_log")
    shared_col("stock_access_log").insert_one({
        "Id": log_id,
        "Timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "IP": _client_ip(request),
        "Device": device or request.headers.get("user-agent", "unknown")[:200],
        "Success": success,
    })
    if not success:
        return err("Incorrect PIN", 401)
    return ok({"verified": True, "sessionDays": (cfg or {}).get("SessionDays", DEFAULT_STOCK_PIN_SESSION_DAYS)})

@app.get("/api/billing/stock-access-log")
async def get_stock_access_log(limit: int = Query(100, ge=1, le=500)):
    if not await ensure_db(): return err("Database not connected", 503)
    docs = list(shared_col("stock_access_log").find({}, {"_id": 0}).sort("Id", -1).limit(limit))
    return JSONResponse(content={"data": docs})

# ══════════════════════════════════════════════════════════════
# END PURCHASE AND STOCK
# ══════════════════════════════════════════════════════════════
